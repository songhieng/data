"""
Gated EMA Validation Framework
=============================

A comprehensive validation framework for Gated Exponential Moving Average (EMA) 
template updates in face recognition systems.

This framework provides:
1. Face Verification Accuracy Over Time
2. Genuine-Impostor Score Separation Analysis
3. Template Drift Robustness Testing
4. Update Stability & Sensitivity Metrics
5. Ablation Study Comparisons
6. Real-World Simulation Capabilities

Key Components:
- Core Gated EMA implementation with validation hooks
- Comprehensive validation metrics and analyzers
- Visualization and reporting tools
- Experimental framework for systematic evaluation

Usage:
    from gated_ema_validation import GatedEMAValidator, ValidationConfig
    
    config = ValidationConfig()
    validator = GatedEMAValidator(config)
    results = validator.run_comprehensive_validation()

Author: Gated EMA Validation Framework
Version: 1.0.0
"""

from .config import ValidationConfig, GatedEMAConfig
from .core import GatedEMATemplate, GatedEMAUpdater
from .validators import (
    VerificationAccuracyValidator,
    GenuineImpostorValidator, 
    DriftRobustnessValidator,
    UpdateStabilityValidator,
    AblationStudyValidator
)
from .analyzers import ValidationAnalyzer, ResultsVisualizer
from .experiments import GatedEMAValidator
from .utils import TemporalDataLoader, MetricsCalculator

__version__ = "1.0.0"
__author__ = "Gated EMA Validation Framework"

__all__ = [
    'ValidationConfig',
    'GatedEMAConfig', 
    'GatedEMATemplate',
    'GatedEMAUpdater',
    'VerificationAccuracyValidator',
    'GenuineImpostorValidator',
    'DriftRobustnessValidator', 
    'UpdateStabilityValidator',
    'AblationStudyValidator',
    'ValidationAnalyzer',
    'ResultsVisualizer',
    'GatedEMAValidator',
    'TemporalDataLoader',
    'MetricsCalculator'
] 