"""
Analysis and Visualization Components for Gated EMA Validation
============================================================

This module provides comprehensive analysis and visualization tools
for the validation results.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Any, Optional, Tuple
import logging
from pathlib import Path

from .validators import ValidationResults
from .config import VisualizationConfig

logger = logging.getLogger(__name__)


class ValidationAnalyzer:
    """Comprehensive analyzer for validation results."""
    
    def __init__(self, config: VisualizationConfig):
        self.config = config
        self.results_cache = {}
    
    def analyze_comprehensive_results(self, all_results: Dict[str, ValidationResults]) -> Dict[str, Any]:
        """
        Perform comprehensive analysis across all validation results.
        
        Args:
            all_results: Dictionary mapping validator names to their results
            
        Returns:
            Comprehensive analysis summary
        """
        
        analysis = {
            'summary': {},
            'detailed_findings': {},
            'recommendations': [],
            'pass_fail_summary': {},
            'key_metrics': {}
        }
        
        # Overall pass/fail summary
        total_validators = len(all_results)
        passed_validators = sum(1 for result in all_results.values() if result.passed)
        
        analysis['pass_fail_summary'] = {
            'total_validators': total_validators,
            'passed_validators': passed_validators,
            'failed_validators': total_validators - passed_validators,
            'overall_pass_rate': passed_validators / total_validators if total_validators > 0 else 0
        }
        
        # Detailed analysis for each validator
        for validator_name, result in all_results.items():
            analysis['detailed_findings'][validator_name] = {
                'passed': result.passed,
                'summary': result.summary,
                'key_metrics': self._extract_key_metrics(result)
            }
        
        # Generate recommendations
        analysis['recommendations'] = self._generate_recommendations(all_results)
        
        # Extract key metrics for comparison
        analysis['key_metrics'] = self._compile_key_metrics(all_results)
        
        return analysis
    
    def _extract_key_metrics(self, result: ValidationResults) -> Dict[str, Any]:
        """Extract key metrics from validation results."""
        
        key_metrics = {}
        
        if result.metric_name == "Verification Accuracy Over Time":
            values = result.values
            if 'roc_auc_over_time' in values and values['roc_auc_over_time']:
                key_metrics['final_roc_auc'] = values['roc_auc_over_time'][-1]
                key_metrics['initial_roc_auc'] = values['roc_auc_over_time'][0]
                key_metrics['roc_auc_trend'] = (key_metrics['final_roc_auc'] - 
                                              key_metrics['initial_roc_auc'])
            
            if 'eer_over_time' in values and values['eer_over_time']:
                key_metrics['final_eer'] = values['eer_over_time'][-1]
                key_metrics['initial_eer'] = values['eer_over_time'][0]
        
        elif result.metric_name == "Genuine-Impostor Separation":
            values = result.values
            key_metrics['separation_gap'] = values.get('separation_gap', 0)
            key_metrics['effect_size'] = values.get('effect_size', 0)
            key_metrics['genuine_mean'] = values.get('genuine_mean', 0)
            key_metrics['impostor_mean'] = values.get('impostor_mean', 0)
        
        elif result.metric_name == "Template Drift Robustness":
            values = result.values
            drift_stats = values.get('drift_statistics', {})
            key_metrics['mean_drift'] = drift_stats.get('mean_total_drift', 0)
            key_metrics['drift_stability'] = 1 / (1 + drift_stats.get('std_total_drift', 0))
        
        elif result.metric_name == "Update Stability & Sensitivity":
            values = result.values
            key_metrics['update_frequency'] = values.get('update_frequency', 0)
            key_metrics['rejection_rate'] = values.get('rejection_rate', 0)
        
        return key_metrics
    
    def _generate_recommendations(self, all_results: Dict[str, ValidationResults]) -> List[str]:
        """Generate actionable recommendations based on validation results."""
        
        recommendations = []
        
        # Check overall performance
        pass_rate = sum(1 for r in all_results.values() if r.passed) / len(all_results)
        
        if pass_rate < 0.5:
            recommendations.append(
                "⚠️ CRITICAL: Less than 50% of validators passed. "
                "Consider fundamental changes to the Gated EMA approach."
            )
        elif pass_rate < 0.8:
            recommendations.append(
                "⚠️ WARNING: Moderate validation performance. "
                "Fine-tuning parameters may improve results."
            )
        else:
            recommendations.append(
                "✅ GOOD: Most validators passed. "
                "System shows strong validation performance."
            )
        
        # Specific recommendations based on individual validators
        for validator_name, result in all_results.items():
            if not result.passed:
                if validator_name == "Verification Accuracy Over Time":
                    recommendations.append(
                        "🎯 Verification accuracy is declining over time. "
                        "Consider more conservative update thresholds."
                    )
                
                elif validator_name == "Genuine-Impostor Separation":
                    recommendations.append(
                        "📊 Poor genuine-impostor separation. "
                        "Template updates may be reducing discriminability."
                    )
                
                elif validator_name == "Template Drift Robustness":
                    recommendations.append(
                        "🔄 Template drift is excessive or unstable. "
                        "Consider stricter update criteria or drift limits."
                    )
                
                elif validator_name == "Update Stability & Sensitivity":
                    recommendations.append(
                        "⚖️ Update behavior is either too aggressive or too conservative. "
                        "Adjust confidence thresholds for better balance."
                    )
        
        return recommendations
    
    def _compile_key_metrics(self, all_results: Dict[str, ValidationResults]) -> Dict[str, Any]:
        """Compile key metrics for easy comparison."""
        
        key_metrics = {}
        
        for validator_name, result in all_results.items():
            extracted = self._extract_key_metrics(result)
            for metric_name, value in extracted.items():
                full_name = f"{validator_name}_{metric_name}"
                key_metrics[full_name] = value
        
        return key_metrics


class ResultsVisualizer:
    """Comprehensive visualization tools for validation results."""
    
    def __init__(self, config: VisualizationConfig):
        self.config = config
        self._setup_style()
    
    def _setup_style(self):
        """Set up matplotlib style."""
        plt.style.use(self.config.style)
        sns.set_palette(self.config.color_palette)
        
        # Set font sizes
        plt.rcParams.update({
            'font.size': self.config.tick_fontsize,
            'axes.titlesize': self.config.title_fontsize,
            'axes.labelsize': self.config.label_fontsize,
            'legend.fontsize': self.config.legend_fontsize,
            'figure.figsize': self.config.figure_size
        })
    
    def create_comprehensive_report(self, all_results: Dict[str, ValidationResults],
                                  analysis: Dict[str, Any],
                                  save_dir: str) -> List[str]:
        """
        Create comprehensive visualization report.
        
        Args:
            all_results: Validation results from all validators
            analysis: Analysis results from ValidationAnalyzer
            save_dir: Directory to save plots
            
        Returns:
            List of created plot file paths
        """
        
        save_path = Path(save_dir)
        save_path.mkdir(parents=True, exist_ok=True)
        
        created_plots = []
        
        # 1. Overall Summary Dashboard
        dashboard_path = self._create_summary_dashboard(analysis, save_path)
        if dashboard_path:
            created_plots.append(dashboard_path)
        
        # 2. Verification Accuracy Over Time
        if "Verification Accuracy Over Time" in all_results:
            accuracy_plots = self._plot_verification_accuracy(
                all_results["Verification Accuracy Over Time"], save_path
            )
            created_plots.extend(accuracy_plots)
        
        # 3. Genuine-Impostor Separation
        if "Genuine-Impostor Separation" in all_results:
            separation_plots = self._plot_genuine_impostor_separation(
                all_results["Genuine-Impostor Separation"], save_path
            )
            created_plots.extend(separation_plots)
        
        # 4. Template Drift Analysis
        if "Template Drift Robustness" in all_results:
            drift_plots = self._plot_template_drift(
                all_results["Template Drift Robustness"], save_path
            )
            created_plots.extend(drift_plots)
        
        # 5. Update Stability Analysis
        if "Update Stability & Sensitivity" in all_results:
            stability_plots = self._plot_update_stability(
                all_results["Update Stability & Sensitivity"], save_path
            )
            created_plots.extend(stability_plots)
        
        # 6. Ablation Study Comparison
        if "Ablation Study" in all_results:
            ablation_plots = self._plot_ablation_study(
                all_results["Ablation Study"], save_path
            )
            created_plots.extend(ablation_plots)
        
        return created_plots
    
    def _create_summary_dashboard(self, analysis: Dict[str, Any], save_path: Path) -> Optional[str]:
        """Create overall summary dashboard."""
        
        try:
            fig, axes = plt.subplots(2, 2, figsize=(16, 12))
            fig.suptitle('Gated EMA Validation Summary Dashboard', fontsize=20, fontweight='bold')
            
            # 1. Pass/Fail Summary (Pie Chart)
            ax1 = axes[0, 0]
            pass_fail = analysis['pass_fail_summary']
            labels = ['Passed', 'Failed']
            sizes = [pass_fail['passed_validators'], pass_fail['failed_validators']]
            colors = ['#2ecc71', '#e74c3c']
            
            ax1.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
            ax1.set_title('Validation Pass/Fail Summary')
            
            # 2. Key Metrics Radar Chart
            ax2 = axes[0, 1]
            self._create_metrics_radar(analysis['key_metrics'], ax2)
            
            # 3. Detailed Findings Table
            ax3 = axes[1, 0]
            ax3.axis('tight')
            ax3.axis('off')
            
            table_data = []
            for validator, details in analysis['detailed_findings'].items():
                status = '✅' if details['passed'] else '❌'
                table_data.append([validator, status])
            
            table = ax3.table(cellText=table_data,
                            colLabels=['Validator', 'Status'],
                            cellLoc='left',
                            loc='center')
            table.auto_set_font_size(False)
            table.set_fontsize(10)
            table.scale(1.2, 1.5)
            ax3.set_title('Detailed Validation Results')
            
            # 4. Recommendations
            ax4 = axes[1, 1]
            ax4.axis('off')
            recommendations_text = '\n'.join(analysis['recommendations'][:5])  # Top 5
            ax4.text(0.05, 0.95, 'Key Recommendations:', fontsize=14, fontweight='bold',
                    transform=ax4.transAxes, verticalalignment='top')
            ax4.text(0.05, 0.85, recommendations_text, fontsize=10,
                    transform=ax4.transAxes, verticalalignment='top', wrap=True)
            
            plt.tight_layout()
            
            dashboard_file = save_path / f'validation_summary_dashboard.{self.config.plot_format}'
            plt.savefig(dashboard_file, dpi=self.config.dpi, 
                       bbox_inches='tight', transparent=self.config.transparent_background)
            plt.close()
            
            return str(dashboard_file)
            
        except Exception as e:
            logger.error(f"Error creating summary dashboard: {e}")
            return None
    
    def _create_metrics_radar(self, key_metrics: Dict[str, Any], ax):
        """Create radar chart for key metrics."""
        
        # Select key metrics for radar chart
        radar_metrics = {
            'ROC AUC': key_metrics.get('Verification Accuracy Over Time_final_roc_auc', 0),
            'Separation': key_metrics.get('Genuine-Impostor Separation_separation_gap', 0),
            'Drift Control': 1 - key_metrics.get('Template Drift Robustness_mean_drift', 0),
            'Update Balance': key_metrics.get('Update Stability & Sensitivity_update_frequency', 0)
        }
        
        if not any(radar_metrics.values()):
            ax.text(0.5, 0.5, 'No radar data available', ha='center', va='center', transform=ax.transAxes)
            ax.set_title('Key Metrics Overview')
            return
        
        # Normalize values to 0-1 range
        values = []
        labels = []
        for label, value in radar_metrics.items():
            labels.append(label)
            # Normalize different metrics appropriately
            if label == 'ROC AUC':
                values.append(max(0, min(1, value)))
            elif label == 'Separation':
                values.append(max(0, min(1, value * 2)))  # Scale separation gap
            else:
                values.append(max(0, min(1, value)))
        
        # Create radar chart
        angles = np.linspace(0, 2 * np.pi, len(values), endpoint=False)
        values += values[:1]  # Complete the circle
        angles = np.concatenate((angles, [angles[0]]))
        
        ax.plot(angles, values, 'o-', linewidth=2, label='Gated EMA')
        ax.fill(angles, values, alpha=0.25)
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(labels)
        ax.set_ylim(0, 1)
        ax.set_title('Key Metrics Radar')
        ax.grid(True)
    
    def _plot_verification_accuracy(self, result: ValidationResults, save_path: Path) -> List[str]:
        """Plot verification accuracy over time."""
        
        plots = []
        values = result.values
        
        if not values.get('roc_auc_over_time'):
            return plots
        
        try:
            fig, axes = plt.subplots(2, 2, figsize=(16, 12))
            fig.suptitle('Verification Accuracy Over Time Analysis', fontsize=16, fontweight='bold')
            
            time_windows = values['time_windows']
            
            # ROC AUC over time
            ax1 = axes[0, 0]
            ax1.plot(time_windows, values['roc_auc_over_time'], 'b-o', linewidth=2, markersize=6)
            ax1.set_xlabel('Time Window')
            ax1.set_ylabel('ROC AUC')
            ax1.set_title('ROC AUC Over Time')
            ax1.grid(True, alpha=0.3)
            ax1.set_ylim(0, 1)
            
            # EER over time
            ax2 = axes[0, 1]
            if values['eer_over_time']:
                ax2.plot(time_windows, values['eer_over_time'], 'r-o', linewidth=2, markersize=6)
                ax2.set_xlabel('Time Window')
                ax2.set_ylabel('Equal Error Rate')
                ax2.set_title('EER Over Time (Lower is Better)')
                ax2.grid(True, alpha=0.3)
            
            # Accuracy over time
            ax3 = axes[1, 0]
            if values['accuracy_over_time']:
                ax3.plot(time_windows, values['accuracy_over_time'], 'g-o', linewidth=2, markersize=6)
                ax3.set_xlabel('Time Window')
                ax3.set_ylabel('Accuracy')
                ax3.set_title('Accuracy Over Time')
                ax3.grid(True, alpha=0.3)
                ax3.set_ylim(0, 1)
            
            # Summary statistics
            ax4 = axes[1, 1]
            ax4.axis('off')
            
            final_roc = values['roc_auc_over_time'][-1] if values['roc_auc_over_time'] else 0
            initial_roc = values['roc_auc_over_time'][0] if values['roc_auc_over_time'] else 0
            trend = final_roc - initial_roc
            
            summary_text = f"""
            Performance Summary:
            
            Initial ROC AUC: {initial_roc:.4f}
            Final ROC AUC: {final_roc:.4f}
            Trend: {trend:+.4f}
            
            Validation: {'✅ PASSED' if result.passed else '❌ FAILED'}
            """
            
            ax4.text(0.1, 0.9, summary_text, transform=ax4.transAxes, fontsize=12,
                    verticalalignment='top', bbox=dict(boxstyle="round,pad=0.3", facecolor="lightgray"))
            
            plt.tight_layout()
            
            plot_file = save_path / f'verification_accuracy_over_time.{self.config.plot_format}'
            plt.savefig(plot_file, dpi=self.config.dpi, bbox_inches='tight')
            plt.close()
            
            plots.append(str(plot_file))
            
        except Exception as e:
            logger.error(f"Error creating verification accuracy plots: {e}")
        
        return plots
    
    def _plot_genuine_impostor_separation(self, result: ValidationResults, save_path: Path) -> List[str]:
        """Plot genuine vs impostor score separation."""
        
        plots = []
        values = result.values
        
        if not values.get('genuine_scores') or not values.get('impostor_scores'):
            return plots
        
        try:
            fig, axes = plt.subplots(1, 2, figsize=(16, 6))
            fig.suptitle('Genuine-Impostor Score Separation Analysis', fontsize=16, fontweight='bold')
            
            genuine_scores = values['genuine_scores']
            impostor_scores = values['impostor_scores']
            
            # Distribution plot
            ax1 = axes[0]
            ax1.hist(genuine_scores, bins=30, alpha=0.7, label='Genuine', color='green', density=True)
            ax1.hist(impostor_scores, bins=30, alpha=0.7, label='Impostor', color='red', density=True)
            ax1.set_xlabel('Cosine Similarity Score')
            ax1.set_ylabel('Density')
            ax1.set_title('Score Distribution Comparison')
            ax1.legend()
            ax1.grid(True, alpha=0.3)
            
            # Box plot comparison
            ax2 = axes[1]
            box_data = [genuine_scores, impostor_scores]
            box_labels = ['Genuine', 'Impostor']
            bp = ax2.boxplot(box_data, labels=box_labels, patch_artist=True)
            bp['boxes'][0].set_facecolor('green')
            bp['boxes'][1].set_facecolor('red')
            ax2.set_ylabel('Cosine Similarity Score')
            ax2.set_title('Score Distribution Box Plot')
            ax2.grid(True, alpha=0.3)
            
            # Add statistics
            gap = values.get('separation_gap', 0)
            effect_size = values.get('effect_size', 0)
            
            stats_text = f"Separation Gap: {gap:.4f}\nEffect Size: {effect_size:.2f}"
            ax2.text(0.02, 0.98, stats_text, transform=ax2.transAxes, 
                    verticalalignment='top', bbox=dict(boxstyle="round,pad=0.3", facecolor="lightblue"))
            
            plt.tight_layout()
            
            plot_file = save_path / f'genuine_impostor_separation.{self.config.plot_format}'
            plt.savefig(plot_file, dpi=self.config.dpi, bbox_inches='tight')
            plt.close()
            
            plots.append(str(plot_file))
            
        except Exception as e:
            logger.error(f"Error creating genuine-impostor separation plots: {e}")
        
        return plots
    
    def _plot_template_drift(self, result: ValidationResults, save_path: Path) -> List[str]:
        """Plot template drift analysis."""
        
        plots = []
        values = result.values
        
        if not values.get('per_identity_drift'):
            return plots
        
        try:
            fig, axes = plt.subplots(1, 2, figsize=(16, 6))
            fig.suptitle('Template Drift Robustness Analysis', fontsize=16, fontweight='bold')
            
            # Extract drift data
            drift_data = values['per_identity_drift']
            total_drifts = [data['total_drift'] for data in drift_data.values()]
            drift_rates = [data['drift_rate'] for data in drift_data.values()]
            
            # Drift distribution
            ax1 = axes[0]
            ax1.hist(total_drifts, bins=20, alpha=0.7, color='blue', edgecolor='black')
            ax1.set_xlabel('Total Drift')
            ax1.set_ylabel('Frequency')
            ax1.set_title('Distribution of Total Drift per Identity')
            ax1.grid(True, alpha=0.3)
            
            # Drift rate distribution
            ax2 = axes[1]
            ax2.hist(drift_rates, bins=20, alpha=0.7, color='orange', edgecolor='black')
            ax2.set_xlabel('Drift Rate (per update)')
            ax2.set_ylabel('Frequency')
            ax2.set_title('Distribution of Drift Rates')
            ax2.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
            plot_file = save_path / f'template_drift_analysis.{self.config.plot_format}'
            plt.savefig(plot_file, dpi=self.config.dpi, bbox_inches='tight')
            plt.close()
            
            plots.append(str(plot_file))
            
        except Exception as e:
            logger.error(f"Error creating template drift plots: {e}")
        
        return plots
    
    def _plot_update_stability(self, result: ValidationResults, save_path: Path) -> List[str]:
        """Plot update stability analysis."""
        
        plots = []
        values = result.values
        
        try:
            fig, axes = plt.subplots(1, 2, figsize=(16, 6))
            fig.suptitle('Update Stability & Sensitivity Analysis', fontsize=16, fontweight='bold')
            
            # Update frequency pie chart
            ax1 = axes[0]
            update_freq = values.get('update_frequency', 0)
            rejection_rate = values.get('rejection_rate', 0)
            
            sizes = [update_freq, rejection_rate]
            labels = ['Updates', 'Rejections']
            colors = ['#2ecc71', '#e74c3c']
            
            ax1.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
            ax1.set_title('Update vs Rejection Rate')
            
            # Rejection reasons
            ax2 = axes[1]
            rejection_reasons = values.get('rejection_reasons', {})
            
            if rejection_reasons:
                reasons = list(rejection_reasons.keys())[:5]  # Top 5 reasons
                counts = [rejection_reasons[reason] for reason in reasons]
                
                ax2.barh(reasons, counts, color='lightcoral')
                ax2.set_xlabel('Count')
                ax2.set_title('Top Rejection Reasons')
                ax2.grid(True, alpha=0.3)
            else:
                ax2.text(0.5, 0.5, 'No rejection data available', 
                        ha='center', va='center', transform=ax2.transAxes)
                ax2.set_title('Rejection Reasons')
            
            plt.tight_layout()
            
            plot_file = save_path / f'update_stability_analysis.{self.config.plot_format}'
            plt.savefig(plot_file, dpi=self.config.dpi, bbox_inches='tight')
            plt.close()
            
            plots.append(str(plot_file))
            
        except Exception as e:
            logger.error(f"Error creating update stability plots: {e}")
        
        return plots
    
    def _plot_ablation_study(self, result: ValidationResults, save_path: Path) -> List[str]:
        """Plot ablation study comparison."""
        
        plots = []
        values = result.values
        
        if not values.get('comparison_table'):
            return plots
        
        try:
            fig, axes = plt.subplots(1, 2, figsize=(16, 6))
            fig.suptitle('Ablation Study Strategy Comparison', fontsize=16, fontweight='bold')
            
            comparison_table = values['comparison_table']
            strategies = values['strategies']
            
            # ROC AUC comparison
            ax1 = axes[0]
            if 'roc_auc' in comparison_table:
                roc_data = comparison_table['roc_auc']
                strategy_names = list(roc_data.keys())
                roc_values = list(roc_data.values())
                
                bars = ax1.bar(strategy_names, roc_values, color=['green' if 'gated' in s.lower() else 'blue' for s in strategy_names])
                ax1.set_ylabel('ROC AUC')
                ax1.set_title('ROC AUC Comparison Across Strategies')
                ax1.set_ylim(0, 1)
                plt.setp(ax1.get_xticklabels(), rotation=45, ha="right")
                
                # Highlight best performing
                best_idx = np.argmax(roc_values)
                bars[best_idx].set_color('gold')
            
            # Strategy ranking
            ax2 = axes[1]
            rankings = values.get('rankings', {})
            
            if 'roc_auc' in rankings:
                ranking = rankings['roc_auc']
                y_pos = np.arange(len(ranking))
                
                colors = ['gold' if i == 0 else 'silver' if i == 1 else 'lightsalmon' for i in range(len(ranking))]
                ax2.barh(y_pos, [len(ranking) - i for i in range(len(ranking))], color=colors)
                ax2.set_yticks(y_pos)
                ax2.set_yticklabels(ranking)
                ax2.set_xlabel('Ranking Score')
                ax2.set_title('Strategy Performance Ranking')
                ax2.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
            plot_file = save_path / f'ablation_study_comparison.{self.config.plot_format}'
            plt.savefig(plot_file, dpi=self.config.dpi, bbox_inches='tight')
            plt.close()
            
            plots.append(str(plot_file))
            
        except Exception as e:
            logger.error(f"Error creating ablation study plots: {e}")
        
        return plots 