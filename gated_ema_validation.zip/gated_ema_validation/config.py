"""
Configuration classes for Gated EMA Validation Framework
========================================================

This module defines all configuration parameters for the validation framework.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Union
import numpy as np


@dataclass
class GatedEMAConfig:
    """Configuration for Gated EMA algorithm parameters."""
    
    # Core Gated EMA parameters
    alpha: float = 0.3  # EMA decay factor (0 < α ≤ 1)
    confidence_threshold: float = 0.7  # Minimum cosine similarity for updates
    
    # Advanced parameters
    adaptive_alpha: bool = False  # Whether to use adaptive alpha
    min_alpha: float = 0.1  # Minimum alpha for adaptive mode
    max_alpha: float = 0.5  # Maximum alpha for adaptive mode
    
    # Update constraints
    max_updates_per_session: int = 10  # Maximum updates per authentication session
    cooldown_period: int = 5  # Minimum time steps between updates
    
    # Quality control
    min_embedding_norm: float = 0.1  # Minimum embedding magnitude
    max_drift_per_update: float = 0.5  # Maximum allowed drift per update
    
    def __post_init__(self):
        """Validate configuration parameters."""
        if not (0 < self.alpha <= 1):
            raise ValueError("Alpha must be in range (0, 1]")
        if not (0 <= self.confidence_threshold <= 1):
            raise ValueError("Confidence threshold must be in range [0, 1]")
        if self.adaptive_alpha and (self.min_alpha >= self.max_alpha):
            raise ValueError("min_alpha must be less than max_alpha")


@dataclass
class ValidationConfig:
    """Configuration for validation experiments and metrics."""
    
    # Dataset configuration
    dataset_root: str = "data/cacd_split/cacd_split"
    metadata_path: str = "data/CACD_features_sex.csv"
    embedding_model: str = "Facenet512"
    
    # Experimental setup
    min_images_per_identity: int = 10
    min_age_span: int = 3
    max_identities: int = 100  # For faster validation
    temporal_split_ratio: float = 0.7  # Train/test split by time
    
    # Validation metrics configuration
    n_genuine_pairs: int = 1000
    n_impostor_pairs: int = 10000
    bootstrap_samples: int = 1000
    confidence_level: float = 0.95
    
    # Thresholds for analysis
    far_points: List[float] = field(default_factory=lambda: [0.001, 0.01, 0.1])
    
    # Output configuration
    results_dir: str = "validation_results"
    save_plots: bool = True
    save_detailed_logs: bool = True
    plot_format: str = "png"
    
    # Comparison strategies
    comparison_strategies: List[str] = field(default_factory=lambda: [
        "static", "ema_fixed", "gated_ema"
    ])
    
    # Strategy-specific parameters
    ema_alphas: List[float] = field(default_factory=lambda: [0.1, 0.3, 0.5, 0.7])
    confidence_thresholds: List[float] = field(default_factory=lambda: [0.5, 0.7, 0.8, 0.9])


@dataclass 
class VisualizationConfig:
    """Configuration for visualization and plotting."""
    
    # Figure settings
    figure_size: tuple = (12, 8)
    dpi: int = 300
    style: str = "seaborn-v0_8"
    color_palette: str = "husl"
    
    # Font settings
    title_fontsize: int = 16
    label_fontsize: int = 14
    legend_fontsize: int = 12
    tick_fontsize: int = 10
    
    # Plot-specific settings
    show_confidence_intervals: bool = True
    show_grid: bool = True
    transparent_background: bool = False
    
    # Animation settings (for temporal plots)
    animation_fps: int = 2
    animation_duration: int = 10


@dataclass
class RealWorldSimulationConfig:
    """Configuration for real-world simulation scenarios."""
    
    # Authentication session simulation
    sessions_per_identity: int = 20
    authentications_per_session: int = 5
    session_time_span_days: int = 30
    
    # Noise and variation simulation
    add_gaussian_noise: bool = True
    noise_std: float = 0.05
    simulate_lighting_changes: bool = True
    simulate_pose_variations: bool = True
    
    # Attack simulation
    simulate_spoofing_attacks: bool = False
    spoofing_success_rate: float = 0.1
    
    # Environmental factors
    quality_degradation_rate: float = 0.02  # Per time step
    template_aging_factor: float = 0.001


@dataclass
class ExperimentConfig:
    """Master configuration combining all sub-configurations."""
    
    gated_ema: GatedEMAConfig = field(default_factory=GatedEMAConfig)
    validation: ValidationConfig = field(default_factory=ValidationConfig)
    visualization: VisualizationConfig = field(default_factory=VisualizationConfig)
    real_world: RealWorldSimulationConfig = field(default_factory=RealWorldSimulationConfig)
    
    # Experiment metadata
    experiment_name: str = "gated_ema_validation"
    description: str = "Comprehensive validation of Gated EMA template updates"
    random_seed: int = 42
    
    # Computational settings
    n_jobs: int = -1  # Number of parallel jobs
    use_gpu: bool = False
    batch_size: int = 32
    
    def __post_init__(self):
        """Set random seed for reproducibility."""
        np.random.seed(self.random_seed)


# Predefined configuration presets
QUICK_VALIDATION_CONFIG = ExperimentConfig(
    validation=ValidationConfig(
        max_identities=20,
        n_genuine_pairs=100,
        n_impostor_pairs=1000,
        bootstrap_samples=100
    )
)

COMPREHENSIVE_VALIDATION_CONFIG = ExperimentConfig(
    validation=ValidationConfig(
        max_identities=500,
        n_genuine_pairs=5000,
        n_impostor_pairs=50000,
        bootstrap_samples=2000
    )
)

PRODUCTION_VALIDATION_CONFIG = ExperimentConfig(
    validation=ValidationConfig(
        max_identities=1000,
        n_genuine_pairs=10000,
        n_impostor_pairs=100000,
        bootstrap_samples=5000
    ),
    real_world=RealWorldSimulationConfig(
        sessions_per_identity=50,
        authentications_per_session=10
    )
) 