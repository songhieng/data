"""
Optimized CACD Test with Real Face Data
Efficient processing for larger datasets
"""

import numpy as np
import cv2
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

from enhanced_ema_study import TemplateState, StaticTemplateStrategy, EMATemplateStrategy, GatedEMATemplateStrategy
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import normalize
import time

def extract_efficient_features(image_path):
    """Extract features efficiently with minimal processing"""
    try:
        # Read and resize image quickly
        image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
        if image is None:
            return None
        
        # Quick resize
        image = cv2.resize(image, (32, 32))
        
        # Fast feature extraction
        features = []
        
        # Color statistics (very fast)
        features.extend([
            np.mean(image),
            np.std(image),
            np.mean(image[:,:,0]),  # B channel
            np.mean(image[:,:,1]),  # G channel  
            np.mean(image[:,:,2]),  # R channel
            np.std(image[:,:,0]),
            np.std(image[:,:,1]),
            np.std(image[:,:,2])
        ])
        
        # Simple texture (edge density only)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 50, 150)
        features.append(np.sum(edges > 0) / (32 * 32))
        
        # Pad to 512 with small random noise
        features = np.array(features, dtype=np.float32)
        if len(features) < 512:
            padding = np.random.randn(512 - len(features)).astype(np.float32) * 0.01
            features = np.concatenate([features, padding])
        
        # Normalize
        norm = np.linalg.norm(features)
        if norm > 0:
            features = features / norm
        
        return features
        
    except Exception as e:
        return None

def optimized_test():
    """Optimized test with 10 people and 15 images each"""
    print("="*60)
    print("OPTIMIZED CACD TEST - REAL FACE DATA ANALYSIS")
    print("="*60)
    
    # Load CACD data efficiently
    cacd_path = Path("../data/cacd_split/cacd_split")
    if not cacd_path.exists():
        print(f"ERROR: CACD directory not found: {cacd_path}")
        return
    
    # Get first 10 people for balanced dataset
    person_dirs = [d for d in cacd_path.iterdir() if d.is_dir()][:10]
    
    print(f"Processing {len(person_dirs)} celebrities...")
    print("Extracting face features...")
    
    embeddings = []
    labels = []
    person_names = []
    
    start_time = time.time()
    
    for person_idx, person_dir in enumerate(person_dirs):
        print(f"  [{person_idx+1:2d}/10] {person_dir.name[:20]:<20}", end="")
        
        # Get image files efficiently
        image_files = list(person_dir.glob('*.jpg'))[:15]  # First 15 images
        
        person_embeddings = []
        processed = 0
        
        for img_file in image_files:
            embedding = extract_efficient_features(img_file)
            if embedding is not None:
                person_embeddings.append(embedding)
                processed += 1
            
            if processed >= 15:  # Limit to 15 per person
                break
        
        if len(person_embeddings) >= 5:  # Need at least 5 images
            embeddings.extend(person_embeddings)
            labels.extend([person_idx] * len(person_embeddings))
            person_names.append(person_dir.name)
            print(f" -> {len(person_embeddings):2d} images")
        else:
            print(f" -> skipped (only {len(person_embeddings)} images)")
    
    embeddings = np.array(embeddings, dtype=np.float32)
    labels = np.array(labels)
    
    processing_time = time.time() - start_time
    
    print(f"\nDataset Summary:")
    print(f"  - Total embeddings: {len(embeddings)}")
    print(f"  - Celebrities: {len(person_names)}")
    print(f"  - Processing time: {processing_time:.1f} seconds")
    print(f"  - Celebrities: {person_names}")
    
    # Create verification pairs efficiently
    print("\nCreating verification pairs...")
    pairs = []
    
    # Genuine pairs (same person)
    genuine_count = 0
    for label in np.unique(labels):
        indices = np.where(labels == label)[0]
        if len(indices) >= 2:
            # Create 4 pairs per person max
            for i in range(min(4, len(indices))):
                for j in range(i+1, min(i+3, len(indices))):
                    pairs.append((indices[i], indices[j], 1))
                    genuine_count += 1
    
    # Impostor pairs (different people) - match genuine count
    impostor_count = 0
    unique_labels = np.unique(labels)
    while impostor_count < genuine_count:
        label1, label2 = np.random.choice(unique_labels, 2, replace=False)
        idx1 = np.random.choice(np.where(labels == label1)[0])
        idx2 = np.random.choice(np.where(labels == label2)[0])
        pairs.append((idx1, idx2, 0))
        impostor_count += 1
    
    print(f"  - Genuine pairs: {genuine_count}")
    print(f"  - Impostor pairs: {impostor_count}")
    print(f"  - Total pairs: {len(pairs)}")
    
    # Test strategies
    strategies = {
        'Static': StaticTemplateStrategy(),
        'EMA': EMATemplateStrategy(alpha=0.3),  
        'Gated EMA': GatedEMATemplateStrategy(alpha=0.3, confidence_threshold=0.7)
    }
    
    results = {}
    
    print(f"\nTesting Template Update Strategies:")
    print("-" * 40)
    
    for name, strategy in strategies.items():
        print(f"\n{name} Strategy:")
        
        start_time = time.time()
        
        # Initialize templates for each person
        templates = {}
        for label in np.unique(labels):
            indices = np.where(labels == label)[0]
            initial_embedding = embeddings[indices[0]]
            templates[label] = TemplateState(
                embedding=initial_embedding,
                confidence=0.8,
                age=0
            )
        
        # Simulate temporal updates
        updates = 0
        decisions = 0
        
        for label in np.unique(labels):
            indices = np.where(labels == label)[0]
            template = templates[label]
            
            # Process subsequent images as updates
            for age_idx, idx in enumerate(indices[1:], 1):
                new_embedding = embeddings[idx]
                
                # Apply strategy update
                updated_template = strategy.update_template(
                    template, new_embedding, 0.8, age_idx
                )
                
                decisions += 1
                
                # Check if embedding changed (update occurred)
                if not np.allclose(template.embedding, updated_template.embedding, atol=1e-6):
                    updates += 1
                
                templates[label] = updated_template
                template = updated_template
        
        # Verification testing
        scores = []
        true_labels = []
        
        for idx1, idx2, label in pairs:
            label1, label2 = labels[idx1], labels[idx2]
            
            # Use current template embeddings
            emb1 = templates[label1].embedding
            emb2 = templates[label2].embedding
            
            # Cosine similarity
            score = np.dot(emb1, emb2)
            scores.append(score)
            true_labels.append(label)
        
        # Calculate performance metrics
        auc = roc_auc_score(true_labels, scores)
        update_rate = updates / max(1, decisions)
        processing_time = time.time() - start_time
        
        results[name] = {
            'auc': auc,
            'updates': updates,
            'decisions': decisions, 
            'update_rate': update_rate,
            'processing_time': processing_time,
            'scores': scores
        }
        
        print(f"  - ROC AUC: {auc:.4f}")
        print(f"  - Template Updates: {updates}/{decisions} ({update_rate:.1%})")
        print(f"  - Processing Time: {processing_time:.2f}s")
    
    # Comprehensive results analysis
    print("\n" + "="*60)
    print("COMPREHENSIVE RESULTS ANALYSIS")
    print("="*60)
    
    # Performance ranking
    sorted_results = sorted(results.items(), key=lambda x: x[1]['auc'], reverse=True)
    
    print(f"\nPerformance Ranking (by ROC AUC):")
    for rank, (name, result) in enumerate(sorted_results, 1):
        status = "[BEST]" if rank == 1 else f"[#{rank}]"
        print(f"  {status} {name}:")
        print(f"      ROC AUC: {result['auc']:.4f}")
        print(f"      Update Rate: {result['update_rate']:.1%}")
        print(f"      Processing: {result['processing_time']:.2f}s")
    
    # Key findings
    print(f"\nKey Findings:")
    
    if 'Gated EMA' in results and 'Static' in results:
        gated_auc = results['Gated EMA']['auc']
        static_auc = results['Static']['auc']
        improvement = gated_auc - static_auc
        percent_improvement = (improvement / static_auc) * 100
        
        print(f"  • Gated EMA vs Static Templates:")
        print(f"    - Accuracy improvement: {improvement:+.4f} ({percent_improvement:+.1f}%)")
        
        if improvement > 0.01:  # Significant improvement
            print(f"    - [CONCLUSION] Gated EMA SIGNIFICANTLY ENHANCES verification accuracy!")
        elif improvement > 0:
            print(f"    - [CONCLUSION] Gated EMA provides slight accuracy enhancement")
        else:
            print(f"    - [CONCLUSION] No accuracy improvement with Gated EMA on this dataset")
    
    if 'Gated EMA' in results and 'EMA' in results:
        gated_auc = results['Gated EMA']['auc']
        ema_auc = results['EMA']['auc']
        gated_updates = results['Gated EMA']['update_rate']
        ema_updates = results['EMA']['update_rate']
        
        print(f"  • Gated EMA vs Standard EMA:")
        print(f"    - Accuracy difference: {gated_auc - ema_auc:+.4f}")
        print(f"    - Update selectivity: {gated_updates:.1%} vs {ema_updates:.1%}")
        
        if gated_auc >= ema_auc and gated_updates < ema_updates:
            print(f"    - [CONCLUSION] Gated EMA provides better selectivity with equal/better accuracy!")
    
    # Statistical insights
    genuine_scores = [score for score, label in zip(results['Static']['scores'], true_labels) if label == 1]
    impostor_scores = [score for score, label in zip(results['Static']['scores'], true_labels) if label == 0]
    
    print(f"\nScore Distribution Analysis (Static baseline):")
    print(f"  • Genuine pairs: μ={np.mean(genuine_scores):.3f}, σ={np.std(genuine_scores):.3f}")
    print(f"  • Impostor pairs: μ={np.mean(impostor_scores):.3f}, σ={np.std(impostor_scores):.3f}")
    print(f"  • Separation gap: {np.mean(genuine_scores) - np.mean(impostor_scores):.3f}")
    
    # Save comprehensive results
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    results_file = f"optimized_cacd_results_{timestamp}.txt"
    
    with open(results_file, "w") as f:
        f.write("OPTIMIZED CACD TEST RESULTS - REAL FACE DATA\n")
        f.write("="*50 + "\n\n")
        f.write(f"Dataset: {len(embeddings)} embeddings from {len(person_names)} celebrities\n")
        f.write(f"Celebrities: {person_names}\n")
        f.write(f"Verification pairs: {len(pairs)} ({genuine_count} genuine, {impostor_count} impostor)\n\n")
        
        f.write("Performance Results:\n")
        f.write("-" * 20 + "\n")
        for name, result in sorted_results:
            f.write(f"{name}:\n")
            f.write(f"  ROC AUC: {result['auc']:.4f}\n")
            f.write(f"  Update Rate: {result['update_rate']:.1%}\n")
            f.write(f"  Processing Time: {result['processing_time']:.2f}s\n\n")
        
        if 'Gated EMA' in results and 'Static' in results:
            improvement = results['Gated EMA']['auc'] - results['Static']['auc']
            f.write(f"Key Finding:\n")
            f.write(f"Gated EMA vs Static improvement: {improvement:+.4f} ({improvement/results['Static']['auc']*100:+.1f}%)\n")
    
    print(f"\nDetailed results saved to: {results_file}")
    print(f"\n[SUCCESS] Real CACD face data analysis completed!")

if __name__ == "__main__":
    optimized_test() 