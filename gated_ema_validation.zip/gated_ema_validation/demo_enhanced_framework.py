#!/usr/bin/env python3
"""
Enhanced EMA Validation Framework Demo
=====================================

This demo script shows how to use the enhanced EMA validation framework
with separate validation components for comprehensive analysis.

Usage:
    python demo_enhanced_framework.py [--quick] [--synthetic] [--real-data]
"""

import argparse
import logging
import numpy as np
import pandas as pd
from pathlib import Path
import time
from typing import Dict, Any, List, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Import the enhanced framework
try:
    from enhanced_ema_study import EnhancedEMADriftExperiment, run_enhanced_experiment
    from enhanced_ema_study import TemplateState, StaticTemplateStrategy, EMATemplateStrategy, GatedEMATemplateStrategy
except ImportError:
    logger.error("Could not import enhanced framework. Make sure all files are in the correct location.")
    exit(1)


def create_synthetic_dataset(n_identities: int = 20, 
                           n_images_per_identity: int = 15,
                           embedding_dim: int = 512,
                           age_range: Tuple[int, int] = (20, 60)) -> pd.DataFrame:
    """Create synthetic dataset for demonstration."""
    
    logger.info(f"Creating synthetic dataset: {n_identities} identities, {n_images_per_identity} images each")
    
    data = []
    
    for identity_id in range(1, n_identities + 1):
        # Create base embedding for this identity
        np.random.seed(identity_id * 42)  # Deterministic but different per identity
        base_embedding = np.random.randn(embedding_dim)
        base_embedding = base_embedding / np.linalg.norm(base_embedding)
        
        # Generate ages for this identity
        min_age, max_age = age_range
        ages = np.linspace(min_age, max_age, n_images_per_identity)
        ages = ages + np.random.normal(0, 1, len(ages))  # Add some noise
        ages = np.clip(ages, min_age, max_age).astype(int)
        
        for i, age in enumerate(ages):
            # Create slight variations of the base embedding
            noise_level = 0.1  # Small noise to simulate natural variation
            embedding_variation = base_embedding + np.random.normal(0, noise_level, embedding_dim)
            embedding_variation = embedding_variation / np.linalg.norm(embedding_variation)
            
            # Create filename
            celebrity_name = f"Person{identity_id:03d}"
            filename = f"{age:02d}_{celebrity_name}_{i:04d}.jpg"
            
            data.append({
                'name': filename,
                'identity': identity_id,
                'celebrity': celebrity_name,
                'age': age,
                'embedding': embedding_variation
            })
    
    df = pd.DataFrame(data)
    logger.info(f"Created synthetic dataset with {len(df)} images")
    return df


def run_quick_demo():
    """Run a quick demonstration with minimal data."""
    
    logger.info("🚀 Running Quick Demo")
    logger.info("=" * 50)
    
    # Create small synthetic dataset
    synthetic_data = create_synthetic_dataset(
        n_identities=5,
        n_images_per_identity=8,
        embedding_dim=128
    )
    
    # Save synthetic data to temporary file
    temp_metadata_path = Path("temp_synthetic_metadata.csv")
    synthetic_data.to_csv(temp_metadata_path, index=False)
    
    # Configuration for quick demo
    config = {
        'metadata_path': str(temp_metadata_path),
        'dataset_root': 'synthetic_data',  # Not used for synthetic data
        'ema_alpha': 0.3,
        'gated_threshold': 0.7,
        'min_images_per_identity': 5,
        'min_age_span': 10,
        'max_identities': 5,
        'results_dir': 'quick_demo_results',
        'use_synthetic_embeddings': True  # Flag to use embeddings from CSV
    }
    
    try:
        # Create experiment
        experiment = EnhancedEMADriftExperiment(config)
        
        # Override the embedding extraction to use synthetic data
        experiment.synthetic_data = synthetic_data
        experiment.extract_simple_embedding = lambda path: experiment._get_synthetic_embedding(path)
        
        # Add method to get synthetic embeddings
        def _get_synthetic_embedding(self, image_path: str) -> np.ndarray:
            # Extract identity and image info from path
            filename = Path(image_path).name
            matching_rows = self.synthetic_data[self.synthetic_data['name'] == filename]
            
            if not matching_rows.empty:
                return matching_rows.iloc[0]['embedding']
            else:
                # Fallback to random embedding
                return np.random.randn(128) / np.linalg.norm(np.random.randn(128))
        
        experiment._get_synthetic_embedding = _get_synthetic_embedding.__get__(experiment, EnhancedEMADriftExperiment)
        
        # Run experiment
        results = experiment.run_comprehensive_experiment()
        
        # Display results summary
        print("\n" + "="*60)
        print("QUICK DEMO RESULTS SUMMARY")
        print("="*60)
        
        strategy_results = results.get('strategy_results', {})
        for strategy_name, strategy_data in strategy_results.items():
            validation_results = strategy_data.get('validation_results', {})
            
            print(f"\n{strategy_name.upper()} Strategy:")
            print("-" * 30)
            
            for validator_name, result in validation_results.items():
                status = "[PASSED]" if result.get('passed', False) else "[FAILED]"
                print(f"  {validator_name.replace('_', ' ').title()}: {status}")
        
        # Show comparative insights
        comparative_analysis = results.get('comparative_analysis', {})
        insights = comparative_analysis.get('insights', [])
        
        if insights:
            print(f"\n[KEY INSIGHTS]:")
            for insight in insights:
                print(f"  • {insight}")
        
        print(f"\n📁 Detailed results saved to: {config['results_dir']}/")
        
    except Exception as e:
        logger.error(f"Error in quick demo: {e}")
        raise
    finally:
        # Cleanup
        if temp_metadata_path.exists():
            temp_metadata_path.unlink()


def run_comprehensive_demo():
    """Run comprehensive demonstration with full validation suite."""
    
    logger.info("🚀 Running Comprehensive Demo")
    logger.info("=" * 50)
    
    # Create larger synthetic dataset
    synthetic_data = create_synthetic_dataset(
        n_identities=20,
        n_images_per_identity=12,
        embedding_dim=512
    )
    
    # Save synthetic data
    temp_metadata_path = Path("temp_comprehensive_metadata.csv")
    synthetic_data.to_csv(temp_metadata_path, index=False)
    
    # Configuration for comprehensive demo
    config = {
        'metadata_path': str(temp_metadata_path),
        'dataset_root': 'synthetic_data',
        'ema_alpha': 0.3,
        'gated_threshold': 0.7,
        'min_images_per_identity': 8,
        'min_age_span': 15,
        'max_identities': 20,
        'results_dir': 'comprehensive_demo_results',
        'use_synthetic_embeddings': True,
        # Additional validation parameters
        'alpha_values': [0.1, 0.3, 0.5, 0.7],
        'threshold_values': [0.5, 0.6, 0.7, 0.8]
    }
    
    try:
        # Create and run experiment
        experiment = EnhancedEMADriftExperiment(config)
        
        # Override embedding extraction for synthetic data
        experiment.synthetic_data = synthetic_data
        experiment.extract_simple_embedding = lambda path: experiment._get_synthetic_embedding(path)
        
        def _get_synthetic_embedding(self, image_path: str) -> np.ndarray:
            filename = Path(image_path).name
            matching_rows = self.synthetic_data[self.synthetic_data['name'] == filename]
            
            if not matching_rows.empty:
                return matching_rows.iloc[0]['embedding']
            else:
                return np.random.randn(512) / np.linalg.norm(np.random.randn(512))
        
        experiment._get_synthetic_embedding = _get_synthetic_embedding.__get__(experiment, EnhancedEMADriftExperiment)
        
        # Run comprehensive experiment
        results = experiment.run_comprehensive_experiment()
        
        # Generate detailed report
        _generate_demo_report(results, config)
        
    except Exception as e:
        logger.error(f"Error in comprehensive demo: {e}")
        raise
    finally:
        # Cleanup
        if temp_metadata_path.exists():
            temp_metadata_path.unlink()


def run_real_data_demo():
    """Run demonstration with real CACD data if available."""
    
    logger.info("🚀 Running Real Data Demo")
    logger.info("=" * 50)
    
    # Check if real data is available
    metadata_path = Path("../data/CACD_features_sex.csv")
    dataset_root = Path("../data/cacd_split/cacd_split")
    
    if not metadata_path.exists():
        logger.warning("Real CACD metadata not found. Please ensure data/CACD_features_sex.csv exists.")
        logger.info("Falling back to synthetic data demo...")
        run_comprehensive_demo()
        return
    
    if not dataset_root.exists():
        logger.warning("Real CACD dataset not found. Please ensure data/cacd_split/cacd_split exists.")
        logger.info("Falling back to synthetic data demo...")
        run_comprehensive_demo()
        return
    
    # Configuration for real data
    config = {
        'metadata_path': str(metadata_path),
        'dataset_root': str(dataset_root),
        'ema_alpha': 0.3,
        'gated_threshold': 0.7,
        'min_images_per_identity': 10,
        'min_age_span': 5,
        'max_identities': 30,  # Limit for demo
        'results_dir': 'real_data_demo_results'
    }
    
    try:
        # Run experiment with real data
        results = run_enhanced_experiment(config)
        
        # Generate detailed report
        _generate_demo_report(results, config)
        
        logger.info("✅ Real data demo completed successfully!")
        
    except Exception as e:
        logger.error(f"Error in real data demo: {e}")
        raise


def _generate_demo_report(results: Dict[str, Any], config: Dict[str, Any]):
    """Generate a comprehensive demo report."""
    
    print("\n" + "="*80)
    print("COMPREHENSIVE DEMO RESULTS")
    print("="*80)
    
    # Configuration summary
    print(f"\nCONFIGURATION:")
    print(f"- EMA Alpha: {config.get('ema_alpha', 0.3)}")
    print(f"- Gated Threshold: {config.get('gated_threshold', 0.7)}")
    print(f"- Max Identities: {config.get('max_identities', 20)}")
    print(f"- Results Directory: {config.get('results_dir', 'results')}")
    
    # Strategy performance comparison
    strategy_results = results.get('strategy_results', {})
    comparative_analysis = results.get('comparative_analysis', {})
    
    print(f"\nSTRATEGY PERFORMANCE COMPARISON:")
    print("-" * 40)
    
    performance_comparison = comparative_analysis.get('performance_comparison', {})
    for strategy_name, metrics in performance_comparison.items():
        print(f"\n{strategy_name.upper()}:")
        print(f"  Final ROC AUC: {metrics.get('final_roc_auc', 0):.4f}")
        print(f"  ROC AUC Change: {metrics.get('roc_auc_improvement', 0):+.4f}")
        print(f"  Separation Gap: {metrics.get('separation_gap', 0):.4f}")
        print(f"  Mean Drift: {metrics.get('mean_drift', 0):.4f}")
    
    # Strategy rankings
    rankings = comparative_analysis.get('strategy_rankings', {})
    if rankings:
        print(f"\nSTRATEGY RANKINGS:")
        print("-" * 20)
        
        for metric, ranking in rankings.items():
            print(f"\n{metric.upper()}:")
            for i, strategy in enumerate(ranking, 1):
                print(f"  {i}. {strategy.upper()}")
    
    # Key insights
    insights = comparative_analysis.get('insights', [])
    if insights:
        print(f"\nKEY INSIGHTS:")
        print("-" * 15)
        for insight in insights:
            print(f"• {insight}")
    
    # Validation summary
    print(f"\nVALIDATION SUMMARY:")
    print("-" * 20)
    
    for strategy_name, strategy_data in strategy_results.items():
        validation_results = strategy_data.get('validation_results', {})
        
        print(f"\n{strategy_name.upper()}:")
        total_validations = len(validation_results)
        passed_validations = sum(1 for result in validation_results.values() if result.get('passed', False))
        
        print(f"  Validations Passed: {passed_validations}/{total_validations}")
        
        for validator_name, result in validation_results.items():
            status = "✅" if result.get('passed', False) else "❌"
            print(f"  {status} {validator_name.replace('_', ' ').title()}")
    
    # Performance over time analysis
    print(f"\nPERFORMANCE OVER TIME ANALYSIS:")
    print("-" * 35)
    
    best_strategy = None
    best_improvement = -float('inf')
    
    for strategy_name, metrics in performance_comparison.items():
        improvement = metrics.get('roc_auc_improvement', 0)
        if improvement > best_improvement:
            best_improvement = improvement
            best_strategy = strategy_name
    
    if best_strategy:
        if best_improvement > 0.01:
            print(f"✅ {best_strategy.upper()} shows best performance improvement over time (+{best_improvement:.3f})")
        elif best_improvement < -0.01:
            print(f"⚠️ All strategies show performance degradation over time")
        else:
            print(f"📊 All strategies maintain stable performance over time")
    
    # Recommendations
    print(f"\nRECOMMENDATIONS:")
    print("-" * 15)
    
    # Based on rankings and performance
    if rankings.get('roc_auc'):
        best_roc_strategy = rankings['roc_auc'][0]
        print(f"• For best verification accuracy: Use {best_roc_strategy.upper()}")
    
    if rankings.get('drift_control'):
        best_drift_strategy = rankings['drift_control'][0]
        print(f"• For best drift control: Use {best_drift_strategy.upper()}")
    
    # Gated EMA specific recommendation
    gated_ema_metrics = performance_comparison.get('gated_ema', {})
    if gated_ema_metrics:
        gated_roc = gated_ema_metrics.get('final_roc_auc', 0)
        gated_improvement = gated_ema_metrics.get('roc_auc_improvement', 0)
        
        if gated_roc > 0.9 and gated_improvement > 0:
            print("• ✅ Gated EMA is recommended - shows excellent performance and improvement")
        elif gated_roc > 0.8:
            print("• 📊 Gated EMA is acceptable - shows good performance")
        else:
            print("• ⚠️ Gated EMA not recommended - consider alternative strategies")
    
    print(f"\n📁 Detailed results and visualizations saved to: {config.get('results_dir', 'results')}/")
    print(f"⏱️ Total execution time: {results.get('execution_time', 0):.2f} seconds")


def main():
    """Main demo function."""
    
    parser = argparse.ArgumentParser(description="Enhanced EMA Validation Framework Demo")
    parser.add_argument('--quick', action='store_true', help='Run quick demo with minimal data')
    parser.add_argument('--synthetic', action='store_true', help='Run comprehensive demo with synthetic data')
    parser.add_argument('--real-data', action='store_true', help='Run demo with real CACD data')
    
    args = parser.parse_args()
    
    print("🎯 Enhanced EMA Validation Framework Demo")
    print("=" * 50)
    print("This demo showcases the comprehensive validation framework")
    print("for EMA and Gated EMA template update strategies.")
    print()
    
    start_time = time.time()
    
    try:
        if args.quick:
            run_quick_demo()
        elif args.synthetic:
            run_comprehensive_demo()
        elif args.real_data:
            run_real_data_demo()
        else:
            # Default: run quick demo
            logger.info("No specific demo type specified. Running quick demo...")
            run_quick_demo()
        
        end_time = time.time()
        print(f"\n🎉 Demo completed successfully in {end_time - start_time:.2f} seconds!")
        
    except KeyboardInterrupt:
        print("\n⚠️ Demo interrupted by user")
    except Exception as e:
        logger.error(f"Demo failed with error: {e}")
        raise


if __name__ == "__main__":
    main() 