"""
Enhanced EMA Template Drift Study
=================================

This module provides an enhanced experimental framework for evaluating EMA
and Gated EMA template update strategies with comprehensive validation
components focusing on performance over time analysis.
"""

import numpy as np
import pandas as pd
import os
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import matplotlib.pyplot as plt
import time

# Import validation components
import importlib
import sys
from pathlib import Path

# Add current directory to path for imports
current_dir = Path(__file__).parent
if str(current_dir) not in sys.path:
    sys.path.insert(0, str(current_dir))

# Import validators using importlib to handle numeric prefixes
validator_modules = {}
try:
    validator_modules['accuracy'] = importlib.import_module('1_Face_Verification_Accuracy_Over_Time')
    validator_modules['separation'] = importlib.import_module('2_Genuine_Impostor_Separation')  
    validator_modules['drift'] = importlib.import_module('3_Template_Drift_Robustness')
    
    FaceVerificationAccuracyOverTimeValidator = validator_modules['accuracy'].FaceVerificationAccuracyOverTimeValidator
    GenuineImpostorSeparationValidator = validator_modules['separation'].GenuineImpostorSeparationValidator
    TemplateDriftRobustnessValidator = validator_modules['drift'].TemplateDriftRobustnessValidator
    
except ImportError as e:
    print(f"Warning: Could not import validators: {e}")
    # Create dummy validators for testing
    class DummyValidator:
        def __init__(self, config):
            pass
        def validate(self, *args, **kwargs):
            return {'metric_name': 'Dummy', 'values': {}, 'summary': 'Dummy validator', 'passed': True}
    
    FaceVerificationAccuracyOverTimeValidator = DummyValidator
    GenuineImpostorSeparationValidator = DummyValidator
    TemplateDriftRobustnessValidator = DummyValidator

logger = logging.getLogger(__name__)


class TemplateState:
    """Enhanced template state for tracking drift and performance."""
    
    def __init__(self, embedding: np.ndarray, confidence: float = 0.8, age: int = 0):
        self.embedding = embedding / np.linalg.norm(embedding)  # Normalize
        self.confidence = confidence
        self.age_at_creation = age
        self.current_age = age
        self.update_count = 0
        self.last_update_age = age
        self.creation_time = time.time()
        
        # Drift tracking
        self.total_drift = 0.0
        self.drift_history = []
        self.update_magnitudes = []
        self.confidence_history = [confidence]


class TemplateUpdateStrategy:
    """Base class for template update strategies."""
    
    def update_template(self, current_template: TemplateState, 
                       new_embedding: np.ndarray, 
                       new_confidence: float,
                       age: int) -> TemplateState:
        raise NotImplementedError
    
    def get_strategy_name(self) -> str:
        raise NotImplementedError


class StaticTemplateStrategy(TemplateUpdateStrategy):
    """Static template - no updates after initial creation."""
    
    def update_template(self, current_template: TemplateState, 
                       new_embedding: np.ndarray, 
                       new_confidence: float,
                       age: int) -> TemplateState:
        # Update age but keep everything else the same
        updated_template = TemplateState(
            current_template.embedding, 
            current_template.confidence, 
            current_template.age_at_creation
        )
        updated_template.current_age = age
        updated_template.update_count = current_template.update_count
        updated_template.total_drift = current_template.total_drift
        updated_template.drift_history = current_template.drift_history.copy()
        updated_template.confidence_history = current_template.confidence_history.copy()
        return updated_template
    
    def get_strategy_name(self) -> str:
        return "Static"


class EMATemplateStrategy(TemplateUpdateStrategy):
    """Exponential Moving Average template update strategy."""
    
    def __init__(self, alpha: float = 0.3):
        self.alpha = alpha
    
    def update_template(self, current_template: TemplateState, 
                       new_embedding: np.ndarray, 
                       new_confidence: float,
                       age: int) -> TemplateState:
        
        # Calculate updated embedding
        updated_embedding = (self.alpha * new_embedding + 
                           (1 - self.alpha) * current_template.embedding)
        updated_embedding = updated_embedding / np.linalg.norm(updated_embedding)
        
        # Calculate drift
        drift = 1 - np.dot(current_template.embedding, updated_embedding)
        
        # Create updated template
        updated_template = TemplateState(updated_embedding, new_confidence, current_template.age_at_creation)
        updated_template.current_age = age
        updated_template.update_count = current_template.update_count + 1
        updated_template.last_update_age = age
        updated_template.total_drift = current_template.total_drift + drift
        updated_template.drift_history = current_template.drift_history + [drift]
        updated_template.update_magnitudes = current_template.update_magnitudes + [np.linalg.norm(new_embedding - current_template.embedding)]
        updated_template.confidence_history = current_template.confidence_history + [new_confidence]
        
        return updated_template
    
    def get_strategy_name(self) -> str:
        return f"EMA(α={self.alpha})"


class GatedEMATemplateStrategy(TemplateUpdateStrategy):
    """Gated EMA - only update if similarity is above threshold."""
    
    def __init__(self, alpha: float = 0.3, confidence_threshold: float = 0.7):
        self.alpha = alpha
        self.confidence_threshold = confidence_threshold
    
    def update_template(self, current_template: TemplateState, 
                       new_embedding: np.ndarray, 
                       new_confidence: float,
                       age: int) -> TemplateState:
        
        # Calculate similarity between current template and new embedding
        similarity = np.dot(current_template.embedding, new_embedding / np.linalg.norm(new_embedding))
        
        # Only update if similarity is above threshold
        if similarity >= self.confidence_threshold:
            # Apply EMA update
            updated_embedding = (self.alpha * new_embedding + 
                               (1 - self.alpha) * current_template.embedding)
            updated_embedding = updated_embedding / np.linalg.norm(updated_embedding)
            
            # Calculate drift
            drift = 1 - np.dot(current_template.embedding, updated_embedding)
            
            # Create updated template
            updated_template = TemplateState(updated_embedding, new_confidence, current_template.age_at_creation)
            updated_template.current_age = age
            updated_template.update_count = current_template.update_count + 1
            updated_template.last_update_age = age
            updated_template.total_drift = current_template.total_drift + drift
            updated_template.drift_history = current_template.drift_history + [drift]
            updated_template.update_magnitudes = current_template.update_magnitudes + [np.linalg.norm(new_embedding - current_template.embedding)]
            updated_template.confidence_history = current_template.confidence_history + [new_confidence]
            
            return updated_template
        else:
            # No update - return current template with updated age
            updated_template = TemplateState(
                current_template.embedding, 
                current_template.confidence, 
                current_template.age_at_creation
            )
            updated_template.current_age = age
            updated_template.update_count = current_template.update_count
            updated_template.total_drift = current_template.total_drift
            updated_template.drift_history = current_template.drift_history.copy()
            updated_template.confidence_history = current_template.confidence_history.copy()
            
            return updated_template
    
    def get_strategy_name(self) -> str:
        return f"GatedEMA(α={self.alpha},τ={self.confidence_threshold})"


class EnhancedEMADriftExperiment:
    """Enhanced experimental framework for EMA drift study."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.metadata = None
        self.results = {}
        
        # Initialize strategies
        self.strategies = {
            'static': StaticTemplateStrategy(),
            'ema': EMATemplateStrategy(config.get('ema_alpha', 0.3)),
            'gated_ema': GatedEMATemplateStrategy(
                config.get('ema_alpha', 0.3), 
                config.get('gated_threshold', 0.7)
            )
        }
        
        # Initialize validators
        self.validators = {
            'accuracy_over_time': FaceVerificationAccuracyOverTimeValidator(config),
            'genuine_impostor_separation': GenuineImpostorSeparationValidator(config),
            'template_drift_robustness': TemplateDriftRobustnessValidator(config)
        }
        
        # Try to import additional validators
        try:
            update_stability_module = importlib.import_module('4_Update_Stability_Sensitivity')
            ablation_study_module = importlib.import_module('5_Ablation_Study_Comparison')
            
            UpdateStabilitySensitivityValidator = update_stability_module.UpdateStabilitySensitivityValidator
            AblationStudyComparisonValidator = ablation_study_module.AblationStudyComparisonValidator
            
            self.validators['update_stability_sensitivity'] = UpdateStabilitySensitivityValidator(config)
            self.validators['ablation_study_comparison'] = AblationStudyComparisonValidator(config)
            
        except ImportError as e:
            logger.warning(f"Could not import additional validators: {e}")
        
        # Create results directory
        self.results_dir = Path(config.get('results_dir', 'enhanced_results'))
        self.results_dir.mkdir(exist_ok=True)
        
        logger.info(f"Enhanced EMA Drift Experiment initialized with {len(self.strategies)} strategies")
    
    def load_dataset_metadata(self) -> pd.DataFrame:
        """Load and preprocess CACD dataset metadata."""
        
        metadata_path = self.config.get('metadata_path', 'data/CACD_features_sex.csv')
        
        try:
            metadata = pd.read_csv(metadata_path)
            
            # Extract celebrity name from filename
            def extract_celebrity_name(filename):
                parts = filename.split('_')
                if len(parts) >= 3:
                    firstname = parts[1]
                    lastname = parts[2].replace('.jpg', '').split('_')[0] 
                    return firstname + lastname
                return 'Unknown'
            
            metadata['celebrity'] = metadata['name'].apply(extract_celebrity_name)
            
            # Filter by minimum requirements
            min_images = self.config.get('min_images_per_identity', 10)
            min_age_span = self.config.get('min_age_span', 3)
            
            # Filter by image count
            identity_counts = metadata.groupby('identity').size()
            valid_identities = identity_counts[identity_counts >= min_images].index
            
            # Filter by age span
            age_spans = metadata.groupby('identity')['age'].apply(lambda x: x.max() - x.min())
            valid_age_spans = age_spans[age_spans >= min_age_span].index
            
            # Get intersection
            valid_identities = set(valid_identities) & set(valid_age_spans)
            
            # Limit to max identities for manageable processing
            max_identities = self.config.get('max_identities', 50)
            if len(valid_identities) > max_identities:
                valid_identities = list(valid_identities)[:max_identities]
            
            metadata = metadata[metadata['identity'].isin(valid_identities)]
            
            logger.info(f"Loaded metadata: {len(valid_identities)} identities, {len(metadata)} images")
            self.metadata = metadata
            return metadata
            
        except Exception as e:
            logger.error(f"Error loading metadata: {e}")
            return pd.DataFrame()
    
    def extract_simple_embedding(self, image_path: str) -> Optional[np.ndarray]:
        """Extract simple embedding from image path."""
        
        try:
            # For demonstration, create a random but consistent embedding based on path
            # In practice, this would use a real face recognition model
            import hashlib
            
            # Create deterministic random embedding based on image path
            hash_obj = hashlib.md5(image_path.encode())
            seed = int(hash_obj.hexdigest()[:8], 16)
            np.random.seed(seed)
            
            embedding = np.random.randn(512).astype(np.float32)
            embedding = embedding / np.linalg.norm(embedding)
            
            return embedding
            
        except Exception as e:
            logger.warning(f"Error extracting embedding from {image_path}: {e}")
            return None
    
    def simulate_temporal_evolution(self, identity_id: int, strategy: TemplateUpdateStrategy) -> Tuple[List[TemplateState], List[int]]:
        """Simulate temporal template evolution for an identity."""
        
        identity_data = self.metadata[self.metadata['identity'] == identity_id].copy()
        identity_data = identity_data.sort_values('age')  # Sort by age
        
        if len(identity_data) < 2:
            return [], []
        
        templates_over_time = []
        ages = []
        
        # Initialize with first image
        first_row = identity_data.iloc[0]
        celebrity = first_row['celebrity']
        image_path = os.path.join(self.config.get('dataset_root', ''), celebrity, first_row['name'])
        
        first_embedding = self.extract_simple_embedding(image_path)
        if first_embedding is None:
            return [], []
        
        current_template = TemplateState(first_embedding, 0.8, first_row['age'])
        templates_over_time.append(current_template)
        ages.append(first_row['age'])
        
        # Process remaining images
        for _, row in identity_data.iloc[1:].iterrows():
            celebrity = row['celebrity']
            image_path = os.path.join(self.config.get('dataset_root', ''), celebrity, row['name'])
            
            new_embedding = self.extract_simple_embedding(image_path)
            if new_embedding is not None:
                # Apply strategy update
                current_template = strategy.update_template(
                    current_template, new_embedding, 0.8, row['age']
                )
                templates_over_time.append(current_template)
                ages.append(row['age'])
        
        return templates_over_time, ages
    
    def create_verification_pairs(self, identities: List[int]) -> List[Tuple[int, int, bool]]:
        """Create verification pairs for evaluation."""
        
        pairs = []
        
        # Generate genuine pairs (same identity)
        n_genuine = min(100, len(identities) * 2)
        for i in range(n_genuine):
            identity = np.random.choice(identities)
            pairs.append((identity, identity, True))
        
        # Generate impostor pairs (different identities)
        n_impostor = min(500, len(identities) * 10)
        for i in range(n_impostor):
            id1, id2 = np.random.choice(identities, 2, replace=False)
            pairs.append((id1, id2, False))
        
        logger.info(f"Created {n_genuine} genuine and {n_impostor} impostor pairs")
        return pairs
    
    def run_comprehensive_experiment(self) -> Dict[str, Any]:
        """Run comprehensive EMA drift experiment with all validations."""
        
        logger.info("Starting comprehensive EMA drift experiment...")
        start_time = time.time()
        
        # Load dataset
        metadata = self.load_dataset_metadata()
        if metadata.empty:
            logger.error("No valid metadata loaded")
            return {}
        
        # Get identities for processing
        identities = metadata['identity'].unique()
        verification_pairs = self.create_verification_pairs(identities)
        
        # Results storage
        all_results = {}
        
        # Run experiment for each strategy
        for strategy_name, strategy in self.strategies.items():
            logger.info(f"Running experiment for {strategy.get_strategy_name()}")
            
            strategy_results = {
                'templates_history': {},
                'ages_history': {},
                'validation_results': {}
            }
            
            # Simulate temporal evolution for each identity
            processed_identities = 0
            for identity_id in identities:
                templates, ages = self.simulate_temporal_evolution(identity_id, strategy)
                
                if len(templates) >= 2:  # Need at least 2 time points
                    strategy_results['templates_history'][str(identity_id)] = templates
                    strategy_results['ages_history'][str(identity_id)] = ages
                    processed_identities += 1
            
            logger.info(f"Processed {processed_identities} identities for {strategy_name}")
            
            if processed_identities > 0:
                # Run all validations
                strategy_results['validation_results'] = self._run_all_validations(
                    strategy_results, verification_pairs, strategy.get_strategy_name()
                )
            
            all_results[strategy_name] = strategy_results
        
        # Comparative analysis
        comparative_analysis = self._perform_comparative_analysis(all_results)
        
        # Save results
        self._save_comprehensive_results(all_results, comparative_analysis)
        
        end_time = time.time()
        logger.info(f"Comprehensive experiment completed in {end_time - start_time:.2f} seconds")
        
        return {
            'strategy_results': all_results,
            'comparative_analysis': comparative_analysis,
            'execution_time': end_time - start_time
        }
    
    def _run_all_validations(self, strategy_results: Dict[str, Any], 
                           verification_pairs: List[Tuple[int, int, bool]],
                           strategy_name: str) -> Dict[str, Any]:
        """Run all validation components for a strategy."""
        
        validation_results = {}
        templates_history = strategy_results['templates_history']
        
        # Get final templates for separation analysis
        final_templates = {}
        for identity, history in templates_history.items():
            if history:
                final_templates[identity] = history[-1]
        
        try:
            # 1. Face Verification Accuracy Over Time
            logger.info(f"Running accuracy over time validation for {strategy_name}")
            validation_results['accuracy_over_time'] = self.validators['accuracy_over_time'].validate(
                templates_history=templates_history,
                verification_pairs=verification_pairs,
                strategy_name=strategy_name
            )
            
            # 2. Genuine-Impostor Separation
            logger.info(f"Running genuine-impostor separation validation for {strategy_name}")
            validation_results['genuine_impostor_separation'] = self.validators['genuine_impostor_separation'].validate(
                templates=final_templates,
                pairs=verification_pairs,
                strategy_name=strategy_name
            )
            
            # 3. Template Drift Robustness
            logger.info(f"Running drift robustness validation for {strategy_name}")
            validation_results['template_drift_robustness'] = self.validators['template_drift_robustness'].validate(
                templates_history=templates_history,
                strategy_name=strategy_name
            )
            
        except Exception as e:
            logger.error(f"Error during validation for {strategy_name}: {e}")
        
        return validation_results
    
    def _perform_comparative_analysis(self, all_results: Dict[str, Any]) -> Dict[str, Any]:
        """Perform comparative analysis across all strategies."""
        
        analysis = {
            'performance_comparison': {},
            'drift_comparison': {},
            'strategy_rankings': {},
            'insights': []
        }
        
        # Extract key metrics for comparison
        strategy_metrics = {}
        
        for strategy_name, results in all_results.items():
            validation_results = results.get('validation_results', {})
            
            metrics = {}
            
            # Extract accuracy metrics
            accuracy_validation = validation_results.get('accuracy_over_time', {})
            if accuracy_validation.get('values'):
                accuracy_data = accuracy_validation['values'].get('accuracy_evolution', {})
                if accuracy_data.get('roc_auc_over_time'):
                    metrics['final_roc_auc'] = accuracy_data['roc_auc_over_time'][-1]
                    metrics['initial_roc_auc'] = accuracy_data['roc_auc_over_time'][0]
                    metrics['roc_auc_improvement'] = metrics['final_roc_auc'] - metrics['initial_roc_auc']
            
            # Extract separation metrics
            separation_validation = validation_results.get('genuine_impostor_separation', {})
            if separation_validation.get('values'):
                separation_data = separation_validation['values'].get('statistical_analysis', {})
                metrics['separation_gap'] = separation_data.get('separation_gap', 0)
                metrics['effect_size'] = separation_data.get('effect_size', 0)
            
            # Extract drift metrics
            drift_validation = validation_results.get('template_drift_robustness', {})
            if drift_validation.get('values'):
                drift_data = drift_validation['values'].get('drift_analysis', {})
                drift_stats = drift_data.get('drift_statistics', {})
                metrics['mean_drift'] = drift_stats.get('mean_total_drift', 0)
                metrics['drift_consistency'] = drift_validation['values'].get('consistency_analysis', {}).get('overall_consistency', 0)
            
            strategy_metrics[strategy_name] = metrics
        
        analysis['performance_comparison'] = strategy_metrics
        
        # Generate rankings
        if strategy_metrics:
            # ROC AUC ranking
            roc_aucs = {k: v.get('final_roc_auc', 0) for k, v in strategy_metrics.items()}
            analysis['strategy_rankings']['roc_auc'] = sorted(roc_aucs.keys(), key=lambda k: roc_aucs[k], reverse=True)
            
            # Separation gap ranking
            separations = {k: v.get('separation_gap', 0) for k, v in strategy_metrics.items()}
            analysis['strategy_rankings']['separation'] = sorted(separations.keys(), key=lambda k: separations[k], reverse=True)
            
            # Drift control ranking (lower is better)
            drifts = {k: v.get('mean_drift', float('inf')) for k, v in strategy_metrics.items()}
            analysis['strategy_rankings']['drift_control'] = sorted(drifts.keys(), key=lambda k: drifts[k])
        
        # Generate insights
        analysis['insights'] = self._generate_comparative_insights(strategy_metrics, analysis['strategy_rankings'])
        
        return analysis
    
    def _generate_comparative_insights(self, strategy_metrics: Dict[str, Dict], rankings: Dict[str, List]) -> List[str]:
        """Generate comparative insights across strategies."""
        
        insights = []
        
        # Performance insights
        if 'roc_auc' in rankings:
            best_roc_strategy = rankings['roc_auc'][0]
            worst_roc_strategy = rankings['roc_auc'][-1]
            
            best_roc = strategy_metrics[best_roc_strategy].get('final_roc_auc', 0)
            worst_roc = strategy_metrics[worst_roc_strategy].get('final_roc_auc', 0)
            
            insights.append(f"[BEST] Best ROC AUC: {best_roc_strategy.upper()} ({best_roc:.3f})")
            insights.append(f"[GAP] Performance gap: {best_roc - worst_roc:.3f} between best and worst")
        
        # Improvement insights
        improvements = {}
        for strategy, metrics in strategy_metrics.items():
            if 'roc_auc_improvement' in metrics:
                improvements[strategy] = metrics['roc_auc_improvement']
        
        if improvements:
            best_improvement = max(improvements.keys(), key=lambda k: improvements[k])
            improvement_value = improvements[best_improvement]
            
            if improvement_value > 0.01:
                insights.append(f"[TREND+] {best_improvement.upper()} shows best accuracy improvement over time (+{improvement_value:.3f})")
            elif improvement_value < -0.01:
                insights.append(f"[TREND-] {best_improvement.upper()} shows accuracy degradation over time ({improvement_value:.3f})")
            else:
                insights.append("[STABLE] All strategies maintain stable accuracy over time")
        
        # Drift insights
        if 'drift_control' in rankings:
            best_drift_control = rankings['drift_control'][0]
            insights.append(f"[DRIFT] Best drift control: {best_drift_control.upper()}")
        
        # Separation insights
        if 'separation' in rankings:
            best_separation = rankings['separation'][0]
            insights.append(f"[SEPARATION] Best genuine-impostor separation: {best_separation.upper()}")
        
        return insights
    
    def _save_comprehensive_results(self, all_results: Dict[str, Any], comparative_analysis: Dict[str, Any]):
        """Save comprehensive experimental results."""
        
        # Generate comprehensive report
        report = self._generate_comprehensive_report(all_results, comparative_analysis)
        
        # Save report
        report_path = self.results_dir / "comprehensive_experiment_report.txt"
        with open(report_path, 'w') as f:
            f.write(report)
        
        logger.info(f"Comprehensive report saved to {report_path}")
        
        # Generate visualizations
        self._generate_comprehensive_visualizations(all_results, comparative_analysis)
    
    def _generate_comprehensive_report(self, all_results: Dict[str, Any], comparative_analysis: Dict[str, Any]) -> str:
        """Generate comprehensive experimental report."""
        
        report = []
        report.append("=" * 80)
        report.append("ENHANCED EMA TEMPLATE DRIFT STUDY - COMPREHENSIVE REPORT")
        report.append("=" * 80)
        report.append("")
        report.append(f"Generated: {pd.Timestamp.now()}")
        report.append("")
        
        # Configuration summary
        report.append("EXPERIMENTAL CONFIGURATION:")
        report.append(f"- EMA Alpha: {self.config.get('ema_alpha', 0.3)}")
        report.append(f"- Gated Threshold: {self.config.get('gated_threshold', 0.7)}")
        report.append(f"- Max Identities: {self.config.get('max_identities', 50)}")
        report.append(f"- Min Images per Identity: {self.config.get('min_images_per_identity', 10)}")
        report.append("")
        
        # Strategy comparison
        report.append("STRATEGY PERFORMANCE COMPARISON:")
        report.append("-" * 40)
        
        performance_comparison = comparative_analysis.get('performance_comparison', {})
        for strategy_name, metrics in performance_comparison.items():
            report.append(f"\n{strategy_name.upper()}:")
            report.append(f"  Final ROC AUC: {metrics.get('final_roc_auc', 0):.4f}")
            report.append(f"  ROC AUC Change: {metrics.get('roc_auc_improvement', 0):+.4f}")
            report.append(f"  Separation Gap: {metrics.get('separation_gap', 0):.4f}")
            report.append(f"  Effect Size: {metrics.get('effect_size', 0):.2f}")
            report.append(f"  Mean Drift: {metrics.get('mean_drift', 0):.4f}")
        
        # Rankings
        report.append("\n\nSTRATEGY RANKINGS:")
        report.append("-" * 20)
        
        rankings = comparative_analysis.get('strategy_rankings', {})
        for metric, ranking in rankings.items():
            report.append(f"\n{metric.upper()}:")
            for i, strategy in enumerate(ranking, 1):
                report.append(f"  {i}. {strategy.upper()}")
        
        # Key insights
        report.append("\n\nKEY INSIGHTS:")
        report.append("-" * 15)
        
        insights = comparative_analysis.get('insights', [])
        for insight in insights:
            report.append(f"• {insight}")
        
        # Detailed validation results
        report.append("\n\nDETAILED VALIDATION RESULTS:")
        report.append("-" * 35)
        
        for strategy_name, results in all_results.items():
            validation_results = results.get('validation_results', {})
            
            report.append(f"\n{strategy_name.upper()} - Detailed Results:")
            
            for validator_name, result in validation_results.items():
                status = "[PASSED]" if result.get('passed', False) else "[FAILED]"
                report.append(f"\n  {validator_name.replace('_', ' ').title()}: {status}")
                summary = result.get('summary', 'No summary available')
                # Add indented summary
                for line in summary.split('\n'):
                    if line.strip():
                        report.append(f"    {line.strip()}")
        
        return "\n".join(report)
    
    def _generate_comprehensive_visualizations(self, all_results: Dict[str, Any], comparative_analysis: Dict[str, Any]):
        """Generate comprehensive visualizations."""
        
        try:
            # Strategy comparison plot
            self._plot_strategy_comparison(comparative_analysis)
            
            # Individual strategy validation plots
            for strategy_name, results in all_results.items():
                validation_results = results.get('validation_results', {})
                
                # Plot accuracy evolution
                accuracy_result = validation_results.get('accuracy_over_time')
                if accuracy_result:
                    save_path = self.results_dir / f"{strategy_name}_accuracy_evolution.png"
                    self.validators['accuracy_over_time'].plot_accuracy_evolution(accuracy_result, str(save_path))
                
                # Plot score distributions
                separation_result = validation_results.get('genuine_impostor_separation')
                if separation_result:
                    save_path = self.results_dir / f"{strategy_name}_score_distributions.png"
                    self.validators['genuine_impostor_separation'].plot_score_distributions(separation_result, str(save_path))
                
                # Plot drift analysis
                drift_result = validation_results.get('template_drift_robustness')
                if drift_result:
                    save_path = self.results_dir / f"{strategy_name}_drift_analysis.png"
                    self.validators['template_drift_robustness'].plot_drift_analysis(drift_result, str(save_path))
            
            logger.info(f"Comprehensive visualizations saved to {self.results_dir}")
            
        except Exception as e:
            logger.error(f"Error generating visualizations: {e}")
    
    def _plot_strategy_comparison(self, comparative_analysis: Dict[str, Any]):
        """Plot strategy comparison overview."""
        
        performance_comparison = comparative_analysis.get('performance_comparison', {})
        if not performance_comparison:
            return
        
        strategies = list(performance_comparison.keys())
        
        # Extract metrics for plotting
        roc_aucs = [performance_comparison[s].get('final_roc_auc', 0) for s in strategies]
        roc_improvements = [performance_comparison[s].get('roc_auc_improvement', 0) for s in strategies]
        separation_gaps = [performance_comparison[s].get('separation_gap', 0) for s in strategies]
        mean_drifts = [performance_comparison[s].get('mean_drift', 0) for s in strategies]
        
        # Create comparison plot
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.suptitle('Strategy Performance Comparison', fontsize=16, fontweight='bold')
        
        # ROC AUC comparison
        ax1 = axes[0, 0]
        bars1 = ax1.bar(strategies, roc_aucs, color=['blue', 'red', 'green'])
        ax1.set_ylabel('Final ROC AUC')
        ax1.set_title('Final ROC AUC Comparison')
        ax1.set_ylim(0, 1)
        for i, v in enumerate(roc_aucs):
            ax1.text(i, v + 0.01, f'{v:.3f}', ha='center', va='bottom')
        
        # ROC AUC improvement
        ax2 = axes[0, 1]
        colors2 = ['green' if x >= 0 else 'red' for x in roc_improvements]
        bars2 = ax2.bar(strategies, roc_improvements, color=colors2)
        ax2.set_ylabel('ROC AUC Change')
        ax2.set_title('ROC AUC Change Over Time')
        ax2.axhline(y=0, color='black', linestyle='-', alpha=0.3)
        for i, v in enumerate(roc_improvements):
            ax2.text(i, v + 0.001 if v >= 0 else v - 0.001, f'{v:+.3f}', ha='center', va='bottom' if v >= 0 else 'top')
        
        # Separation gap comparison
        ax3 = axes[1, 0]
        bars3 = ax3.bar(strategies, separation_gaps, color=['blue', 'red', 'green'])
        ax3.set_ylabel('Separation Gap')
        ax3.set_title('Genuine-Impostor Separation Gap')
        for i, v in enumerate(separation_gaps):
            ax3.text(i, v + 0.01, f'{v:.3f}', ha='center', va='bottom')
        
        # Mean drift comparison
        ax4 = axes[1, 1]
        bars4 = ax4.bar(strategies, mean_drifts, color=['blue', 'red', 'green'])
        ax4.set_ylabel('Mean Template Drift')
        ax4.set_title('Mean Template Drift (Lower is Better)')
        for i, v in enumerate(mean_drifts):
            ax4.text(i, v + 0.001, f'{v:.3f}', ha='center', va='bottom')
        
        plt.tight_layout()
        
        save_path = self.results_dir / "strategy_comparison.png"
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"Strategy comparison plot saved to {save_path}")


def run_enhanced_experiment(config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Run enhanced EMA drift experiment with default or custom configuration."""
    
    if config is None:
        config = {
            'dataset_root': 'data/cacd_split/cacd_split',
            'metadata_path': 'data/CACD_features_sex.csv',
            'ema_alpha': 0.3,
            'gated_threshold': 0.7,
            'min_images_per_identity': 10,
            'min_age_span': 3,
            'max_identities': 20,  # Reduced for faster execution
            'results_dir': 'enhanced_ema_results'
        }
    
    experiment = EnhancedEMADriftExperiment(config)
    return experiment.run_comprehensive_experiment()


if __name__ == "__main__":
    # Run enhanced experiment
    results = run_enhanced_experiment()
    print("Enhanced EMA drift experiment completed!")
    print(f"Results saved to: enhanced_ema_results/") 