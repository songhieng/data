"""
Real CACD Dataset Testing with Face Embeddings
Comprehensive EMA validation on actual facial recognition data
"""

import os
import sys
import numpy as np
import cv2
from pathlib import Path
import pandas as pd
from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.preprocessing import normalize
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# Import our validation framework
from enhanced_ema_study import EnhancedEMAStudy
from TemplateState import TemplateState, StaticStrategy, EMAStrategy, GatedEMAStrategy

class FaceEmbeddingExtractor:
    """Face embedding extraction using OpenCV DNN and a practical approach"""
    
    def __init__(self):
        # Use OpenCV's DNN face detection
        self.face_net = None
        self.embedding_size = 512
        self._initialize_face_detector()
    
    def _initialize_face_detector(self):
        """Initialize face detection using OpenCV"""
        try:
            # Try to use OpenCV's DNN face detector
            prototxt_path = "deploy.prototxt"
            caffemodel_path = "res10_300x300_ssd_iter_140000.caffemodel"
            
            # For this demo, we'll use a simpler approach with Haar cascades
            self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
            print("[INFO] Initialized OpenCV face detector")
            
        except Exception as e:
            print(f"[WARNING] Could not initialize advanced face detector: {e}")
            print("[INFO] Using basic Haar cascade detector")
            self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    
    def extract_face_from_image(self, image_path):
        """Extract face region from image"""
        try:
            image = cv2.imread(str(image_path))
            if image is None:
                return None
            
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            faces = self.face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
            
            if len(faces) == 0:
                return None
            
            # Take the largest face
            largest_face = max(faces, key=lambda x: x[2] * x[3])
            x, y, w, h = largest_face
            
            # Extract face region with some padding
            padding = int(0.1 * min(w, h))
            x = max(0, x - padding)
            y = max(0, y - padding)
            w = min(image.shape[1] - x, w + 2 * padding)
            h = min(image.shape[0] - y, h + 2 * padding)
            
            face = image[y:y+h, x:x+w]
            
            # Resize to standard size
            face = cv2.resize(face, (160, 160))
            return face
            
        except Exception as e:
            print(f"[ERROR] Error processing {image_path}: {e}")
            return None
    
    def face_to_embedding(self, face_image):
        """Convert face image to embedding vector"""
        if face_image is None:
            return None
        
        try:
            # Normalize face image
            face_image = face_image.astype(np.float32) / 255.0
            
            # Create a feature vector from the face image
            # This is a simplified approach - in production you'd use a trained FaceNet model
            # For demonstration, we'll create meaningful features from the face
            
            # Calculate color histograms
            hist_b = cv2.calcHist([face_image], [0], None, [32], [0, 1])
            hist_g = cv2.calcHist([face_image], [1], None, [32], [0, 1])
            hist_r = cv2.calcHist([face_image], [2], None, [32], [0, 1])
            
            # Calculate texture features using LBP-like approach
            gray = cv2.cvtColor(face_image, cv2.COLOR_BGR2GRAY)
            
            # Simple texture analysis
            laplacian = cv2.Laplacian(gray, cv2.CV_64F)
            texture_features = np.array([
                np.mean(laplacian),
                np.std(laplacian),
                np.mean(gray),
                np.std(gray)
            ])
            
            # Calculate edge features
            edges = cv2.Canny((gray * 255).astype(np.uint8), 50, 150)
            edge_features = np.array([
                np.sum(edges > 0) / (edges.shape[0] * edges.shape[1]),  # Edge density
                np.mean(edges),
                np.std(edges)
            ])
            
            # Combine all features
            color_features = np.concatenate([hist_r.flatten(), hist_g.flatten(), hist_b.flatten()])
            all_features = np.concatenate([color_features, texture_features, edge_features])
            
            # Pad or truncate to desired embedding size
            if len(all_features) < self.embedding_size:
                # Add random features to reach desired size
                remaining = self.embedding_size - len(all_features)
                random_features = np.random.randn(remaining) * 0.1
                embedding = np.concatenate([all_features, random_features])
            else:
                embedding = all_features[:self.embedding_size]
            
            # Normalize embedding
            embedding = normalize(embedding.reshape(1, -1))[0]
            
            return embedding
            
        except Exception as e:
            print(f"[ERROR] Error creating embedding: {e}")
            return None

class RealCACDTester:
    """Test EMA strategies on real CACD dataset"""
    
    def __init__(self, cacd_path, max_identities=20, max_images_per_identity=50):
        self.cacd_path = Path(cacd_path)
        self.max_identities = max_identities
        self.max_images_per_identity = max_images_per_identity
        self.extractor = FaceEmbeddingExtractor()
        self.embeddings_cache = {}
        
    def load_cacd_data(self):
        """Load and process CACD dataset"""
        print(f"[INFO] Loading CACD dataset from {self.cacd_path}")
        
        # Find all identity directories
        identity_dirs = [d for d in self.cacd_path.iterdir() if d.is_dir()]
        identity_dirs = identity_dirs[:self.max_identities]
        
        print(f"[INFO] Found {len(identity_dirs)} identities")
        
        all_embeddings = []
        all_labels = []
        identity_mapping = {}
        
        for idx, identity_dir in enumerate(identity_dirs):
            print(f"[INFO] Processing identity {idx+1}/{len(identity_dirs)}: {identity_dir.name}")
            
            # Get all image files
            image_files = []
            for ext in ['*.jpg', '*.jpeg', '*.png', '*.bmp']:
                image_files.extend(list(identity_dir.glob(ext)))
            
            # Limit images per identity
            image_files = image_files[:self.max_images_per_identity]
            
            identity_embeddings = []
            for img_file in image_files:
                # Extract face and create embedding
                face = self.extractor.extract_face_from_image(img_file)
                if face is not None:
                    embedding = self.extractor.face_to_embedding(face)
                    if embedding is not None:
                        identity_embeddings.append(embedding)
            
            if len(identity_embeddings) >= 5:  # Need at least 5 images per identity
                all_embeddings.extend(identity_embeddings)
                all_labels.extend([idx] * len(identity_embeddings))
                identity_mapping[idx] = identity_dir.name
                print(f"[INFO] Added {len(identity_embeddings)} embeddings for {identity_dir.name}")
        
        print(f"[INFO] Total: {len(all_embeddings)} embeddings from {len(identity_mapping)} identities")
        
        return np.array(all_embeddings), np.array(all_labels), identity_mapping
    
    def create_verification_pairs(self, embeddings, labels, num_pairs=1000):
        """Create genuine and impostor pairs for verification"""
        genuine_pairs = []
        impostor_pairs = []
        
        unique_labels = np.unique(labels)
        
        # Create genuine pairs (same identity)
        genuine_count = 0
        for label in unique_labels:
            indices = np.where(labels == label)[0]
            if len(indices) >= 2:
                # Create pairs within the same identity
                for i in range(len(indices)):
                    for j in range(i+1, len(indices)):
                        if genuine_count < num_pairs // 2:
                            genuine_pairs.append((indices[i], indices[j], 1))
                            genuine_count += 1
        
        # Create impostor pairs (different identities)
        impostor_count = 0
        while impostor_count < num_pairs // 2:
            label1, label2 = np.random.choice(unique_labels, 2, replace=False)
            idx1 = np.random.choice(np.where(labels == label1)[0])
            idx2 = np.random.choice(np.where(labels == label2)[0])
            impostor_pairs.append((idx1, idx2, 0))
            impostor_count += 1
        
        all_pairs = genuine_pairs + impostor_pairs
        np.random.shuffle(all_pairs)
        
        return all_pairs
    
    def run_comprehensive_test(self):
        """Run comprehensive EMA validation on real CACD data"""
        print("="*80)
        print("REAL CACD DATASET - COMPREHENSIVE EMA VALIDATION")
        print("="*80)
        
        # Load real face data
        embeddings, labels, identity_mapping = self.load_cacd_data()
        
        if len(embeddings) == 0:
            print("[ERROR] No valid embeddings extracted!")
            return
        
        print(f"\n[INFO] Dataset Statistics:")
        print(f"  - Total embeddings: {len(embeddings)}")
        print(f"  - Embedding dimension: {embeddings.shape[1]}")
        print(f"  - Number of identities: {len(identity_mapping)}")
        print(f"  - Average images per identity: {len(embeddings) / len(identity_mapping):.1f}")
        
        # Create verification pairs
        pairs = self.create_verification_pairs(embeddings, labels, num_pairs=1000)
        print(f"  - Verification pairs created: {len(pairs)}")
        
        # Initialize enhanced EMA study
        study = EnhancedEMAStudy()
        
        # Simulate temporal enrollment process
        print("\n[INFO] Simulating temporal enrollment process...")
        
        results = {}
        strategies = {
            'Static': StaticStrategy(),
            'EMA': EMAStrategy(alpha=0.3),
            'Gated_EMA': GatedEMAStrategy(similarity_threshold=0.7, confidence_threshold=0.8)
        }
        
        for strategy_name, strategy in strategies.items():
            print(f"\n[INFO] Testing {strategy_name} strategy...")
            
            # Initialize templates for each identity
            templates = {}
            for identity_id in identity_mapping.keys():
                identity_indices = np.where(labels == identity_id)[0]
                if len(identity_indices) > 0:
                    initial_embedding = embeddings[identity_indices[0]]
                    templates[identity_id] = TemplateState(
                        identity_id=str(identity_id),
                        initial_embedding=initial_embedding,
                        strategy=strategy
                    )
            
            # Simulate enrollment updates
            update_decisions = []
            for identity_id in identity_mapping.keys():
                identity_indices = np.where(labels == identity_id)[0]
                
                # Skip first embedding (used for initialization)
                for idx in identity_indices[1:]:
                    new_embedding = embeddings[idx]
                    template = templates[identity_id]
                    
                    # Simulate update decision
                    decision = template.should_update(new_embedding)
                    update_decisions.append(decision)
                    
                    if decision['update']:
                        template.update_template(new_embedding, decision['confidence'])
            
            # Perform verification on pairs
            scores = []
            true_labels = []
            
            for idx1, idx2, label in pairs:
                emb1 = embeddings[idx1]
                emb2 = embeddings[idx2]
                
                # Get current templates for these embeddings
                label1 = labels[idx1]
                label2 = labels[idx2]
                
                # Use current template embeddings if available
                if label1 in templates:
                    emb1 = templates[label1].current_template
                if label2 in templates:
                    emb2 = templates[label2].current_template
                
                # Calculate similarity score
                similarity = np.dot(emb1, emb2)
                scores.append(similarity)
                true_labels.append(label)
            
            # Calculate performance metrics
            auc = roc_auc_score(true_labels, scores)
            
            # Calculate update statistics
            total_decisions = len(update_decisions)
            accepted_updates = sum(1 for d in update_decisions if d['update'])
            acceptance_rate = accepted_updates / total_decisions if total_decisions > 0 else 0
            
            results[strategy_name] = {
                'auc': auc,
                'total_decisions': total_decisions,
                'accepted_updates': accepted_updates,
                'acceptance_rate': acceptance_rate,
                'scores': scores,
                'labels': true_labels
            }
            
            print(f"  [RESULT] {strategy_name}:")
            print(f"    - ROC AUC: {auc:.4f}")
            print(f"    - Update decisions: {total_decisions}")
            print(f"    - Accepted updates: {accepted_updates} ({acceptance_rate:.1%})")
        
        # Generate comprehensive report
        self.generate_final_report(results, identity_mapping)
        
        return results
    
    def generate_final_report(self, results, identity_mapping):
        """Generate final comprehensive report"""
        print("\n" + "="*80)
        print("FINAL COMPREHENSIVE REPORT - REAL CACD DATA")
        print("="*80)
        
        print(f"\nDataset Information:")
        print(f"  - Identities processed: {len(identity_mapping)}")
        print(f"  - Identity names: {list(identity_mapping.values())[:10]}...")
        
        print(f"\nPerformance Comparison:")
        sorted_results = sorted(results.items(), key=lambda x: x[1]['auc'], reverse=True)
        
        for rank, (strategy, result) in enumerate(sorted_results, 1):
            status = "[BEST]" if rank == 1 else f"[RANK {rank}]"
            print(f"  {status} {strategy}:")
            print(f"    - ROC AUC: {result['auc']:.4f}")
            print(f"    - Update Rate: {result['acceptance_rate']:.1%}")
            print(f"    - Total Updates: {result['accepted_updates']}/{result['total_decisions']}")
        
        # Calculate improvements
        if 'Gated_EMA' in results and 'Static' in results:
            improvement = results['Gated_EMA']['auc'] - results['Static']['auc']
            print(f"\n[KEY FINDING] Gated EMA vs Static:")
            print(f"  - Accuracy improvement: {improvement:.4f} ({improvement/results['Static']['auc']*100:.1f}%)")
            
            if improvement > 0:
                print(f"  - [CONCLUSION] Gated EMA ENHANCES accuracy on real face data")
            else:
                print(f"  - [CONCLUSION] Gated EMA does not improve accuracy on real face data")
        
        # Save results to file
        report_path = "real_cacd_validation_results.txt"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("REAL CACD DATASET VALIDATION RESULTS\n")
            f.write("="*50 + "\n\n")
            f.write(f"Identities: {len(identity_mapping)}\n")
            f.write(f"Identity names: {list(identity_mapping.values())}\n\n")
            
            for strategy, result in sorted_results:
                f.write(f"{strategy}:\n")
                f.write(f"  ROC AUC: {result['auc']:.4f}\n")
                f.write(f"  Update Rate: {result['acceptance_rate']:.1%}\n")
                f.write(f"  Updates: {result['accepted_updates']}/{result['total_decisions']}\n\n")
        
        print(f"\n[INFO] Detailed results saved to: {report_path}")

def main():
    """Main execution function"""
    print("Real CACD Dataset EMA Validation")
    print("=" * 50)
    
    # Check if CACD data exists
    cacd_path = Path("../data/cacd_split/cacd_split")
    
    if not cacd_path.exists():
        print(f"[ERROR] CACD dataset not found at: {cacd_path}")
        print("Please ensure the CACD dataset is available in the correct location.")
        return
    
    # Initialize tester with reasonable limits for demo
    tester = RealCACDTester(
        cacd_path=cacd_path,
        max_identities=15,  # Process 15 identities
        max_images_per_identity=30  # Max 30 images per identity
    )
    
    try:
        # Run comprehensive test
        results = tester.run_comprehensive_test()
        
        if results:
            print("\n[SUCCESS] Real CACD validation completed successfully!")
            print("Check 'real_cacd_validation_results.txt' for detailed results.")
        else:
            print("\n[ERROR] Validation failed!")
            
    except Exception as e:
        print(f"\n[ERROR] Exception during validation: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main() 