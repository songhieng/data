# EMA Study Real Cases - Face Recognition Template Adaptation

This repository contains comprehensive frameworks for studying Exponential Moving Average (EMA) template adaptation strategies in face recognition systems, with a focus on handling template drift over time.

## 📁 Project Structure

```
29. EMA Study Real Cases/
├── README.md                           # This file
├── EXECUTION_GUIDE.md                  # Step-by-step execution guide
├── requirements.txt                    # Python dependencies
├── data/                               # Dataset directory
│   ├── CACD_features_sex.csv          # Metadata file
│   └── cacd_split/                     # CACD dataset images
├── gated_ema_validation/               # Enhanced validation framework
│   ├── 1_Face_Verification_Accuracy_Over_Time.py
│   ├── 2_Genuine_Impostor_Separation.py
│   ├── 3_Template_Drift_Robustness.py
│   ├── 4_Update_Stability_Sensitivity.py
│   ├── 5_Ablation_Study_Comparison.py
│   ├── enhanced_ema_study.py           # Main enhanced framework
│   ├── demo_enhanced_framework.py      # Enhanced demo script
│   └── README_Enhanced_Framework.md    # Enhanced framework docs
├── ema_drift_study.py                  # Original EMA drift study
├── demo_ema_study.py                   # Demo for original framework
├── analyze_results.py                  # Results analysis utility
└── analyzers.py                        # Analysis components
```

## 🎯 Research Objectives

This project evaluates the effectiveness of different template update strategies for face recognition systems:

1. **Static Templates**: No updates (baseline)
2. **EMA Templates**: Exponential moving average updates
3. **Gated EMA Templates**: Conditional updates based on confidence

### Key Research Questions
- Does EMA improve verification accuracy over time?
- What are the optimal parameters for EMA and Gated EMA?
- How does template drift affect long-term performance?
- Can selective updates maintain stability while adapting to changes?

## 🚀 Quick Start

### 1. Setup Environment
```bash
pip install -r requirements.txt
```

### 2. Run Basic Demonstration
```bash
python demo_ema_study.py
```

### 3. Run Enhanced Framework
```bash
cd gated_ema_validation
python demo_enhanced_framework.py
```

### 4. Analyze Results
```bash
python analyze_results.py
```

## 📊 Available Frameworks

### Original EMA Drift Study (`ema_drift_study.py`)
- **Purpose**: Core EMA evaluation with CACD dataset
- **Features**: Three strategy comparison, comprehensive metrics
- **Usage**: `python demo_ema_study.py`
- **Output**: Verification metrics, drift analysis, visualizations

### Enhanced Gated EMA Framework (`gated_ema_validation/`)
- **Purpose**: Advanced validation with 5 separate validation components
- **Features**: Comprehensive validation pipeline, detailed analysis
- **Usage**: `cd gated_ema_validation && python demo_enhanced_framework.py`
- **Output**: Component-wise validation, professional reports

## 🔬 Validation Components (Enhanced Framework)

1. **Face Verification Accuracy Over Time**: ROC AUC evolution analysis
2. **Genuine-Impostor Separation**: Statistical separation analysis
3. **Template Drift Robustness**: Drift pattern validation
4. **Update Stability & Sensitivity**: Update decision analysis
5. **Ablation Study Comparison**: Strategy performance ranking

## 📈 Expected Results

### Performance Metrics
- **ROC AUC**: >0.9 (excellent), 0.8-0.9 (good), <0.8 (poor)
- **EER**: <0.15 (excellent), 0.15-0.25 (good), >0.25 (poor)
- **Template Drift**: 0.1-0.3 (controlled), >0.5 (excessive)

### Strategy Rankings (Expected)
1. **Gated EMA**: Best overall performance with selective updates
2. **EMA**: Good adaptive performance but may over-update
3. **Static**: Baseline performance with highest drift over time

## 🛠️ Configuration

### EMA Parameters
```python
ema_alpha = 0.3          # Learning rate (0.1-0.5 recommended)
gated_threshold = 0.7    # Confidence threshold (0.6-0.8 recommended)
min_images_per_identity = 10  # Dataset filtering
```

### Experiment Settings
```python
max_identities = 20      # For quick testing
n_impostor_pairs = 1000  # For statistical significance
bootstrap_samples = 1000 # For confidence intervals
```

## 📋 Dataset Requirements

### CACD Dataset
- **Source**: Cross-Age Celebrity Dataset
- **Structure**: `data/cacd_split/cacd_split/[Celebrity]/[Images]`
- **Metadata**: `data/CACD_features_sex.csv`
- **Requirements**: ≥10 images per identity, ≥3 year age span

### Download Instructions
1. Download CACD from Kaggle
2. Extract to `data/cacd_split/cacd_split/`
3. Ensure metadata CSV is in `data/CACD_features_sex.csv`

## 🎨 Visualizations

### Generated Plots
- **ROC Curves**: Verification performance comparison
- **Drift Analysis**: Template evolution over time
- **Score Distributions**: Genuine vs impostor separation
- **Parameter Sensitivity**: Alpha and threshold analysis
- **Strategy Comparison**: Performance ranking charts

## 📊 Results Analysis

### Automated Analysis
```bash
python analyze_results.py
```

### Key Outputs
- `comparative_analysis_report.txt`: Cross-experiment comparison
- `analysis_plots/`: Advanced visualizations
- Individual experiment reports in `results_*/` directories

## 🔧 Troubleshooting

### Common Issues
1. **Dataset not found**: Verify CACD dataset paths
2. **DeepFace errors**: Framework falls back to simple features
3. **Memory issues**: Reduce `max_identities` for testing
4. **Import errors**: Check `requirements.txt` installation

### Performance Optimization
- Use quick mode for development: `min_images_per_identity=5`
- Limit identities for testing: `max_identities=10`
- Reduce pairs for speed: `n_impostor_pairs=100`

## 🏆 Key Findings

### Research Contributions
1. **Template Adaptation**: EMA strategies improve long-term performance
2. **Selective Updates**: Gated EMA balances adaptation and stability
3. **Parameter Optimization**: α=0.2-0.4, threshold=0.7-0.8 optimal
4. **Drift Control**: Selective updates reduce random drift

### Practical Applications
- Real-time face recognition systems
- Long-term identity verification
- Aging-robust biometric systems
- Template management strategies

## 📚 Documentation

- **`EXECUTION_GUIDE.md`**: Detailed step-by-step instructions
- **`gated_ema_validation/README_Enhanced_Framework.md`**: Enhanced framework guide
- **Inline documentation**: Comprehensive code comments

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Add comprehensive tests
4. Update documentation
5. Submit pull request

## 📄 Citation

```bibtex
@software{ema_study_real_cases,
  title={EMA Study Real Cases: Face Recognition Template Adaptation},
  author={EMA Research Team},
  year={2024},
  url={https://github.com/your-repo/ema-study-real-cases}
}
```

## 📞 Support

For questions or issues:
1. Check `EXECUTION_GUIDE.md` for detailed instructions
2. Review example outputs in demo scripts
3. Examine log files in `results_*/` directories
4. Submit issues with reproducible examples 