#!/usr/bin/env python3
"""
FaceNet-512 Enhanced EMA Validation Test
========================================

This script runs comprehensive validation of all strategies using real FaceNet-512 embeddings
extracted from the CACD dataset face images.
"""

import sys
import os
import pandas as pd
import numpy as np
import time
import logging
import matplotlib.pyplot as plt
from pathlib import Path
from typing import Dict, List, Any, Tuple
from deepface import DeepFace
from deepface.commons import functions
from sklearn.metrics import roc_auc_score, roc_curve
import warnings
import cv2
import tensorflow as tf

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Suppress TensorFlow warnings
tf.get_logger().setLevel(logging.ERROR)
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
warnings.filterwarnings("ignore")

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

# Import the template strategies
try:
    from enhanced_ema_study import (
        EnhancedEMADriftExperiment, 
        StaticTemplateStrategy, 
        EMATemplateStrategy, 
        GatedEMATemplateStrategy,
        TemplateState
    )
except ImportError as e:
    logger.error(f"Import error: {e}")
    sys.exit(1)


class FaceNet512Extractor:
    """FaceNet-512 feature extractor for face images."""
    
    def __init__(self):
        """Initialize the FaceNet-512 model."""
        self.model = None
        self.model_name = 'Facenet512'
        logger.info("Initializing FaceNet-512 model...")
        
        # Lazy loading - model will be loaded on first use
        
    def _ensure_model_loaded(self):
        """Ensure the model is loaded."""
        if self.model is None:
            logger.info("Loading FaceNet-512 model...")
            self.model = DeepFace.build_model(self.model_name)
            logger.info("FaceNet-512 model loaded successfully")
    
    def extract_embedding(self, image_path: str) -> np.ndarray:
        """Extract FaceNet-512 embedding from a face image."""
        self._ensure_model_loaded()
        
        try:
            # Read and preprocess image
            img = functions.preprocess_face(
                img=image_path,
                target_size=(160, 160),
                enforce_detection=False,
                detector_backend='opencv'
            )
            
            # Get embedding
            embedding = self.model.predict(img, verbose=0)[0]
            
            # Normalize embedding to unit length
            embedding = embedding / np.linalg.norm(embedding)
            
            return embedding
            
        except Exception as e:
            logger.warning(f"Error extracting embedding from {image_path}: {e}")
            # Return random embedding as fallback
            random_embedding = np.random.randn(512)
            return random_embedding / np.linalg.norm(random_embedding)


def load_cacd_data(max_identities: int = 30) -> pd.DataFrame:
    """Load CACD dataset metadata."""
    
    metadata_path = "../data/CACD_features_sex.csv"
    
    if not os.path.exists(metadata_path):
        raise FileNotFoundError(f"CACD metadata not found at {metadata_path}")
    
    logger.info(f"Loading CACD metadata from {metadata_path}")
    metadata = pd.read_csv(metadata_path)
    
    # Filter by minimum images and age span
    identity_counts = metadata.groupby('identity').size()
    valid_identities = identity_counts[identity_counts >= 15].index  # At least 15 images
    
    age_spans = metadata.groupby('identity')['age'].apply(lambda x: x.max() - x.min())
    valid_age_spans = age_spans[age_spans >= 8].index  # At least 8 years span
    
    valid_identities = set(valid_identities) & set(valid_age_spans)
    
    # Limit to max_identities for testing
    if len(valid_identities) > max_identities:
        valid_identities = list(valid_identities)[:max_identities]
    
    filtered_metadata = metadata[metadata['identity'].isin(valid_identities)]
    
    # Add full image path
    dataset_root = Path("../data/cacd_split/cacd_split")
    
    def get_full_path(row):
        # Extract celebrity name from filename
        parts = row['name'].split('_')
        if len(parts) >= 3:
            firstname = parts[1]
            lastname = parts[2].replace('.jpg', '').split('_')[0]
            celebrity = firstname + lastname
            return str(dataset_root / celebrity / row['name'])
        return None
    
    filtered_metadata['image_path'] = filtered_metadata.apply(get_full_path, axis=1)
    
    logger.info(f"Filtered dataset: {len(valid_identities)} identities, {len(filtered_metadata)} images")
    logger.info(f"Age range: {filtered_metadata['age'].min()}-{filtered_metadata['age'].max()}")
    
    return filtered_metadata


def run_facenet_verification_test():
    """Run face verification test with real FaceNet-512 embeddings."""
    
    print("\n" + "="*80)
    print("FACENET-512 VERIFICATION TEST")
    print("="*80)
    
    # Load data
    metadata = load_cacd_data(max_identities=10)  # Limit to 10 identities for faster testing
    
    # Initialize FaceNet-512 extractor
    extractor = FaceNet512Extractor()
    
    # Configuration
    config = {
        'ema_alpha': 0.3,
        'gated_threshold': 0.7,
        'min_images_per_identity': 15,
        'results_dir': 'facenet_test_results'
    }
    
    # Initialize strategies
    strategies = {
        'Static': StaticTemplateStrategy(),
        'EMA': EMATemplateStrategy(config['ema_alpha']),
        'Gated_EMA': GatedEMATemplateStrategy(config['ema_alpha'], config['gated_threshold'])
    }
    
    results = {}
    
    # Process each identity
    identities = metadata['identity'].unique()
    
    for strategy_name, strategy in strategies.items():
        logger.info(f"Testing {strategy_name} strategy with FaceNet-512 embeddings...")
        
        strategy_metrics = {
            'roc_auc_evolution': [],
            'accuracy_evolution': [],
            'eer_evolution': [],
            'template_updates': 0,
            'total_comparisons': 0,
            'genuine_scores': [],
            'impostor_scores': [],
            'drift_values': []
        }
        
        # Process each identity
        for identity in identities:
            logger.info(f"Processing identity {identity}...")
            
            # Get temporal sequence for this identity
            identity_data = metadata[metadata['identity'] == identity].sort_values('age')
            
            if len(identity_data) < 5:
                continue
                
            # Extract embeddings for all images of this identity
            identity_embeddings = {}
            
            for _, row in identity_data.iterrows():
                if row['image_path'] and os.path.exists(row['image_path']):
                    embedding = extractor.extract_embedding(row['image_path'])
                    identity_embeddings[row['name']] = embedding
            
            if len(identity_embeddings) < 5:
                logger.warning(f"Not enough valid images for identity {identity}, skipping")
                continue
                
            # Simulate temporal evolution
            templates_over_time = []
            ages = []
            
            # Initialize template with first image
            first_row = identity_data.iloc[0]
            if first_row['name'] in identity_embeddings:
                initial_embedding = identity_embeddings[first_row['name']]
                
                current_template = TemplateState(
                    embedding=initial_embedding,
                    confidence=0.8,
                    age=first_row['age']
                )
                templates_over_time.append(current_template)
                ages.append(first_row['age'])
                
                # Process subsequent images
                for _, row in identity_data.iloc[1:].iterrows():
                    if row['name'] in identity_embeddings:
                        new_embedding = identity_embeddings[row['name']]
                        
                        # Apply strategy
                        updated_template = strategy.update_template(
                            current_template, new_embedding, 0.8, row['age']
                        )
                        
                        templates_over_time.append(updated_template)
                        ages.append(row['age'])
                        
                        # Calculate drift
                        from sklearn.metrics.pairwise import cosine_similarity
                        initial_emb = templates_over_time[0].embedding.reshape(1, -1)
                        current_emb = updated_template.embedding.reshape(1, -1)
                        drift = 1 - cosine_similarity(initial_emb, current_emb)[0, 0]
                        strategy_metrics['drift_values'].append(drift)
                        
                        strategy_metrics['total_comparisons'] += 1
                        if updated_template.update_count > current_template.update_count:
                            strategy_metrics['template_updates'] += 1
                        
                        current_template = updated_template
            
            # Generate genuine and impostor scores
            if len(templates_over_time) >= 3:
                final_template = templates_over_time[-1]
                
                # Genuine comparisons - same identity, different images
                other_identities = [i for i in identities if i != identity]
                
                # Use last 5 images of same identity for genuine scores
                for _, row in identity_data.tail(5).iterrows():
                    if row['name'] in identity_embeddings:
                        probe_embedding = identity_embeddings[row['name']]
                        similarity = np.dot(final_template.embedding, probe_embedding)
                        strategy_metrics['genuine_scores'].append(similarity)
                
                # Impostor comparisons - different identities
                for other_id in other_identities[:3]:  # Limit to 3 other identities
                    other_data = metadata[metadata['identity'] == other_id].head(3)
                    
                    for _, row in other_data.iterrows():
                        if row['image_path'] and os.path.exists(row['image_path']):
                            impostor_embedding = extractor.extract_embedding(row['image_path'])
                            similarity = np.dot(final_template.embedding, impostor_embedding)
                            strategy_metrics['impostor_scores'].append(similarity)
        
        # Calculate metrics
        if strategy_metrics['genuine_scores'] and strategy_metrics['impostor_scores']:
            # Calculate ROC AUC
            y_true = [1] * len(strategy_metrics['genuine_scores']) + [0] * len(strategy_metrics['impostor_scores'])
            y_scores = strategy_metrics['genuine_scores'] + strategy_metrics['impostor_scores']
            
            roc_auc = roc_auc_score(y_true, y_scores)
            
            # Calculate EER
            fpr, tpr, thresholds = roc_curve(y_true, y_scores)
            fnr = 1 - tpr
            eer_threshold = thresholds[np.nanargmin(np.absolute(fnr - fpr))]
            eer = fpr[np.nanargmin(np.absolute(fnr - fpr))]
            
            # Calculate separation
            genuine_mean = np.mean(strategy_metrics['genuine_scores'])
            genuine_std = np.std(strategy_metrics['genuine_scores'])
            impostor_mean = np.mean(strategy_metrics['impostor_scores'])
            impostor_std = np.std(strategy_metrics['impostor_scores'])
            
            separation_gap = genuine_mean - impostor_mean
            
            # Cohen's d (effect size)
            pooled_std = np.sqrt((genuine_std**2 + impostor_std**2) / 2)
            effect_size = separation_gap / pooled_std if pooled_std > 0 else 0
            
            # Mean drift
            mean_drift = np.mean(strategy_metrics['drift_values']) if strategy_metrics['drift_values'] else 0
            
            # Update frequency
            update_freq = strategy_metrics['template_updates'] / max(1, strategy_metrics['total_comparisons'])
            
            results[strategy_name] = {
                'roc_auc': roc_auc,
                'eer': eer,
                'separation_gap': separation_gap,
                'effect_size': effect_size,
                'mean_drift': mean_drift,
                'update_frequency': update_freq,
                'n_genuine': len(strategy_metrics['genuine_scores']),
                'n_impostor': len(strategy_metrics['impostor_scores'])
            }
    
    # Display results
    print("\nFACENET-512 VERIFICATION RESULTS:")
    print("-" * 40)
    
    for strategy_name, metrics in results.items():
        print(f"\n{strategy_name.upper()}:")
        print(f"  ROC AUC: {metrics['roc_auc']:.4f}")
        print(f"  EER: {metrics['eer']:.4f}")
        print(f"  Separation Gap: {metrics['separation_gap']:.3f}")
        print(f"  Effect Size: {metrics['effect_size']:.2f}")
        print(f"  Mean Drift: {metrics['mean_drift']:.4f}")
        print(f"  Update Frequency: {metrics['update_frequency']:.3f}")
        print(f"  Genuine Scores: {metrics['n_genuine']}")
        print(f"  Impostor Scores: {metrics['n_impostor']}")
    
    # Plot ROC curves
    plt.figure(figsize=(10, 8))
    
    for strategy_name, metrics in results.items():
        y_true = [1] * metrics['n_genuine'] + [0] * metrics['n_impostor']
        y_scores = strategy_metrics['genuine_scores'][:metrics['n_genuine']] + strategy_metrics['impostor_scores'][:metrics['n_impostor']]
        
        fpr, tpr, _ = roc_curve(y_true, y_scores)
        plt.plot(fpr, tpr, label=f"{strategy_name} (AUC = {metrics['roc_auc']:.3f})")
    
    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curves - FaceNet-512 Verification')
    plt.legend(loc='lower right')
    
    # Save results
    os.makedirs('facenet_test_results', exist_ok=True)
    plt.savefig('facenet_test_results/roc_curves.png', dpi=300)
    
    # Save metrics to CSV
    df_results = pd.DataFrame(results).T
    df_results.to_csv('facenet_test_results/facenet_results.csv')
    
    print("\nResults saved to facenet_test_results/")
    
    return results


if __name__ == "__main__":
    print("🎯 Running FaceNet-512 Enhanced EMA Validation Test")
    print("=" * 60)
    
    start_time = time.time()
    
    try:
        results = run_facenet_verification_test()
        
        end_time = time.time()
        print(f"\n⏱️ Total testing time: {end_time - start_time:.2f} seconds")
        
    except Exception as e:
        logger.error(f"Testing failed: {e}")
        import traceback
        traceback.print_exc() 