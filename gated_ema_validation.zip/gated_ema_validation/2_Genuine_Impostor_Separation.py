"""
Genuine-Impostor Separation Validator
====================================

This validator analyzes how template updates affect the separation between
genuine and impostor verification scores, which is crucial for determining
whether Gated EMA maintains or improves discriminability.
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.metrics import roc_curve, auc
from typing import Dict, List, Tuple, Optional, Any
import logging
from pathlib import Path

from .config import ValidationConfig
from .validators import BaseValidator, ValidationResults
from .core import TemplateState

logger = logging.getLogger(__name__)


class GenuineImpostorSeparationValidator(BaseValidator):
    """
    Comprehensive validator for genuine-impostor score separation analysis.
    
    Key Questions Answered:
    1. Does Gated EMA maintain score separation over time?
    2. How do genuine and impostor score distributions evolve?
    3. Is the separation statistically significant?
    4. What is the effect size of the separation?
    """
    
    def __init__(self, config: ValidationConfig):
        super().__init__(config)
        self.min_separation_gap = 0.2  # Minimum acceptable separation
        self.min_effect_size = 1.0     # Minimum Cohen's d effect size
        
    def get_validator_name(self) -> str:
        return "Genuine-Impostor Separation"
    
    def validate(self, 
                templates: Dict[str, TemplateState],
                pairs: List[Tuple[str, str, bool]],
                strategy_name: str = "Unknown") -> ValidationResults:
        """
        Validate genuine-impostor score separation.
        
        Args:
            templates: Final template states for all identities
            pairs: List of (id1, id2, is_genuine) verification pairs
            strategy_name: Name of the strategy being evaluated
            
        Returns:
            ValidationResults with comprehensive separation analysis
        """
        
        logger.info(f"Validating genuine-impostor separation for {strategy_name}")
        
        if not templates or not pairs:
            return self._create_empty_result("No templates or pairs available")
        
        # Calculate verification scores
        genuine_scores, impostor_scores = self._calculate_verification_scores(templates, pairs)
        
        if not genuine_scores or not impostor_scores:
            return self._create_empty_result("No valid verification scores calculated")
        
        # Statistical analysis
        statistical_analysis = self._perform_statistical_analysis(genuine_scores, impostor_scores)
        
        # Distribution analysis
        distribution_analysis = self._analyze_score_distributions(genuine_scores, impostor_scores)
        
        # ROC analysis
        roc_analysis = self._perform_roc_analysis(genuine_scores, impostor_scores)
        
        # Separation quality assessment
        separation_quality = self._assess_separation_quality(statistical_analysis, distribution_analysis)
        
        # Generate insights
        insights = self._generate_separation_insights(
            statistical_analysis, distribution_analysis, roc_analysis, strategy_name
        )
        
        # Compile results
        results = {
            'genuine_scores': genuine_scores,
            'impostor_scores': impostor_scores,
            'statistical_analysis': statistical_analysis,
            'distribution_analysis': distribution_analysis,
            'roc_analysis': roc_analysis,
            'separation_quality': separation_quality,
            'insights': insights,
            'strategy_name': strategy_name
        }
        
        # Determine pass/fail
        passed, summary = self._evaluate_separation(statistical_analysis, separation_quality, strategy_name)
        
        return ValidationResults(
            metric_name=self.get_validator_name(),
            values=results,
            summary=summary,
            passed=passed
        )
    
    def _calculate_verification_scores(self, 
                                     templates: Dict[str, TemplateState],
                                     pairs: List[Tuple[str, str, bool]]) -> Tuple[List[float], List[float]]:
        """Calculate verification scores for genuine and impostor pairs."""
        
        genuine_scores = []
        impostor_scores = []
        
        for id1, id2, is_genuine in pairs:
            if str(id1) in templates and str(id2) in templates:
                template1 = templates[str(id1)]
                template2 = templates[str(id2)]
                
                # Calculate cosine similarity
                similarity = np.dot(template1.embedding, template2.embedding) / (
                    np.linalg.norm(template1.embedding) * np.linalg.norm(template2.embedding)
                )
                
                if is_genuine:
                    genuine_scores.append(similarity)
                else:
                    impostor_scores.append(similarity)
        
        return genuine_scores, impostor_scores
    
    def _perform_statistical_analysis(self, 
                                    genuine_scores: List[float], 
                                    impostor_scores: List[float]) -> Dict[str, Any]:
        """Perform comprehensive statistical analysis of score distributions."""
        
        analysis = {}
        
        # Basic statistics
        analysis['genuine_stats'] = {
            'mean': np.mean(genuine_scores),
            'std': np.std(genuine_scores),
            'median': np.median(genuine_scores),
            'min': np.min(genuine_scores),
            'max': np.max(genuine_scores),
            'count': len(genuine_scores)
        }
        
        analysis['impostor_stats'] = {
            'mean': np.mean(impostor_scores),
            'std': np.std(impostor_scores),
            'median': np.median(impostor_scores),
            'min': np.min(impostor_scores),
            'max': np.max(impostor_scores),
            'count': len(impostor_scores)
        }
        
        # Separation metrics
        analysis['separation_gap'] = analysis['genuine_stats']['mean'] - analysis['impostor_stats']['mean']
        
        # Effect size (Cohen's d)
        pooled_std = np.sqrt((analysis['genuine_stats']['std']**2 + analysis['impostor_stats']['std']**2) / 2)
        analysis['effect_size'] = analysis['separation_gap'] / pooled_std if pooled_std > 0 else 0.0
        
        # Statistical significance test (Welch's t-test)
        try:
            t_stat, p_value = stats.ttest_ind(genuine_scores, impostor_scores, equal_var=False)
            analysis['t_statistic'] = t_stat
            analysis['p_value'] = p_value
            analysis['statistically_significant'] = p_value < 0.05
        except Exception as e:
            logger.warning(f"Statistical test failed: {e}")
            analysis['t_statistic'] = 0.0
            analysis['p_value'] = 1.0
            analysis['statistically_significant'] = False
        
        # Overlap analysis
        overlap_range = [
            max(analysis['genuine_stats']['min'], analysis['impostor_stats']['min']),
            min(analysis['genuine_stats']['max'], analysis['impostor_stats']['max'])
        ]
        analysis['score_overlap'] = max(0, overlap_range[1] - overlap_range[0])
        
        return analysis
    
    def _analyze_score_distributions(self, 
                                   genuine_scores: List[float], 
                                   impostor_scores: List[float]) -> Dict[str, Any]:
        """Analyze the shape and characteristics of score distributions."""
        
        analysis = {}
        
        # Distribution shape analysis
        try:
            # Normality tests
            genuine_shapiro = stats.shapiro(genuine_scores)
            impostor_shapiro = stats.shapiro(impostor_scores)
            
            analysis['genuine_normality'] = {
                'shapiro_statistic': genuine_shapiro.statistic,
                'shapiro_p_value': genuine_shapiro.pvalue,
                'is_normal': genuine_shapiro.pvalue > 0.05
            }
            
            analysis['impostor_normality'] = {
                'shapiro_statistic': impostor_shapiro.statistic,
                'shapiro_p_value': impostor_shapiro.pvalue,
                'is_normal': impostor_shapiro.pvalue > 0.05
            }
            
            # Skewness and kurtosis
            analysis['genuine_skewness'] = stats.skew(genuine_scores)
            analysis['genuine_kurtosis'] = stats.kurtosis(genuine_scores)
            analysis['impostor_skewness'] = stats.skew(impostor_scores)
            analysis['impostor_kurtosis'] = stats.kurtosis(impostor_scores)
            
        except Exception as e:
            logger.warning(f"Distribution analysis failed: {e}")
            analysis['genuine_normality'] = {'is_normal': False}
            analysis['impostor_normality'] = {'is_normal': False}
        
        # Percentile analysis
        analysis['genuine_percentiles'] = {
            '5th': np.percentile(genuine_scores, 5),
            '25th': np.percentile(genuine_scores, 25),
            '75th': np.percentile(genuine_scores, 75),
            '95th': np.percentile(genuine_scores, 95)
        }
        
        analysis['impostor_percentiles'] = {
            '5th': np.percentile(impostor_scores, 5),
            '25th': np.percentile(impostor_scores, 25),
            '75th': np.percentile(impostor_scores, 75),
            '95th': np.percentile(impostor_scores, 95)
        }
        
        # Interquartile range
        analysis['genuine_iqr'] = analysis['genuine_percentiles']['75th'] - analysis['genuine_percentiles']['25th']
        analysis['impostor_iqr'] = analysis['impostor_percentiles']['75th'] - analysis['impostor_percentiles']['25th']
        
        return analysis
    
    def _perform_roc_analysis(self, 
                            genuine_scores: List[float], 
                            impostor_scores: List[float]) -> Dict[str, Any]:
        """Perform ROC curve analysis."""
        
        analysis = {}
        
        try:
            # Prepare data for ROC analysis
            all_scores = genuine_scores + impostor_scores
            all_labels = [1] * len(genuine_scores) + [0] * len(impostor_scores)
            
            # Calculate ROC curve
            fpr, tpr, thresholds = roc_curve(all_labels, all_scores)
            roc_auc = auc(fpr, tpr)
            
            analysis['fpr'] = fpr.tolist()
            analysis['tpr'] = tpr.tolist()
            analysis['thresholds'] = thresholds.tolist()
            analysis['auc'] = roc_auc
            
            # Calculate EER
            fnr = 1 - tpr
            eer_idx = np.nanargmin(np.absolute(fnr - fpr))
            analysis['eer'] = fpr[eer_idx]
            analysis['eer_threshold'] = thresholds[eer_idx]
            
            # Calculate specific operating points
            # FPR at 95% TPR
            tpr_95_idx = np.where(tpr >= 0.95)[0]
            analysis['fpr_at_95_tpr'] = fpr[tpr_95_idx[0]] if len(tpr_95_idx) > 0 else 1.0
            
            # TPR at 1% FPR
            fpr_1_idx = np.where(fpr <= 0.01)[0]
            analysis['tpr_at_1_fpr'] = tpr[fpr_1_idx[-1]] if len(fpr_1_idx) > 0 else 0.0
            
        except Exception as e:
            logger.warning(f"ROC analysis failed: {e}")
            analysis['auc'] = 0.0
            analysis['eer'] = 1.0
        
        return analysis
    
    def _assess_separation_quality(self, 
                                 statistical_analysis: Dict[str, Any],
                                 distribution_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Assess the overall quality of genuine-impostor separation."""
        
        quality = {}
        
        # Separation gap assessment
        separation_gap = statistical_analysis['separation_gap']
        quality['gap_quality'] = 'excellent' if separation_gap > 0.4 else \
                                'good' if separation_gap > 0.2 else \
                                'poor'
        
        # Effect size assessment
        effect_size = statistical_analysis['effect_size']
        quality['effect_size_quality'] = 'large' if effect_size > 2.0 else \
                                        'medium' if effect_size > 1.0 else \
                                        'small'
        
        # Statistical significance
        quality['significance_quality'] = 'significant' if statistical_analysis['statistically_significant'] else 'not_significant'
        
        # Overlap assessment
        overlap = statistical_analysis['score_overlap']
        quality['overlap_quality'] = 'excellent' if overlap < 0.1 else \
                                    'good' if overlap < 0.3 else \
                                    'poor'
        
        # Overall quality score (0-1)
        quality_score = 0.0
        if quality['gap_quality'] == 'excellent':
            quality_score += 0.3
        elif quality['gap_quality'] == 'good':
            quality_score += 0.2
        
        if quality['effect_size_quality'] == 'large':
            quality_score += 0.3
        elif quality['effect_size_quality'] == 'medium':
            quality_score += 0.2
        
        if quality['significance_quality'] == 'significant':
            quality_score += 0.2
        
        if quality['overlap_quality'] == 'excellent':
            quality_score += 0.2
        elif quality['overlap_quality'] == 'good':
            quality_score += 0.1
        
        quality['overall_score'] = quality_score
        quality['overall_quality'] = 'excellent' if quality_score > 0.8 else \
                                   'good' if quality_score > 0.6 else \
                                   'fair' if quality_score > 0.4 else \
                                   'poor'
        
        return quality
    
    def _generate_separation_insights(self, 
                                    statistical_analysis: Dict[str, Any],
                                    distribution_analysis: Dict[str, Any],
                                    roc_analysis: Dict[str, Any],
                                    strategy_name: str) -> List[str]:
        """Generate actionable insights about score separation."""
        
        insights = []
        
        # Overall separation quality
        separation_gap = statistical_analysis['separation_gap']
        effect_size = statistical_analysis['effect_size']
        
        if separation_gap > self.min_separation_gap:
            insights.append(f"✅ {strategy_name} maintains good separation gap ({separation_gap:.3f})")
        else:
            insights.append(f"⚠️ {strategy_name} has insufficient separation gap ({separation_gap:.3f})")
        
        # Effect size insight
        if effect_size > self.min_effect_size:
            insights.append(f"✅ Large effect size ({effect_size:.2f}) indicates strong discriminability")
        else:
            insights.append(f"⚠️ Small effect size ({effect_size:.2f}) indicates weak discriminability")
        
        # Statistical significance
        if statistical_analysis['statistically_significant']:
            p_value = statistical_analysis['p_value']
            insights.append(f"✅ Separation is statistically significant (p < {p_value:.3f})")
        else:
            insights.append("⚠️ Separation is not statistically significant")
        
        # ROC performance
        auc = roc_analysis.get('auc', 0)
        if auc > 0.9:
            insights.append(f"✅ Excellent ROC AUC ({auc:.3f}) indicates strong verification performance")
        elif auc > 0.8:
            insights.append(f"📊 Good ROC AUC ({auc:.3f}) indicates acceptable verification performance")
        else:
            insights.append(f"⚠️ Poor ROC AUC ({auc:.3f}) indicates weak verification performance")
        
        # Distribution insights
        genuine_mean = statistical_analysis['genuine_stats']['mean']
        impostor_mean = statistical_analysis['impostor_stats']['mean']
        
        insights.append(f"Genuine scores: μ={genuine_mean:.3f}, Impostor scores: μ={impostor_mean:.3f}")
        
        return insights
    
    def _evaluate_separation(self, 
                           statistical_analysis: Dict[str, Any],
                           separation_quality: Dict[str, Any],
                           strategy_name: str) -> Tuple[bool, str]:
        """Evaluate whether the separation meets validation criteria."""
        
        # Check separation gap
        separation_gap = statistical_analysis['separation_gap']
        gap_acceptable = separation_gap >= self.min_separation_gap
        
        # Check effect size
        effect_size = statistical_analysis['effect_size']
        effect_size_acceptable = effect_size >= self.min_effect_size
        
        # Check statistical significance
        statistically_significant = statistical_analysis['statistically_significant']
        
        # Overall assessment
        passed = gap_acceptable and effect_size_acceptable and statistically_significant
        
        # Generate summary
        summary = f"""
        {strategy_name} Genuine-Impostor Separation Analysis:
        
        📊 Separation Gap: {separation_gap:.4f}
        📈 Effect Size (Cohen's d): {effect_size:.2f}
        🔬 Statistical Significance: {'Yes' if statistically_significant else 'No'}
        
        Quality Assessment:
        - Gap Quality: {separation_quality['gap_quality'].title()}
        - Effect Size: {separation_quality['effect_size_quality'].title()}
        - Overall Quality: {separation_quality['overall_quality'].title()}
        
        Genuine Scores: μ={statistical_analysis['genuine_stats']['mean']:.3f} ± {statistical_analysis['genuine_stats']['std']:.3f}
        Impostor Scores: μ={statistical_analysis['impostor_stats']['mean']:.3f} ± {statistical_analysis['impostor_stats']['std']:.3f}
        """
        
        return passed, summary.strip()
    
    def _create_empty_result(self, reason: str) -> ValidationResults:
        """Create empty validation result."""
        return ValidationResults(
            metric_name=self.get_validator_name(),
            values={},
            summary=f"Validation failed: {reason}",
            passed=False
        )
    
    def plot_score_distributions(self, results: ValidationResults, save_path: Optional[str] = None):
        """Plot genuine and impostor score distributions."""
        
        if not results.values or 'genuine_scores' not in results.values:
            logger.warning("No score data to plot")
            return
        
        genuine_scores = results.values['genuine_scores']
        impostor_scores = results.values['impostor_scores']
        strategy_name = results.values.get('strategy_name', 'Unknown')
        
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.suptitle(f'{strategy_name} - Genuine vs Impostor Score Analysis', fontsize=16, fontweight='bold')
        
        # Score distributions
        ax1 = axes[0, 0]
        ax1.hist(genuine_scores, bins=50, alpha=0.7, color='green', label='Genuine', density=True)
        ax1.hist(impostor_scores, bins=50, alpha=0.7, color='red', label='Impostor', density=True)
        ax1.set_xlabel('Similarity Score')
        ax1.set_ylabel('Density')
        ax1.set_title('Score Distributions')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # Box plots
        ax2 = axes[0, 1]
        ax2.boxplot([genuine_scores, impostor_scores], labels=['Genuine', 'Impostor'])
        ax2.set_ylabel('Similarity Score')
        ax2.set_title('Score Distribution Comparison')
        ax2.grid(True, alpha=0.3)
        
        # ROC Curve
        ax3 = axes[1, 0]
        if 'roc_analysis' in results.values:
            roc_data = results.values['roc_analysis']
            fpr = roc_data.get('fpr', [])
            tpr = roc_data.get('tpr', [])
            auc_score = roc_data.get('auc', 0)
            
            ax3.plot(fpr, tpr, 'b-', linewidth=2, label=f'ROC (AUC = {auc_score:.3f})')
            ax3.plot([0, 1], [0, 1], 'r--', alpha=0.5, label='Random')
            ax3.set_xlabel('False Positive Rate')
            ax3.set_ylabel('True Positive Rate')
            ax3.set_title('ROC Curve')
            ax3.legend()
            ax3.grid(True, alpha=0.3)
        
        # Statistics summary
        ax4 = axes[1, 1]
        ax4.axis('off')
        
        if 'statistical_analysis' in results.values:
            stats_data = results.values['statistical_analysis']
            stats_text = f"""
            Separation Statistics:
            
            Genuine Scores:
            • Mean: {stats_data['genuine_stats']['mean']:.3f}
            • Std: {stats_data['genuine_stats']['std']:.3f}
            • Count: {stats_data['genuine_stats']['count']}
            
            Impostor Scores:
            • Mean: {stats_data['impostor_stats']['mean']:.3f}
            • Std: {stats_data['impostor_stats']['std']:.3f}
            • Count: {stats_data['impostor_stats']['count']}
            
            Separation Metrics:
            • Gap: {stats_data['separation_gap']:.3f}
            • Effect Size: {stats_data['effect_size']:.2f}
            • P-value: {stats_data['p_value']:.3e}
            """
            
            ax4.text(0.05, 0.95, stats_text, transform=ax4.transAxes, fontsize=10,
                    verticalalignment='top', bbox=dict(boxstyle="round,pad=0.3", facecolor="lightgray"))
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            logger.info(f"Score distribution plot saved to {save_path}")
        else:
            plt.show()
        
        plt.close() 