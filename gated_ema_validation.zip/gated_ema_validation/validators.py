"""
Validation Components for Gated EMA Framework
============================================

This module implements comprehensive validation criteria:
1. Face Verification Accuracy Over Time
2. Genuine-Impostor Score Separation
3. Template Drift Robustness
4. Update Stability & Sensitivity  
5. Ablation Study Comparisons
"""

import numpy as np
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass, field
from sklearn.metrics import roc_auc_score, roc_curve, accuracy_score
from sklearn.metrics.pairwise import cosine_similarity
from scipy import stats
import pandas as pd
from abc import ABC, abstractmethod
import logging

from .core import TemplateState, UpdateDecision, GatedEMAUpdater
from .config import ValidationConfig

logger = logging.getLogger(__name__)


@dataclass
class ValidationResults:
    """Container for validation results."""
    
    metric_name: str
    values: Dict[str, Any]
    plots: List[Dict[str, Any]] = field(default_factory=list)
    summary: str = ""
    passed: bool = True
    

class BaseValidator(ABC):
    """Abstract base class for all validators."""
    
    def __init__(self, config: ValidationConfig):
        self.config = config
    
    @abstractmethod
    def validate(self, **kwargs) -> ValidationResults:
        """Perform validation and return results."""
        pass
    
    @abstractmethod
    def get_validator_name(self) -> str:
        """Return validator name."""
        pass


class VerificationAccuracyValidator(BaseValidator):
    """✅ 1. Face Verification Accuracy Over Time Validator."""
    
    def get_validator_name(self) -> str:
        return "Verification Accuracy Over Time"
    
    def validate(self, templates_history: Dict[str, List[TemplateState]], 
                verification_pairs: List[Tuple[str, str, bool]], 
                time_windows: Optional[List[int]] = None) -> ValidationResults:
        """
        Validate verification accuracy over time.
        
        Args:
            templates_history: Dict mapping identity_id to list of template states over time
            verification_pairs: List of (id1, id2, is_genuine) tuples
            time_windows: Time windows to evaluate (default: every 5 time steps)
        """
        
        if time_windows is None:
            max_time = max(len(history) for history in templates_history.values())
            time_windows = list(range(1, max_time + 1, 5))
        
        results = {
            'time_windows': time_windows,
            'accuracy_over_time': [],
            'roc_auc_over_time': [],
            'eer_over_time': [],
            'tar_at_far': {far: [] for far in [0.001, 0.01, 0.1]}
        }
        
        for time_idx in time_windows:
            # Get templates at this time point
            current_templates = {}
            for identity, history in templates_history.items():
                if len(history) > time_idx:
                    current_templates[identity] = history[time_idx]
                elif len(history) > 0:
                    current_templates[identity] = history[-1]  # Use last available
            
            if len(current_templates) < 2:
                continue
            
            # Calculate verification scores
            genuine_scores = []
            impostor_scores = []
            labels = []
            
            for id1, id2, is_genuine in verification_pairs:
                if id1 in current_templates and id2 in current_templates:
                    template1 = current_templates[id1]
                    template2 = current_templates[id2]
                    
                    score = cosine_similarity(
                        template1.embedding.reshape(1, -1),
                        template2.embedding.reshape(1, -1)
                    )[0, 0]
                    
                    if is_genuine:
                        genuine_scores.append(score)
                    else:
                        impostor_scores.append(score)
                    labels.append(1 if is_genuine else 0)
            
            if len(genuine_scores) == 0 or len(impostor_scores) == 0:
                continue
            
            # Calculate metrics
            all_scores = genuine_scores + impostor_scores
            all_labels = [1] * len(genuine_scores) + [0] * len(impostor_scores)
            
            # ROC AUC
            roc_auc = roc_auc_score(all_labels, all_scores)
            results['roc_auc_over_time'].append(roc_auc)
            
            # EER calculation
            fpr, tpr, thresholds = roc_curve(all_labels, all_scores)
            fnr = 1 - tpr
            eer_idx = np.nanargmin(np.absolute(fnr - fpr))
            eer = fpr[eer_idx]
            results['eer_over_time'].append(eer)
            
            # Overall accuracy using EER threshold
            threshold = thresholds[eer_idx]
            predictions = [1 if score >= threshold else 0 for score in all_scores]
            accuracy = accuracy_score(all_labels, predictions)
            results['accuracy_over_time'].append(accuracy)
        
        # Summary statistics
        final_roc_auc = results['roc_auc_over_time'][-1] if results['roc_auc_over_time'] else 0.0
        
        summary = f"""
        Verification Accuracy Analysis:
        - Final ROC AUC: {final_roc_auc:.4f}
        - Final EER: {results['eer_over_time'][-1]:.4f if results['eer_over_time'] else 'N/A'}
        """
        
        passed = final_roc_auc > 0.8
        
        return ValidationResults(
            metric_name="Verification Accuracy Over Time",
            values=results,
            summary=summary.strip(),
            passed=passed
        )


class GenuineImpostorValidator(BaseValidator):
    """✅ 2. Genuine-Impostor Score Separation Validator."""
    
    def get_validator_name(self) -> str:
        return "Genuine-Impostor Score Separation"
    
    def validate(self, templates: Dict[str, TemplateState], 
                pairs: List[Tuple[str, str, bool]]) -> ValidationResults:
        """
        Validate genuine vs impostor score separation.
        
        Args:
            templates: Current templates for all identities
            pairs: Verification pairs (id1, id2, is_genuine)
        """
        
        genuine_scores = []
        impostor_scores = []
        
        # Calculate similarity scores
        for id1, id2, is_genuine in pairs:
            if id1 in templates and id2 in templates:
                template1 = templates[id1]
                template2 = templates[id2]
                
                score = cosine_similarity(
                    template1.embedding.reshape(1, -1),
                    template2.embedding.reshape(1, -1)
                )[0, 0]
                
                if is_genuine:
                    genuine_scores.append(score)
                else:
                    impostor_scores.append(score)
        
        if len(genuine_scores) == 0 or len(impostor_scores) == 0:
            return ValidationResults(
                metric_name="Genuine-Impostor Separation",
                values={},
                summary="Insufficient data for analysis",
                passed=False
            )
        
        # Calculate separation metrics
        genuine_mean = np.mean(genuine_scores)
        genuine_std = np.std(genuine_scores)
        impostor_mean = np.mean(impostor_scores)
        impostor_std = np.std(impostor_scores)
        
        # Separation gap
        separation_gap = genuine_mean - impostor_mean
        
        # Statistical tests
        t_stat, p_value = stats.ttest_ind(genuine_scores, impostor_scores)
        effect_size = (genuine_mean - impostor_mean) / np.sqrt((genuine_std**2 + impostor_std**2) / 2)
        
        results = {
            'genuine_scores': genuine_scores,
            'impostor_scores': impostor_scores,
            'genuine_mean': genuine_mean,
            'genuine_std': genuine_std,
            'impostor_mean': impostor_mean,
            'impostor_std': impostor_std,
            'separation_gap': separation_gap,
            't_statistic': t_stat,
            'p_value': p_value,
            'effect_size': effect_size
        }
        
        summary = f"""
        Genuine-Impostor Separation Analysis:
        - Genuine Mean: {genuine_mean:.4f} ± {genuine_std:.4f}
        - Impostor Mean: {impostor_mean:.4f} ± {impostor_std:.4f}
        - Separation Gap: {separation_gap:.4f}
        - Effect Size: {effect_size:.2f}
        """
        
        passed = (separation_gap > 0.1 and effect_size > 0.8 and p_value < 0.01)
        
        return ValidationResults(
            metric_name="Genuine-Impostor Separation",
            values=results,
            summary=summary.strip(),
            passed=passed
        )


class DriftRobustnessValidator(BaseValidator):
    """✅ 3. Template Drift Robustness Validator."""
    
    def get_validator_name(self) -> str:
        return "Template Drift Robustness"
    
    def validate(self, templates_history: Dict[str, List[TemplateState]]) -> ValidationResults:
        """
        Validate template drift characteristics.
        
        Args:
            templates_history: Historical template states for all identities
        """
        
        results = {
            'per_identity_drift': {},
            'drift_statistics': {}
        }
        
        all_total_drifts = []
        all_drift_rates = []
        
        for identity, history in templates_history.items():
            if len(history) < 2:
                continue
            
            final_template = history[-1]
            total_drift = getattr(final_template, 'total_drift', 0)
            drift_history = getattr(final_template, 'drift_history', [])
            
            drift_rate = total_drift / len(drift_history) if len(drift_history) > 0 else 0
            
            results['per_identity_drift'][identity] = {
                'total_drift': total_drift,
                'drift_rate': drift_rate,
                'n_updates': len(drift_history)
            }
            
            all_total_drifts.append(total_drift)
            all_drift_rates.append(drift_rate)
        
        if len(all_total_drifts) == 0:
            return ValidationResults(
                metric_name="Template Drift Robustness",
                values={},
                summary="No drift data available",
                passed=False
            )
        
        results['drift_statistics'] = {
            'mean_total_drift': np.mean(all_total_drifts),
            'std_total_drift': np.std(all_total_drifts),
            'mean_drift_rate': np.mean(all_drift_rates),
            'std_drift_rate': np.std(all_drift_rates)
        }
        
        mean_drift = results['drift_statistics']['mean_total_drift']
        
        summary = f"""
        Template Drift Robustness Analysis:
        - Mean Total Drift: {mean_drift:.4f}
        - Mean Drift Rate: {results['drift_statistics']['mean_drift_rate']:.4f}
        - Identities Analyzed: {len(all_total_drifts)}
        """
        
        passed = (0.01 < mean_drift < 0.5)
        
        return ValidationResults(
            metric_name="Template Drift Robustness",
            values=results,
            summary=summary.strip(),
            passed=passed
        )


class UpdateStabilityValidator(BaseValidator):
    """✅ 4. Update Stability & Sensitivity Validator."""
    
    def get_validator_name(self) -> str:
        return "Update Stability & Sensitivity"
    
    def validate(self, updater: GatedEMAUpdater) -> ValidationResults:
        """
        Validate update stability and sensitivity.
        
        Args:
            updater: GatedEMAUpdater instance with update history
        """
        
        update_stats = updater.get_update_statistics()
        if not update_stats:
            return ValidationResults(
                metric_name="Update Stability & Sensitivity",
                values={},
                summary="No update data available",
                passed=False
            )
        
        update_frequency = 1 - update_stats.get('rejection_rate', 1)
        
        results = {
            'update_frequency': update_frequency,
            'rejection_rate': update_stats.get('rejection_rate', 0),
            'rejection_reasons': update_stats.get('rejection_reasons', {}),
            'average_similarity': update_stats.get('average_similarity', 0)
        }
        
        summary = f"""
        Update Stability Analysis:
        - Update Frequency: {update_frequency:.2%}
        - Average Similarity: {results['average_similarity']:.4f}
        """
        
        passed = (0.1 < update_frequency < 0.8)
        
        return ValidationResults(
            metric_name="Update Stability & Sensitivity",
            values=results,
            summary=summary.strip(),
            passed=passed
        )


class AblationStudyValidator(BaseValidator):
    """✅ 5. Ablation Study Validator."""
    
    def get_validator_name(self) -> str:
        return "Ablation Study Comparison"
    
    def validate(self, strategy_results: Dict[str, Dict[str, Any]]) -> ValidationResults:
        """
        Validate performance across different strategies.
        
        Args:
            strategy_results: Dict mapping strategy names to their results
        """
        
        if len(strategy_results) < 2:
            return ValidationResults(
                metric_name="Ablation Study",
                values={},
                summary="Insufficient strategies for comparison",
                passed=False
            )
        
        comparison_metrics = ['roc_auc', 'eer', 'accuracy']
        results = {
            'strategies': list(strategy_results.keys()),
            'comparison_table': {},
            'rankings': {}
        }
        
        for metric in comparison_metrics:
            results['comparison_table'][metric] = {}
            metric_values = []
            
            for strategy, strategy_data in strategy_results.items():
                value = strategy_data.get(metric, None)
                if value is not None:
                    results['comparison_table'][metric][strategy] = value
                    metric_values.append((strategy, value))
            
            # Rank strategies for this metric
            if metric in ['roc_auc', 'accuracy']:
                ranked = sorted(metric_values, key=lambda x: x[1], reverse=True)
            else:
                ranked = sorted(metric_values, key=lambda x: x[1])
            
            results['rankings'][metric] = [strategy for strategy, _ in ranked]
        
        best_strategy = results['rankings']['roc_auc'][0] if 'roc_auc' in results['rankings'] else 'Unknown'
        
        summary = f"""
        Ablation Study Results:
        - Strategies Compared: {len(strategy_results)}
        - Best Strategy (ROC AUC): {best_strategy}
        """
        
        # Check if any gated EMA is performing well
        gated_strategies = [s for s in strategy_results.keys() if 'gated' in s.lower()]
        passed = any(s in results['rankings']['roc_auc'][:2] for s in gated_strategies) if 'roc_auc' in results['rankings'] else False
        
        return ValidationResults(
            metric_name="Ablation Study",
            values=results,  
            summary=summary.strip(),
            passed=passed
        )


class RealWorldSimulationValidator(BaseValidator):
    """✅ 6. Real-World Simulation Validator."""
    
    def get_validator_name(self) -> str:
        return "Real-World Simulation"
    
    def validate(self, simulation_logs: List[Dict[str, Any]]) -> ValidationResults:
        """
        Validate real-world simulation performance.
        
        Args:
            simulation_logs: Logs from simulated authentication sessions
        """
        
        if len(simulation_logs) == 0:
            return ValidationResults(
                metric_name="Real-World Simulation",
                values={},
                summary="No simulation data available",
                passed=False
            )
        
        # Analyze authentication success rates over time
        session_performance = []
        template_consistency = []
        false_accept_rates = []
        false_reject_rates = []
        
        for log in simulation_logs:
            session_id = log.get('session_id')
            authentications = log.get('authentications', [])
            
            if len(authentications) == 0:
                continue
            
            # Calculate session metrics
            successes = sum(1 for auth in authentications if auth.get('success', False))
            success_rate = successes / len(authentications)
            session_performance.append(success_rate)
            
            # Template consistency (if tracked)
            if 'template_drift' in log:
                template_consistency.append(log['template_drift'])
            
            # FAR/FRR (if tracked)
            if 'false_accepts' in log and 'false_rejects' in log:
                total_attempts = log.get('total_attempts', 1)
                false_accept_rates.append(log['false_accepts'] / total_attempts)
                false_reject_rates.append(log['false_rejects'] / total_attempts)
        
        results = {
            'n_sessions': len(simulation_logs),
            'mean_session_performance': np.mean(session_performance) if session_performance else 0,
            'performance_stability': 1 - np.std(session_performance) if len(session_performance) > 1 else 1,
            'mean_template_consistency': np.mean(template_consistency) if template_consistency else 1,
            'mean_far': np.mean(false_accept_rates) if false_accept_rates else 0,
            'mean_frr': np.mean(false_reject_rates) if false_reject_rates else 0
        }
        
        summary = f"""
        Real-World Simulation Analysis:
        - Sessions Simulated: {results['n_sessions']}
        - Average Success Rate: {results['mean_session_performance']:.2%}
        - Performance Stability: {results['performance_stability']:.4f}
        - Template Consistency: {results['mean_template_consistency']:.4f}
        - Average FAR: {results['mean_far']:.4f}
        - Average FRR: {results['mean_frr']:.4f}
        """
        
        # Pass criteria: high success rate with stability
        passed = (results['mean_session_performance'] > 0.85 and 
                 results['performance_stability'] > 0.8 and
                 results['mean_far'] < 0.05)
        
        return ValidationResults(
            metric_name="Real-World Simulation",
            values=results,
            summary=summary.strip(),
            passed=passed
        ) 