"""
Quick CACD Test - Reduced dataset for faster processing
"""

import os
import sys
import numpy as np
import cv2
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Import validation components
from enhanced_ema_study import TemplateState, StaticTemplateStrategy, EMATemplateStrategy, GatedEMATemplateStrategy
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import normalize

def extract_simple_features(image_path):
    """Extract simple features from face image"""
    try:
        # Read image
        image = cv2.imread(str(image_path))
        if image is None:
            return None
        
        # Resize to small size for speed
        image = cv2.resize(image, (32, 32))
        
        # Simple features: color means, texture info
        features = []
        
        # Color channel means
        for channel in range(3):
            features.append(np.mean(image[:,:,channel]))
            features.append(np.std(image[:,:,channel]))
        
        # Simple gradient features
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        
        features.extend([
            np.mean(np.abs(grad_x)),
            np.mean(np.abs(grad_y)),
            np.std(grad_x),
            np.std(grad_y)
        ])
        
        # Pad to 512 dimensions
        features = np.array(features)
        if len(features) < 512:
            padding = np.random.randn(512 - len(features)) * 0.01
            features = np.concatenate([features, padding])
        else:
            features = features[:512]
        
        # Normalize
        features = normalize(features.reshape(1, -1))[0]
        
        return features
        
    except Exception as e:
        print(f"Error processing {image_path}: {e}")
        return None

def quick_test():
    """Quick test with reduced dataset"""
    print("="*50)
    print("QUICK CACD TEST - REAL FACE DATA")
    print("="*50)
    
    # Load limited CACD data
    cacd_path = Path("../data/cacd_split/cacd_split")
    if not cacd_path.exists():
        print(f"ERROR: CACD directory not found: {cacd_path}")
        return
    
    # Get only first 5 people
    person_dirs = [d for d in cacd_path.iterdir() if d.is_dir()][:5]
    
    print(f"Processing {len(person_dirs)} people...")
    
    embeddings = []
    labels = []
    person_names = []
    
    for person_idx, person_dir in enumerate(person_dirs):
        print(f"  Processing {person_dir.name}")
        
        # Get only first 10 images per person
        image_files = []
        for ext in ['*.jpg', '*.jpeg', '*.png']:
            image_files.extend(list(person_dir.glob(ext)))
        
        image_files = image_files[:10]
        person_embeddings = []
        
        for img_file in image_files:
            embedding = extract_simple_features(img_file)
            if embedding is not None:
                person_embeddings.append(embedding)
        
        if len(person_embeddings) >= 3:
            embeddings.extend(person_embeddings)
            labels.extend([person_idx] * len(person_embeddings))
            person_names.append(person_dir.name)
            print(f"    Added {len(person_embeddings)} embeddings")
    
    embeddings = np.array(embeddings)
    labels = np.array(labels)
    
    print(f"\nDataset: {len(embeddings)} embeddings from {len(person_names)} people")
    print(f"People: {person_names}")
    
    # Create verification pairs
    pairs = []
    
    # Genuine pairs
    for label in np.unique(labels):
        indices = np.where(labels == label)[0]
        if len(indices) >= 2:
            for i in range(min(3, len(indices))):
                for j in range(i+1, min(i+4, len(indices))):
                    pairs.append((indices[i], indices[j], 1))
    
    # Impostor pairs
    unique_labels = np.unique(labels)
    for _ in range(len(pairs)):
        label1, label2 = np.random.choice(unique_labels, 2, replace=False)
        idx1 = np.random.choice(np.where(labels == label1)[0])
        idx2 = np.random.choice(np.where(labels == label2)[0])
        pairs.append((idx1, idx2, 0))
    
    print(f"Verification pairs: {len(pairs)}")
    
    # Test strategies
    strategies = {
        'Static': StaticTemplateStrategy(),
        'EMA': EMATemplateStrategy(alpha=0.3),
        'Gated EMA': GatedEMATemplateStrategy(alpha=0.3, confidence_threshold=0.7)
    }
    
    results = {}
    
    for name, strategy in strategies.items():
        print(f"\nTesting {name}...")
        
        # Initialize templates
        templates = {}
        for label in np.unique(labels):
            indices = np.where(labels == label)[0]
            initial_embedding = embeddings[indices[0]]
            templates[label] = TemplateState(
                embedding=initial_embedding,
                confidence=0.8,
                age=0
            )
        
        # Simulate updates
        updates = 0
        decisions = 0
        
        for label in np.unique(labels):
            indices = np.where(labels == label)[0]
            template = templates[label]
            
            for age_idx, idx in enumerate(indices[1:], 1):
                new_embedding = embeddings[idx]
                
                updated_template = strategy.update_template(
                    template, new_embedding, 0.8, age_idx
                )
                
                decisions += 1
                if not np.allclose(template.embedding, updated_template.embedding):
                    updates += 1
                
                templates[label] = updated_template
                template = updated_template
        
        # Verification
        scores = []
        true_labels = []
        
        for idx1, idx2, label in pairs:
            label1, label2 = labels[idx1], labels[idx2]
            
            emb1 = templates[label1].embedding
            emb2 = templates[label2].embedding
            
            score = np.dot(emb1, emb2)
            scores.append(score)
            true_labels.append(label)
        
        # Calculate metrics
        auc = roc_auc_score(true_labels, scores)
        update_rate = updates / max(1, decisions)
        
        results[name] = {
            'auc': auc,
            'updates': updates,
            'decisions': decisions,
            'update_rate': update_rate
        }
        
        print(f"  ROC AUC: {auc:.4f}")
        print(f"  Updates: {updates}/{decisions} ({update_rate:.1%})")
    
    # Final results
    print("\n" + "="*50)
    print("QUICK TEST RESULTS")
    print("="*50)
    
    sorted_results = sorted(results.items(), key=lambda x: x[1]['auc'], reverse=True)
    
    for rank, (name, result) in enumerate(sorted_results, 1):
        status = "[BEST]" if rank == 1 else f"[#{rank}]"
        print(f"{status} {name}:")
        print(f"    ROC AUC: {result['auc']:.4f}")
        print(f"    Update Rate: {result['update_rate']:.1%}")
    
    # Key finding
    if 'Gated EMA' in results and 'Static' in results:
        gated_auc = results['Gated EMA']['auc']
        static_auc = results['Static']['auc']
        improvement = gated_auc - static_auc
        
        print(f"\n[KEY FINDING] Gated EMA vs Static:")
        print(f"  Improvement: {improvement:.4f} ({improvement/static_auc*100:.1f}%)")
        
        if improvement > 0:
            print(f"  [CONCLUSION] Gated EMA ENHANCES accuracy on real CACD data!")
        else:
            print(f"  [CONCLUSION] Gated EMA does not improve accuracy on this subset")
    
    # Save results
    with open("quick_cacd_results.txt", "w") as f:
        f.write("QUICK CACD TEST RESULTS\n")
        f.write("="*30 + "\n\n")
        f.write(f"Dataset: {len(embeddings)} embeddings from {len(person_names)} people\n")
        f.write(f"People: {person_names}\n\n")
        
        for name, result in sorted_results:
            f.write(f"{name}:\n")
            f.write(f"  ROC AUC: {result['auc']:.4f}\n")
            f.write(f"  Update Rate: {result['update_rate']:.1%}\n\n")
    
    print(f"\nResults saved to: quick_cacd_results.txt")

if __name__ == "__main__":
    quick_test() 