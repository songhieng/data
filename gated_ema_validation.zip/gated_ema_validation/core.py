"""
Core Gated EMA Implementation with Validation Hooks
===================================================

This module implements the Gated EMA algorithm with comprehensive tracking
and validation hooks for performance analysis.
"""

import numpy as np
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
import logging
from sklearn.metrics.pairwise import cosine_similarity
import time

from .config import GatedEMAConfig

logger = logging.getLogger(__name__)


@dataclass
class TemplateState:
    """Enhanced template state with comprehensive tracking."""
    
    # Core template data
    embedding: np.ndarray
    confidence: float
    creation_time: float = field(default_factory=time.time)
    
    # Update tracking
    update_count: int = 0
    last_update_time: float = field(default_factory=time.time)
    
    # Drift tracking
    total_drift: float = 0.0
    drift_history: List[float] = field(default_factory=list)
    update_magnitudes: List[float] = field(default_factory=list)
    
    # Quality tracking
    confidence_history: List[float] = field(default_factory=list)
    embedding_norms: List[float] = field(default_factory=list)
    
    # Temporal tracking
    age_at_creation: Optional[int] = None
    current_age: Optional[int] = None
    
    # Session tracking
    session_updates: int = 0
    sessions_participated: int = 0
    
    def __post_init__(self):
        """Initialize tracking lists with initial values."""
        if len(self.confidence_history) == 0:
            self.confidence_history.append(self.confidence)
        if len(self.embedding_norms) == 0:
            self.embedding_norms.append(np.linalg.norm(self.embedding))


@dataclass
class UpdateDecision:
    """Records the decision and reasoning for template updates."""
    
    should_update: bool
    similarity_score: float
    confidence_score: float
    threshold_used: float
    
    # Decision factors
    passed_similarity_check: bool
    passed_confidence_check: bool
    passed_quality_check: bool
    passed_cooldown_check: bool
    
    # Contextual information
    time_since_last_update: float
    session_update_count: int
    embedding_norm: float
    
    # Rejection reasons (if not updated)
    rejection_reason: Optional[str] = None


class TemplateUpdateStrategy(ABC):
    """Abstract base class for template update strategies."""
    
    @abstractmethod
    def should_update(self, current_template: TemplateState, 
                     new_embedding: np.ndarray, 
                     new_confidence: float,
                     context: Dict[str, Any]) -> UpdateDecision:
        """Decide whether to update the template."""
        pass
    
    @abstractmethod
    def update_template(self, current_template: TemplateState,
                       new_embedding: np.ndarray,
                       new_confidence: float,
                       decision: UpdateDecision) -> TemplateState:
        """Apply the template update."""
        pass
    
    @abstractmethod
    def get_strategy_name(self) -> str:
        """Return strategy name for logging."""
        pass


class StaticStrategy(TemplateUpdateStrategy):
    """Static template strategy - no updates."""
    
    def should_update(self, current_template: TemplateState, 
                     new_embedding: np.ndarray, 
                     new_confidence: float,
                     context: Dict[str, Any]) -> UpdateDecision:
        """Always return false for static strategy."""
        return UpdateDecision(
            should_update=False,
            similarity_score=0.0,
            confidence_score=new_confidence,
            threshold_used=1.0,
            passed_similarity_check=False,
            passed_confidence_check=False,
            passed_quality_check=False,
            passed_cooldown_check=False,
            time_since_last_update=context.get('time_since_last_update', 0),
            session_update_count=current_template.session_updates,
            embedding_norm=np.linalg.norm(new_embedding),
            rejection_reason="Static strategy"
        )
    
    def update_template(self, current_template: TemplateState,
                       new_embedding: np.ndarray,
                       new_confidence: float,
                       decision: UpdateDecision) -> TemplateState:
        """Return unchanged template."""
        return current_template
    
    def get_strategy_name(self) -> str:
        return "Static"


class FixedEMAStrategy(TemplateUpdateStrategy):
    """Fixed EMA strategy - always update with fixed alpha."""
    
    def __init__(self, alpha: float = 0.3):
        self.alpha = alpha
    
    def should_update(self, current_template: TemplateState, 
                     new_embedding: np.ndarray, 
                     new_confidence: float,
                     context: Dict[str, Any]) -> UpdateDecision:
        """Always return true for fixed EMA."""
        return UpdateDecision(
            should_update=True,
            similarity_score=1.0,  # Always "passes"
            confidence_score=new_confidence,
            threshold_used=0.0,
            passed_similarity_check=True,
            passed_confidence_check=True,
            passed_quality_check=True,
            passed_cooldown_check=True,
            time_since_last_update=context.get('time_since_last_update', 0),
            session_update_count=current_template.session_updates,
            embedding_norm=np.linalg.norm(new_embedding)
        )
    
    def update_template(self, current_template: TemplateState,
                       new_embedding: np.ndarray,
                       new_confidence: float,
                       decision: UpdateDecision) -> TemplateState:
        """Apply fixed EMA update."""
        # Calculate updated embedding
        updated_embedding = (self.alpha * new_embedding + 
                           (1 - self.alpha) * current_template.embedding)
        updated_embedding = updated_embedding / np.linalg.norm(updated_embedding)
        
        # Calculate drift
        drift = 1 - cosine_similarity(
            current_template.embedding.reshape(1, -1),
            updated_embedding.reshape(1, -1)
        )[0, 0]
        
        # Update tracking
        new_template = TemplateState(
            embedding=updated_embedding,
            confidence=new_confidence,
            creation_time=current_template.creation_time,
            update_count=current_template.update_count + 1,
            last_update_time=time.time(),
            total_drift=current_template.total_drift + drift,
            drift_history=current_template.drift_history + [drift],
            update_magnitudes=current_template.update_magnitudes + [np.linalg.norm(new_embedding - current_template.embedding)],
            confidence_history=current_template.confidence_history + [new_confidence],
            embedding_norms=current_template.embedding_norms + [np.linalg.norm(updated_embedding)],
            age_at_creation=current_template.age_at_creation,
            current_age=context.get('current_age', current_template.current_age),
            session_updates=current_template.session_updates + 1,
            sessions_participated=current_template.sessions_participated
        )
        
        return new_template
    
    def get_strategy_name(self) -> str:
        return f"FixedEMA(α={self.alpha})"


class GatedEMAStrategy(TemplateUpdateStrategy):
    """Gated EMA strategy with comprehensive validation tracking."""
    
    def __init__(self, config: GatedEMAConfig):
        self.config = config
        self.update_history: List[UpdateDecision] = []
    
    def should_update(self, current_template: TemplateState, 
                     new_embedding: np.ndarray, 
                     new_confidence: float,
                     context: Dict[str, Any]) -> UpdateDecision:
        """Comprehensive gating decision with detailed tracking."""
        
        # Calculate similarity
        similarity = cosine_similarity(
            current_template.embedding.reshape(1, -1),
            new_embedding.reshape(1, -1)
        )[0, 0]
        
        # Initialize checks
        passed_similarity = similarity >= self.config.confidence_threshold
        passed_confidence = new_confidence >= 0.5  # Basic quality threshold
        passed_quality = np.linalg.norm(new_embedding) >= self.config.min_embedding_norm
        
        # Cooldown check
        time_since_last = time.time() - current_template.last_update_time
        passed_cooldown = time_since_last >= self.config.cooldown_period
        
        # Session limit check
        passed_session_limit = current_template.session_updates < self.config.max_updates_per_session
        
        # Overall decision
        should_update = (passed_similarity and passed_confidence and 
                        passed_quality and passed_cooldown and passed_session_limit)
        
        # Determine rejection reason
        rejection_reason = None
        if not should_update:
            reasons = []
            if not passed_similarity:
                reasons.append(f"Low similarity ({similarity:.3f} < {self.config.confidence_threshold})")
            if not passed_confidence:
                reasons.append(f"Low confidence ({new_confidence:.3f})")
            if not passed_quality:
                reasons.append(f"Low embedding norm ({np.linalg.norm(new_embedding):.3f})")
            if not passed_cooldown:
                reasons.append(f"Cooldown period ({time_since_last:.1f}s < {self.config.cooldown_period}s)")
            if not passed_session_limit:
                reasons.append(f"Session limit ({current_template.session_updates} >= {self.config.max_updates_per_session})")
            rejection_reason = "; ".join(reasons)
        
        decision = UpdateDecision(
            should_update=should_update,
            similarity_score=similarity,
            confidence_score=new_confidence,
            threshold_used=self.config.confidence_threshold,
            passed_similarity_check=passed_similarity,
            passed_confidence_check=passed_confidence,
            passed_quality_check=passed_quality,
            passed_cooldown_check=passed_cooldown,
            time_since_last_update=time_since_last,
            session_update_count=current_template.session_updates,
            embedding_norm=np.linalg.norm(new_embedding),
            rejection_reason=rejection_reason
        )
        
        self.update_history.append(decision)
        return decision
    
    def update_template(self, current_template: TemplateState,
                       new_embedding: np.ndarray,
                       new_confidence: float,
                       decision: UpdateDecision) -> TemplateState:
        """Apply gated EMA update with comprehensive tracking."""
        
        if not decision.should_update:
            return current_template
        
        # Adaptive alpha (if enabled)
        alpha = self.config.alpha
        if self.config.adaptive_alpha:
            # Higher similarity -> higher alpha (more aggressive update)
            alpha_range = self.config.max_alpha - self.config.min_alpha
            alpha = self.config.min_alpha + alpha_range * decision.similarity_score
            alpha = np.clip(alpha, self.config.min_alpha, self.config.max_alpha)
        
        # Calculate updated embedding
        updated_embedding = (alpha * new_embedding + 
                           (1 - alpha) * current_template.embedding)
        updated_embedding = updated_embedding / np.linalg.norm(updated_embedding)
        
        # Calculate drift
        drift = 1 - cosine_similarity(
            current_template.embedding.reshape(1, -1),
            updated_embedding.reshape(1, -1)
        )[0, 0]
        
        # Check max drift constraint
        if drift > self.config.max_drift_per_update:
            logger.warning(f"Update would cause excessive drift ({drift:.3f} > {self.config.max_drift_per_update})")
            return current_template
        
        # Create updated template with comprehensive tracking
        new_template = TemplateState(
            embedding=updated_embedding,
            confidence=new_confidence,
            creation_time=current_template.creation_time,
            update_count=current_template.update_count + 1,
            last_update_time=time.time(),
            total_drift=current_template.total_drift + drift,
            drift_history=current_template.drift_history + [drift],
            update_magnitudes=current_template.update_magnitudes + [np.linalg.norm(new_embedding - current_template.embedding)],
            confidence_history=current_template.confidence_history + [new_confidence],
            embedding_norms=current_template.embedding_norms + [np.linalg.norm(updated_embedding)],
            age_at_creation=current_template.age_at_creation,
            current_age=context.get('current_age', current_template.current_age),
            session_updates=current_template.session_updates + 1,
            sessions_participated=current_template.sessions_participated
        )
        
        return new_template
    
    def get_strategy_name(self) -> str:
        return f"GatedEMA(α={self.config.alpha},τ={self.config.confidence_threshold})"


class GatedEMAUpdater:
    """Main class for managing Gated EMA template updates with validation."""
    
    def __init__(self, config: GatedEMAConfig):
        self.config = config
        self.strategy = GatedEMAStrategy(config)
        self.templates: Dict[str, TemplateState] = {}
        self.update_log: List[Dict[str, Any]] = []
    
    def initialize_template(self, identity_id: str, 
                          initial_embedding: np.ndarray,
                          initial_confidence: float,
                          age: Optional[int] = None) -> TemplateState:
        """Initialize a new template for an identity."""
        template = TemplateState(
            embedding=initial_embedding / np.linalg.norm(initial_embedding),
            confidence=initial_confidence,
            age_at_creation=age,
            current_age=age
        )
        
        self.templates[identity_id] = template
        logger.info(f"Initialized template for identity {identity_id}")
        return template
    
    def update_template(self, identity_id: str,
                       new_embedding: np.ndarray,
                       new_confidence: float,
                       context: Optional[Dict[str, Any]] = None) -> Tuple[TemplateState, UpdateDecision]:
        """Update template for an identity with full tracking."""
        
        if identity_id not in self.templates:
            raise ValueError(f"No template found for identity {identity_id}")
        
        current_template = self.templates[identity_id]
        context = context or {}
        
        # Make update decision
        decision = self.strategy.should_update(
            current_template, new_embedding, new_confidence, context
        )
        
        # Apply update if approved
        updated_template = self.strategy.update_template(
            current_template, new_embedding, new_confidence, decision
        )
        
        # Store updated template
        self.templates[identity_id] = updated_template
        
        # Log the update
        log_entry = {
            'identity_id': identity_id,
            'timestamp': time.time(),
            'decision': decision,
            'template_state': updated_template,
            'context': context
        }
        self.update_log.append(log_entry)
        
        logger.debug(f"Processed update for {identity_id}: {'Updated' if decision.should_update else 'Rejected'}")
        
        return updated_template, decision
    
    def get_template(self, identity_id: str) -> Optional[TemplateState]:
        """Get current template for an identity."""
        return self.templates.get(identity_id)
    
    def get_update_statistics(self) -> Dict[str, Any]:
        """Get comprehensive update statistics."""
        if not self.update_log:
            return {}
        
        total_updates = len(self.update_log)
        successful_updates = sum(1 for log in self.update_log if log['decision'].should_update)
        rejection_reasons = {}
        
        for log in self.update_log:
            if not log['decision'].should_update and log['decision'].rejection_reason:
                reason = log['decision'].rejection_reason
                rejection_reasons[reason] = rejection_reasons.get(reason, 0) + 1
        
        return {
            'total_decisions': total_updates,
            'successful_updates': successful_updates,
            'rejection_rate': (total_updates - successful_updates) / total_updates if total_updates > 0 else 0,
            'rejection_reasons': rejection_reasons,
            'average_similarity': np.mean([log['decision'].similarity_score for log in self.update_log]),
            'average_confidence': np.mean([log['decision'].confidence_score for log in self.update_log]),
        } 