"""
Ablation Study Comparison Validator
==================================

This validator performs ablation studies to understand the contribution
of different components in the Gated EMA system and provides comparative
analysis across different parameter settings.
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, List, Tuple, Optional, Any
import logging
from itertools import product

logger = logging.getLogger(__name__)


class AblationStudyComparisonValidator:
    """
    Comprehensive validator for ablation study and parameter comparison.
    
    Key Questions Answered:
    1. What is the impact of different alpha values?
    2. How does threshold selection affect performance?
    3. Which components contribute most to performance?
    4. What are the optimal parameter combinations?
    """
    
    def __init__(self, config):
        self.config = config
        self.alpha_values = config.get('alpha_values', [0.1, 0.3, 0.5, 0.7, 0.9])
        self.threshold_values = config.get('threshold_values', [0.5, 0.6, 0.7, 0.8, 0.9])
        self.performance_metric = 'roc_auc'  # Primary metric for comparison
        
    def get_validator_name(self) -> str:
        return "Ablation Study Comparison"
    
    def validate(self, 
                strategy_results: Dict[str, Any],
                strategy_name: str = "Unknown") -> Dict[str, Any]:
        """
        Validate through ablation study and parameter comparison.
        
        Args:
            strategy_results: Results from multiple strategy configurations
            strategy_name: Base name of the strategy being evaluated
            
        Returns:
            Dictionary with comprehensive ablation analysis
        """
        
        logger.info(f"Performing ablation study for {strategy_name}")
        
        if not strategy_results:
            return self._create_empty_result("No strategy results available")
        
        # Parameter sensitivity analysis
        parameter_analysis = self._analyze_parameter_sensitivity(strategy_results)
        
        # Component contribution analysis
        component_analysis = self._analyze_component_contributions(strategy_results)
        
        # Optimal configuration identification
        optimal_config = self._identify_optimal_configuration(strategy_results, parameter_analysis)
        
        # Performance landscape analysis
        landscape_analysis = self._analyze_performance_landscape(strategy_results, parameter_analysis)
        
        # Robustness analysis
        robustness_analysis = self._analyze_parameter_robustness(parameter_analysis)
        
        # Generate insights
        insights = self._generate_ablation_insights(
            parameter_analysis, component_analysis, optimal_config, strategy_name
        )
        
        # Compile results
        results = {
            'parameter_analysis': parameter_analysis,
            'component_analysis': component_analysis,
            'optimal_configuration': optimal_config,
            'landscape_analysis': landscape_analysis,
            'robustness_analysis': robustness_analysis,
            'insights': insights,
            'strategy_name': strategy_name
        }
        
        # Determine pass/fail
        passed, summary = self._evaluate_ablation_results(optimal_config, robustness_analysis, strategy_name)
        
        return {
            'metric_name': self.get_validator_name(),
            'values': results,
            'summary': summary,
            'passed': passed
        }
    
    def _analyze_parameter_sensitivity(self, strategy_results: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze sensitivity to different parameter values."""
        
        analysis = {
            'alpha_sensitivity': {},
            'threshold_sensitivity': {},
            'parameter_interactions': {},
            'sensitivity_metrics': {}
        }
        
        # Extract performance metrics for different configurations
        config_performance = {}
        
        for config_name, results in strategy_results.items():
            # Parse configuration from name (assuming format like "GatedEMA(α=0.3,τ=0.7)")
            alpha, threshold = self._parse_config_parameters(config_name)
            
            # Extract performance metrics
            performance = self._extract_performance_metrics(results)
            
            config_performance[(alpha, threshold)] = {
                'config_name': config_name,
                'performance': performance
            }
        
        # Alpha sensitivity analysis
        alpha_performance = {}
        for alpha in self.alpha_values:
            alpha_results = []
            for (a, t), data in config_performance.items():
                if abs(a - alpha) < 0.01:  # Match alpha value
                    alpha_results.append(data['performance'].get(self.performance_metric, 0))
            
            if alpha_results:
                alpha_performance[alpha] = {
                    'mean': np.mean(alpha_results),
                    'std': np.std(alpha_results),
                    'count': len(alpha_results),
                    'values': alpha_results
                }
        
        analysis['alpha_sensitivity'] = alpha_performance
        
        # Threshold sensitivity analysis
        threshold_performance = {}
        for threshold in self.threshold_values:
            threshold_results = []
            for (a, t), data in config_performance.items():
                if abs(t - threshold) < 0.01:  # Match threshold value
                    threshold_results.append(data['performance'].get(self.performance_metric, 0))
            
            if threshold_results:
                threshold_performance[threshold] = {
                    'mean': np.mean(threshold_results),
                    'std': np.std(threshold_results),
                    'count': len(threshold_results),
                    'values': threshold_results
                }
        
        analysis['threshold_sensitivity'] = threshold_performance
        
        # Calculate sensitivity metrics
        if alpha_performance:
            alpha_means = [data['mean'] for data in alpha_performance.values()]
            analysis['sensitivity_metrics']['alpha_range'] = max(alpha_means) - min(alpha_means)
            analysis['sensitivity_metrics']['alpha_variance'] = np.var(alpha_means)
        
        if threshold_performance:
            threshold_means = [data['mean'] for data in threshold_performance.values()]
            analysis['sensitivity_metrics']['threshold_range'] = max(threshold_means) - min(threshold_means)
            analysis['sensitivity_metrics']['threshold_variance'] = np.var(threshold_means)
        
        return analysis
    
    def _parse_config_parameters(self, config_name: str) -> Tuple[float, float]:
        """Parse alpha and threshold values from configuration name."""
        
        # Default values
        alpha, threshold = 0.3, 0.7
        
        try:
            # Extract alpha value
            if 'α=' in config_name:
                alpha_part = config_name.split('α=')[1].split(',')[0].split(')')[0]
                alpha = float(alpha_part)
            
            # Extract threshold value
            if 'τ=' in config_name:
                threshold_part = config_name.split('τ=')[1].split(',')[0].split(')')[0]
                threshold = float(threshold_part)
                
        except (ValueError, IndexError) as e:
            logger.warning(f"Could not parse parameters from {config_name}: {e}")
        
        return alpha, threshold
    
    def _extract_performance_metrics(self, results: Dict[str, Any]) -> Dict[str, float]:
        """Extract performance metrics from strategy results."""
        
        metrics = {}
        
        # Try to extract from validation results
        validation_results = results.get('validation_results', {})
        
        # Extract ROC AUC from accuracy validation
        accuracy_validation = validation_results.get('accuracy_over_time', {})
        if accuracy_validation.get('values'):
            accuracy_data = accuracy_validation['values'].get('accuracy_evolution', {})
            if accuracy_data.get('roc_auc_over_time'):
                metrics['roc_auc'] = accuracy_data['roc_auc_over_time'][-1]
                metrics['roc_auc_improvement'] = (accuracy_data['roc_auc_over_time'][-1] - 
                                                accuracy_data['roc_auc_over_time'][0])
        
        # Extract separation metrics
        separation_validation = validation_results.get('genuine_impostor_separation', {})
        if separation_validation.get('values'):
            separation_data = separation_validation['values'].get('statistical_analysis', {})
            metrics['separation_gap'] = separation_data.get('separation_gap', 0)
            metrics['effect_size'] = separation_data.get('effect_size', 0)
        
        # Extract drift metrics
        drift_validation = validation_results.get('template_drift_robustness', {})
        if drift_validation.get('values'):
            drift_data = drift_validation['values'].get('drift_analysis', {})
            drift_stats = drift_data.get('drift_statistics', {})
            metrics['mean_drift'] = drift_stats.get('mean_total_drift', 0)
        
        return metrics
    
    def _analyze_component_contributions(self, strategy_results: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze the contribution of different system components."""
        
        analysis = {
            'gating_contribution': 0.0,
            'ema_contribution': 0.0,
            'threshold_contribution': 0.0,
            'component_rankings': []
        }
        
        # Compare different strategy types if available
        static_performance = None
        ema_performance = None
        gated_ema_performance = None
        
        for config_name, results in strategy_results.items():
            performance = self._extract_performance_metrics(results)
            roc_auc = performance.get('roc_auc', 0)
            
            if 'static' in config_name.lower():
                static_performance = roc_auc
            elif 'gated' not in config_name.lower() and 'ema' in config_name.lower():
                ema_performance = roc_auc
            elif 'gated' in config_name.lower():
                if gated_ema_performance is None or roc_auc > gated_ema_performance:
                    gated_ema_performance = roc_auc
        
        # Calculate component contributions
        if static_performance is not None and ema_performance is not None:
            analysis['ema_contribution'] = ema_performance - static_performance
        
        if ema_performance is not None and gated_ema_performance is not None:
            analysis['gating_contribution'] = gated_ema_performance - ema_performance
        
        # Rank components by contribution
        contributions = []
        if analysis['ema_contribution'] != 0.0:
            contributions.append(('EMA', analysis['ema_contribution']))
        if analysis['gating_contribution'] != 0.0:
            contributions.append(('Gating', analysis['gating_contribution']))
        
        analysis['component_rankings'] = sorted(contributions, key=lambda x: abs(x[1]), reverse=True)
        
        return analysis
    
    def _identify_optimal_configuration(self, 
                                      strategy_results: Dict[str, Any],
                                      parameter_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Identify optimal parameter configuration."""
        
        optimal = {
            'best_config': None,
            'best_performance': 0.0,
            'optimal_alpha': None,
            'optimal_threshold': None,
            'performance_metrics': {}
        }
        
        best_performance = -float('inf')
        best_config = None
        
        # Find best overall configuration
        for config_name, results in strategy_results.items():
            performance_metrics = self._extract_performance_metrics(results)
            primary_metric = performance_metrics.get(self.performance_metric, 0)
            
            if primary_metric > best_performance:
                best_performance = primary_metric
                best_config = config_name
                optimal['performance_metrics'] = performance_metrics
        
        if best_config:
            optimal['best_config'] = best_config
            optimal['best_performance'] = best_performance
            optimal['optimal_alpha'], optimal['optimal_threshold'] = self._parse_config_parameters(best_config)
        
        # Find optimal alpha (averaged across thresholds)
        alpha_sensitivity = parameter_analysis.get('alpha_sensitivity', {})
        if alpha_sensitivity:
            best_alpha = max(alpha_sensitivity.keys(), key=lambda a: alpha_sensitivity[a]['mean'])
            optimal['optimal_alpha'] = best_alpha
        
        # Find optimal threshold (averaged across alphas)
        threshold_sensitivity = parameter_analysis.get('threshold_sensitivity', {})
        if threshold_sensitivity:
            best_threshold = max(threshold_sensitivity.keys(), key=lambda t: threshold_sensitivity[t]['mean'])
            optimal['optimal_threshold'] = best_threshold
        
        return optimal
    
    def _analyze_performance_landscape(self, 
                                     strategy_results: Dict[str, Any],
                                     parameter_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze the performance landscape across parameter space."""
        
        landscape = {
            'performance_surface': {},
            'local_optima': [],
            'parameter_interactions': {},
            'landscape_characteristics': {}
        }
        
        # Build performance surface
        performance_grid = {}
        for config_name, results in strategy_results.items():
            alpha, threshold = self._parse_config_parameters(config_name)
            performance = self._extract_performance_metrics(results)
            primary_metric = performance.get(self.performance_metric, 0)
            
            performance_grid[(alpha, threshold)] = primary_metric
        
        landscape['performance_surface'] = performance_grid
        
        # Find local optima
        for (alpha, threshold), performance in performance_grid.items():
            is_local_optimum = True
            
            # Check neighboring points
            for da, dt in [(-0.1, 0), (0.1, 0), (0, -0.1), (0, 0.1)]:
                neighbor = (alpha + da, threshold + dt)
                if neighbor in performance_grid:
                    if performance_grid[neighbor] > performance:
                        is_local_optimum = False
                        break
            
            if is_local_optimum:
                landscape['local_optima'].append({
                    'alpha': alpha,
                    'threshold': threshold,
                    'performance': performance
                })
        
        # Analyze landscape characteristics
        if performance_grid:
            performances = list(performance_grid.values())
            landscape['landscape_characteristics'] = {
                'performance_range': max(performances) - min(performances),
                'performance_variance': np.var(performances),
                'num_configurations': len(performances),
                'num_local_optima': len(landscape['local_optima'])
            }
        
        return landscape
    
    def _analyze_parameter_robustness(self, parameter_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze robustness of parameter choices."""
        
        robustness = {
            'alpha_robustness': 0.0,
            'threshold_robustness': 0.0,
            'overall_robustness': 0.0,
            'robustness_metrics': {}
        }
        
        # Alpha robustness (lower variance = more robust)
        alpha_sensitivity = parameter_analysis.get('alpha_sensitivity', {})
        if alpha_sensitivity:
            alpha_stds = [data['std'] for data in alpha_sensitivity.values()]
            alpha_means = [data['mean'] for data in alpha_sensitivity.values()]
            
            if alpha_means:
                # Coefficient of variation across different alpha values
                alpha_cv = np.std(alpha_means) / np.mean(alpha_means) if np.mean(alpha_means) > 0 else float('inf')
                robustness['alpha_robustness'] = 1 / (1 + alpha_cv)
        
        # Threshold robustness
        threshold_sensitivity = parameter_analysis.get('threshold_sensitivity', {})
        if threshold_sensitivity:
            threshold_stds = [data['std'] for data in threshold_sensitivity.values()]
            threshold_means = [data['mean'] for data in threshold_sensitivity.values()]
            
            if threshold_means:
                threshold_cv = np.std(threshold_means) / np.mean(threshold_means) if np.mean(threshold_means) > 0 else float('inf')
                robustness['threshold_robustness'] = 1 / (1 + threshold_cv)
        
        # Overall robustness
        robustness['overall_robustness'] = (robustness['alpha_robustness'] + 
                                          robustness['threshold_robustness']) / 2
        
        # Additional robustness metrics
        sensitivity_metrics = parameter_analysis.get('sensitivity_metrics', {})
        robustness['robustness_metrics'] = {
            'alpha_sensitivity_range': sensitivity_metrics.get('alpha_range', 0),
            'threshold_sensitivity_range': sensitivity_metrics.get('threshold_range', 0),
            'parameter_stability': robustness['overall_robustness']
        }
        
        return robustness
    
    def _generate_ablation_insights(self, 
                                  parameter_analysis: Dict[str, Any],
                                  component_analysis: Dict[str, Any],
                                  optimal_config: Dict[str, Any],
                                  strategy_name: str) -> List[str]:
        """Generate actionable insights from ablation study."""
        
        insights = []
        
        # Optimal configuration insights
        if optimal_config.get('best_config'):
            best_config = optimal_config['best_config']
            best_performance = optimal_config['best_performance']
            insights.append(f"[BEST] Best configuration: {best_config} (Performance: {best_performance:.3f})")
        
        # Parameter sensitivity insights
        sensitivity_metrics = parameter_analysis.get('sensitivity_metrics', {})
        alpha_range = sensitivity_metrics.get('alpha_range', 0)
        threshold_range = sensitivity_metrics.get('threshold_range', 0)
        
        if alpha_range > threshold_range:
            insights.append(f"📈 Alpha parameter more sensitive (range: {alpha_range:.3f}) than threshold (range: {threshold_range:.3f})")
        else:
            insights.append(f"📈 Threshold parameter more sensitive (range: {threshold_range:.3f}) than alpha (range: {alpha_range:.3f})")
        
        # Component contribution insights
        component_rankings = component_analysis.get('component_rankings', [])
        if component_rankings:
            top_component, top_contribution = component_rankings[0]
            if top_contribution > 0:
                insights.append(f"✅ {top_component} provides largest positive contribution (+{top_contribution:.3f})")
            else:
                insights.append(f"⚠️ {top_component} has largest negative impact ({top_contribution:.3f})")
        
        # EMA vs Gating contribution
        ema_contrib = component_analysis.get('ema_contribution', 0)
        gating_contrib = component_analysis.get('gating_contribution', 0)
        
        if abs(ema_contrib) > abs(gating_contrib):
            insights.append("📊 EMA component has larger impact than gating mechanism")
        elif abs(gating_contrib) > abs(ema_contrib):
            insights.append("📊 Gating mechanism has larger impact than EMA component")
        
        # Optimal parameter insights
        optimal_alpha = optimal_config.get('optimal_alpha')
        optimal_threshold = optimal_config.get('optimal_threshold')
        
        if optimal_alpha is not None:
            if optimal_alpha < 0.3:
                insights.append(f"🎯 Low alpha ({optimal_alpha}) optimal - conservative updates preferred")
            elif optimal_alpha > 0.7:
                insights.append(f"🎯 High alpha ({optimal_alpha}) optimal - aggressive updates preferred")
            else:
                insights.append(f"🎯 Moderate alpha ({optimal_alpha}) optimal - balanced updates")
        
        if optimal_threshold is not None:
            if optimal_threshold < 0.6:
                insights.append(f"🔓 Low threshold ({optimal_threshold}) optimal - frequent updates")
            elif optimal_threshold > 0.8:
                insights.append(f"🔒 High threshold ({optimal_threshold}) optimal - selective updates")
            else:
                insights.append(f"⚖️ Moderate threshold ({optimal_threshold}) optimal - balanced gating")
        
        return insights
    
    def _evaluate_ablation_results(self, 
                                 optimal_config: Dict[str, Any],
                                 robustness_analysis: Dict[str, Any],
                                 strategy_name: str) -> Tuple[bool, str]:
        """Evaluate whether ablation study results are satisfactory."""
        
        # Check if optimal configuration was found
        has_optimal = optimal_config.get('best_config') is not None
        
        # Check performance improvement
        best_performance = optimal_config.get('best_performance', 0)
        performance_acceptable = best_performance > 0.8  # ROC AUC threshold
        
        # Check robustness
        overall_robustness = robustness_analysis.get('overall_robustness', 0)
        robustness_acceptable = overall_robustness > 0.7
        
        # Overall assessment
        passed = has_optimal and performance_acceptable and robustness_acceptable
        
        # Generate summary
        summary = f"""
        {strategy_name} Ablation Study Analysis:
        
        🎯 Optimal Configuration: {optimal_config.get('best_config', 'Not found')}
        📊 Best Performance: {best_performance:.4f}
        🛡️ Parameter Robustness: {overall_robustness:.3f}
        
        Component Analysis:
        - EMA Contribution: {optimal_config.get('performance_metrics', {}).get('roc_auc_improvement', 0):+.4f}
        - Optimal Alpha: {optimal_config.get('optimal_alpha', 'N/A')}
        - Optimal Threshold: {optimal_config.get('optimal_threshold', 'N/A')}
        
        Assessment:
        - {'✅ Found' if has_optimal else '❌ No'} optimal configuration
        - {'✅ Acceptable' if performance_acceptable else '❌ Poor'} performance level
        - {'✅ Robust' if robustness_acceptable else '❌ Sensitive'} parameter choices
        """
        
        return passed, summary.strip()
    
    def _create_empty_result(self, reason: str) -> Dict[str, Any]:
        """Create empty validation result."""
        return {
            'metric_name': self.get_validator_name(),
            'values': {},
            'summary': f"Validation failed: {reason}",
            'passed': False
        }
    
    def plot_ablation_analysis(self, results: Dict[str, Any], save_path: Optional[str] = None):
        """Plot comprehensive ablation analysis."""
        
        if not results.get('values') or 'parameter_analysis' not in results['values']:
            logger.warning("No ablation analysis data to plot")
            return
        
        parameter_data = results['values']['parameter_analysis']
        landscape_data = results['values'].get('landscape_analysis', {})
        strategy_name = results['values'].get('strategy_name', 'Unknown')
        
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.suptitle(f'{strategy_name} - Ablation Study Analysis', fontsize=16, fontweight='bold')
        
        # Alpha sensitivity
        ax1 = axes[0, 0]
        alpha_sensitivity = parameter_data.get('alpha_sensitivity', {})
        if alpha_sensitivity:
            alphas = list(alpha_sensitivity.keys())
            means = [data['mean'] for data in alpha_sensitivity.values()]
            stds = [data['std'] for data in alpha_sensitivity.values()]
            
            ax1.errorbar(alphas, means, yerr=stds, marker='o', linewidth=2, markersize=6, capsize=5)
            ax1.set_xlabel('Alpha Value')
            ax1.set_ylabel('Performance (ROC AUC)')
            ax1.set_title('Alpha Parameter Sensitivity')
            ax1.grid(True, alpha=0.3)
        
        # Threshold sensitivity
        ax2 = axes[0, 1]
        threshold_sensitivity = parameter_data.get('threshold_sensitivity', {})
        if threshold_sensitivity:
            thresholds = list(threshold_sensitivity.keys())
            means = [data['mean'] for data in threshold_sensitivity.values()]
            stds = [data['std'] for data in threshold_sensitivity.values()]
            
            ax2.errorbar(thresholds, means, yerr=stds, marker='s', linewidth=2, markersize=6, capsize=5, color='red')
            ax2.set_xlabel('Threshold Value')
            ax2.set_ylabel('Performance (ROC AUC)')
            ax2.set_title('Threshold Parameter Sensitivity')
            ax2.grid(True, alpha=0.3)
        
        # Performance landscape (heatmap)
        ax3 = axes[1, 0]
        performance_surface = landscape_data.get('performance_surface', {})
        if performance_surface:
            # Create grid for heatmap
            alphas = sorted(set(alpha for alpha, _ in performance_surface.keys()))
            thresholds = sorted(set(threshold for _, threshold in performance_surface.keys()))
            
            if len(alphas) > 1 and len(thresholds) > 1:
                grid = np.zeros((len(thresholds), len(alphas)))
                
                for i, threshold in enumerate(thresholds):
                    for j, alpha in enumerate(alphas):
                        if (alpha, threshold) in performance_surface:
                            grid[i, j] = performance_surface[(alpha, threshold)]
                
                im = ax3.imshow(grid, cmap='viridis', aspect='auto', origin='lower')
                ax3.set_xticks(range(len(alphas)))
                ax3.set_xticklabels([f'{a:.1f}' for a in alphas])
                ax3.set_yticks(range(len(thresholds)))
                ax3.set_yticklabels([f'{t:.1f}' for t in thresholds])
                ax3.set_xlabel('Alpha')
                ax3.set_ylabel('Threshold')
                ax3.set_title('Performance Landscape')
                plt.colorbar(im, ax=ax3)
        
        # Component contributions
        ax4 = axes[1, 1]
        component_analysis = results['values'].get('component_analysis', {})
        if component_analysis:
            contributions = component_analysis.get('component_rankings', [])
            
            if contributions:
                components = [comp for comp, _ in contributions]
                values = [val for _, val in contributions]
                colors = ['green' if v > 0 else 'red' for v in values]
                
                bars = ax4.bar(components, values, color=colors, alpha=0.7)
                ax4.set_ylabel('Performance Contribution')
                ax4.set_title('Component Contributions')
                ax4.axhline(y=0, color='black', linestyle='-', alpha=0.3)
                ax4.grid(True, alpha=0.3)
                
                # Add value labels on bars
                for bar, value in zip(bars, values):
                    height = bar.get_height()
                    ax4.text(bar.get_x() + bar.get_width()/2., height + 0.001 if height >= 0 else height - 0.001,
                            f'{value:+.3f}', ha='center', va='bottom' if height >= 0 else 'top')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            logger.info(f"Ablation analysis plot saved to {save_path}")
        else:
            plt.show()
        
        plt.close() 