"""
Real CACD Dataset Testing - Face Embedding Extraction and EMA Validation
"""

import os
import sys
import numpy as np
import cv2
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Import validation components
from enhanced_ema_study import TemplateState, StaticTemplateStrategy, EMATemplateStrategy, GatedEMATemplateStrategy
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import normalize

class SimpleFaceProcessor:
    """Simple face processing for real images"""
    
    def __init__(self):
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        self.embedding_dim = 512
    
    def extract_face_features(self, image_path):
        """Extract meaningful features from face image"""
        try:
            # Read image
            image = cv2.imread(str(image_path))
            if image is None:
                return None
            
            # Convert to grayscale
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Detect faces
            faces = self.face_cascade.detectMultiScale(gray, 1.1, 4)
            
            if len(faces) == 0:
                # No face detected, use whole image
                face_region = gray
            else:
                # Use largest face
                largest_face = max(faces, key=lambda x: x[2] * x[3])
                x, y, w, h = largest_face
                face_region = gray[y:y+h, x:x+w]
            
            # Resize face to standard size
            face_region = cv2.resize(face_region, (64, 64))
            
            # Extract features
            features = self._extract_image_features(face_region, image)
            
            # Normalize to unit vector
            features = normalize(features.reshape(1, -1))[0]
            
            return features
            
        except Exception as e:
            print(f"Error processing {image_path}: {e}")
            return None
    
    def _extract_image_features(self, face_gray, face_color):
        """Extract comprehensive features from face"""
        features = []
        
        # 1. Pixel intensity statistics
        features.extend([
            np.mean(face_gray),
            np.std(face_gray),
            np.median(face_gray),
            np.min(face_gray),
            np.max(face_gray)
        ])
        
        # 2. Color histogram features
        if face_color is not None:
            for channel in range(3):
                hist = cv2.calcHist([face_color], [channel], None, [16], [0, 256])
                features.extend(hist.flatten())
        
        # 3. Texture features using gradients
        grad_x = cv2.Sobel(face_gray, cv2.CV_64F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(face_gray, cv2.CV_64F, 0, 1, ksize=3)
        
        features.extend([
            np.mean(np.abs(grad_x)),
            np.std(grad_x),
            np.mean(np.abs(grad_y)),
            np.std(grad_y)
        ])
        
        # 4. Edge density
        edges = cv2.Canny(face_gray, 50, 150)
        edge_density = np.sum(edges > 0) / (edges.shape[0] * edges.shape[1])
        features.append(edge_density)
        
        # 5. Local Binary Pattern-like features
        for i in range(1, face_gray.shape[0]-1, 8):
            for j in range(1, face_gray.shape[1]-1, 8):
                center = face_gray[i, j]
                pattern = 0
                for di in [-1, 0, 1]:
                    for dj in [-1, 0, 1]:
                        if di == 0 and dj == 0:
                            continue
                        if face_gray[i+di, j+dj] > center:
                            pattern += 1
                features.append(pattern)
        
        # Pad or truncate to desired size
        features = np.array(features)
        if len(features) < self.embedding_dim:
            # Pad with small random values
            padding = np.random.randn(self.embedding_dim - len(features)) * 0.01
            features = np.concatenate([features, padding])
        else:
            features = features[:self.embedding_dim]
        
        return features

def load_cacd_embeddings(cacd_path, max_people=15, max_images=25):
    """Load embeddings from CACD dataset"""
    print(f"Loading CACD data from: {cacd_path}")
    
    processor = SimpleFaceProcessor()
    embeddings = []
    labels = []
    person_names = []
    
    cacd_dir = Path(cacd_path)
    if not cacd_dir.exists():
        print(f"ERROR: CACD directory not found: {cacd_dir}")
        return None, None, None
    
    # Get person directories
    person_dirs = [d for d in cacd_dir.iterdir() if d.is_dir()]
    person_dirs = person_dirs[:max_people]
    
    print(f"Processing {len(person_dirs)} people...")
    
    for person_idx, person_dir in enumerate(person_dirs):
        print(f"  Processing {person_dir.name} ({person_idx+1}/{len(person_dirs)})")
        
        # Get image files
        image_files = []
        for ext in ['*.jpg', '*.jpeg', '*.png']:
            image_files.extend(list(person_dir.glob(ext)))
        
        image_files = image_files[:max_images]
        person_embeddings = []
        
        for img_file in image_files:
            embedding = processor.extract_face_features(img_file)
            if embedding is not None:
                person_embeddings.append(embedding)
        
        if len(person_embeddings) >= 3:  # Need at least 3 images
            embeddings.extend(person_embeddings)
            labels.extend([person_idx] * len(person_embeddings))
            person_names.append(person_dir.name)
            print(f"    Added {len(person_embeddings)} embeddings")
    
    print(f"Total: {len(embeddings)} embeddings from {len(person_names)} people")
    return np.array(embeddings), np.array(labels), person_names

def create_verification_pairs(embeddings, labels, num_pairs=500):
    """Create genuine and impostor verification pairs"""
    pairs = []
    
    # Genuine pairs (same person)
    for label in np.unique(labels):
        indices = np.where(labels == label)[0]
        if len(indices) >= 2:
            for i in range(min(5, len(indices))):
                for j in range(i+1, min(i+6, len(indices))):
                    pairs.append((indices[i], indices[j], 1))
    
    # Impostor pairs (different people)
    impostor_count = 0
    unique_labels = np.unique(labels)
    while impostor_count < len(pairs):  # Match number of genuine pairs
        label1, label2 = np.random.choice(unique_labels, 2, replace=False)
        idx1 = np.random.choice(np.where(labels == label1)[0])
        idx2 = np.random.choice(np.where(labels == label2)[0])
        pairs.append((idx1, idx2, 0))
        impostor_count += 1
    
    return pairs

def test_strategy(strategy, embeddings, labels, pairs, strategy_name):
    """Test a specific template strategy"""
    print(f"\nTesting {strategy_name}...")
    
    # Initialize templates
    templates = {}
    for label in np.unique(labels):
        indices = np.where(labels == label)[0]
        initial_embedding = embeddings[indices[0]]
        templates[label] = TemplateState(
            embedding=initial_embedding,
            confidence=0.8,
            age=0
        )
    
    # Simulate template updates
    update_stats = {'decisions': 0, 'accepted': 0}
    
    for label in np.unique(labels):
        indices = np.where(labels == label)[0]
        template = templates[label]
        
        # Process remaining embeddings for updates
        for age_idx, idx in enumerate(indices[1:], 1):
            new_embedding = embeddings[idx]
            new_confidence = 0.8
            
            # Get updated template from strategy
            updated_template = strategy.update_template(
                template, new_embedding, new_confidence, age_idx
            )
            
            update_stats['decisions'] += 1
            
            # Check if template was actually updated (compare embeddings)
            if not np.allclose(template.embedding, updated_template.embedding):
                update_stats['accepted'] += 1
            
            templates[label] = updated_template
            template = updated_template
    
    # Perform verification
    scores = []
    true_labels = []
    
    for idx1, idx2, label in pairs:
        label1, label2 = labels[idx1], labels[idx2]
        
        # Use current template embeddings
        emb1 = templates[label1].embedding
        emb2 = templates[label2].embedding
        
        # Cosine similarity
        score = np.dot(emb1, emb2)
        scores.append(score)
        true_labels.append(label)
    
    # Calculate performance
    auc = roc_auc_score(true_labels, scores)
    update_rate = update_stats['accepted'] / max(1, update_stats['decisions'])
    
    print(f"  ROC AUC: {auc:.4f}")
    print(f"  Updates: {update_stats['accepted']}/{update_stats['decisions']} ({update_rate:.1%})")
    
    return {
        'auc': auc,
        'updates': update_stats['accepted'],
        'decisions': update_stats['decisions'],
        'update_rate': update_rate,
        'scores': scores
    }

def main():
    """Main testing function"""
    print("="*60)
    print("REAL CACD DATASET - EMA VALIDATION TEST")
    print("="*60)
    
    # Load real CACD data
    cacd_path = "../data/cacd_split/cacd_split"
    embeddings, labels, person_names = load_cacd_embeddings(cacd_path)
    
    if embeddings is None:
        print("Failed to load CACD data!")
        return
    
    print(f"\nDataset loaded:")
    print(f"  - {len(embeddings)} total face embeddings")
    print(f"  - {len(person_names)} people: {person_names[:5]}...")
    print(f"  - Embedding dimension: {embeddings.shape[1]}")
    
    # Create verification pairs
    pairs = create_verification_pairs(embeddings, labels)
    print(f"  - {len(pairs)} verification pairs created")
    
    # Test strategies
    strategies = {
        'Static': StaticTemplateStrategy(),
        'EMA (α=0.3)': EMATemplateStrategy(alpha=0.3),
        'Gated EMA': GatedEMATemplateStrategy(alpha=0.3, confidence_threshold=0.7)
    }
    
    results = {}
    for name, strategy in strategies.items():
        results[name] = test_strategy(strategy, embeddings, labels, pairs, name)
    
    # Final report
    print("\n" + "="*60)
    print("FINAL RESULTS SUMMARY")
    print("="*60)
    
    sorted_results = sorted(results.items(), key=lambda x: x[1]['auc'], reverse=True)
    
    for rank, (name, result) in enumerate(sorted_results, 1):
        status = "[BEST]" if rank == 1 else f"[#{rank}]"
        print(f"{status} {name}:")
        print(f"    ROC AUC: {result['auc']:.4f}")
        print(f"    Update Rate: {result['update_rate']:.1%}")
    
    # Key comparison
    if 'Gated EMA' in results and 'Static' in results:
        gated_auc = results['Gated EMA']['auc']
        static_auc = results['Static']['auc']
        improvement = gated_auc - static_auc
        
        print(f"\n[KEY FINDING] Gated EMA vs Static Templates:")
        print(f"  Improvement: {improvement:.4f} ({improvement/static_auc*100:.1f}%)")
        
        if improvement > 0:
            print(f"  [CONCLUSION] Gated EMA ENHANCES face verification accuracy!")
        else:
            print(f"  [CONCLUSION] Gated EMA does not improve accuracy on this dataset")
    
    # Save results
    with open("cacd_real_results.txt", "w") as f:
        f.write("REAL CACD DATASET VALIDATION RESULTS\n")
        f.write("="*40 + "\n\n")
        f.write(f"Dataset: {len(embeddings)} embeddings from {len(person_names)} people\n")
        f.write(f"People: {person_names}\n\n")
        
        for name, result in sorted_results:
            f.write(f"{name}:\n")
            f.write(f"  ROC AUC: {result['auc']:.4f}\n")
            f.write(f"  Update Rate: {result['update_rate']:.1%}\n\n")
    
    print(f"\nDetailed results saved to: cacd_real_results.txt")

if __name__ == "__main__":
    main() 