# Face Recognition Data Drift Detection System

A comprehensive system for detecting data drift in face recognition models using FaceNet-512 embeddings and the CFP (Celebrities in Frontal-Profile) dataset.

## Overview

This system implements multiple drift detection methods to identify when face embeddings distributions have shifted, which could indicate:
- Changes in data collection conditions
- Different camera equipment or lighting
- Population shift in the dataset
- Model degradation over time

## Features

### Implemented Drift Detection Methods

1. **Euclidean Distance**: Measures distance between embedding centroids
2. **Cosine Distance**: Measures angular distance between normalized centroids  
3. **Kolmogorov-Smirnov (KS) Test**: Statistical test for distribution differences
4. **Maximum Mean Discrepancy (MMD)**: Kernel-based distribution comparison
5. **Domain Classifier**: ML classifier distinguishing between datasets

### Combined Decision Logic

The system implements your suggested approach:
```
DRIFT = (Euclidean > threshold) AND (KS_detected OR Classifier_detected)
```

This reduces false positives by requiring both distance-based and statistical evidence.

## Installation

1. **Install Python Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Download CFP Dataset**:
   - Download the CFP dataset and extract it to `cfp-dataset/` folder
   - Ensure the structure matches:
     ```
     cfp-dataset/
     ├── Data/
     │   ├── Images/
     │   │   ├── 001/
     │   │   │   ├── frontal/
     │   │   │   └── profile/
     │   │   └── ...
     │   └── list_name.txt
     └── ...
     ```

3. **First Run Setup**:
   - The first run will download DeepFace models (~100MB)
   - Ensure good internet connection for initial setup

## Usage

### Quick Start

Run the main drift detection system:
```bash
python drift_detector.py
```

This will:
- Load CFP dataset images
- Extract FaceNet-512 embeddings  
- Perform temporal split simulation
- Run all drift detection methods
- Generate visualizations and reports

### Advanced Experiments

Run comprehensive experiments:
```bash
python demo_experiment.py
```

This includes:
- Basic drift detection
- Frontal vs Profile comparison (expected drift)
- Parameter sensitivity analysis
- Artificial drift simulation

### Custom Configuration

You can modify drift detection thresholds in the code:

```python
drift_config = {
    'euclidean_threshold': 1.5,     # Distance threshold
    'cosine_threshold': 0.05,       # Cosine distance threshold
    'ks_alpha': 0.01,              # KS test significance level
    'mmd_threshold': 0.05,          # MMD threshold
    'classifier_auc_threshold': 0.7  # Domain classifier AUC threshold
}
```

## Understanding Results

### Output Files

The system generates several output files:

1. **`drift_analysis_summary.json`**: Complete results in JSON format
2. **`embedding_distributions.png`**: Distribution plots for first 6 dimensions
3. **`drift_results.png`**: Bar chart of detection results vs thresholds
4. **`pca_analysis.png`**: 2D PCA visualization of embeddings
5. **`reference_embeddings.npy`** & **`target_embeddings.npy`**: Raw embeddings

### Interpreting Results

#### Example Output:
```
DRIFT DETECTION RESULTS:
==================================================

Euclidean Distance:
  Drift Detected: YES
  Score: 2.1543
  Threshold: 1.5000

Kolmogorov-Smirnov:
  Drift Detected: YES
  Score: 0.0001
  Threshold: 0.0098
  P-value: 0.000123

Domain Classifier:
  Drift Detected: YES
  Score: 0.8234
  Threshold: 0.7000

COMBINED DECISION:
   Logic: (Euclidean > threshold) AND (KS detected OR Classifier detected)
   Final Result: DRIFT DETECTED
```

#### What This Means:
- **Euclidean Distance > threshold**: Centroids are far apart
- **KS Test significant**: Statistical evidence of distribution difference
- **Domain Classifier AUC > 0.7**: Model can distinguish between datasets
- **Combined Decision**: Multiple evidence sources agree on drift

## Key Classes and Methods

### `FaceEmbeddingExtractor`
- Extracts FaceNet-512 embeddings using DeepFace
- Handles batch processing with progress tracking
- Robust error handling for failed extractions

### `CFPDatasetLoader`
- Loads and organizes CFP dataset
- Creates temporal splits for drift simulation
- Filters by image type (frontal/profile/both)

### `DataDriftDetector`
- Implements all drift detection methods
- Configurable thresholds and parameters
- Returns structured results with confidence metrics

### `DriftAnalysisVisualizer`
- Generates embedding distribution plots
- Creates drift detection result visualizations
- PCA analysis for high-dimensional data

## Experimental Scenarios

### 1. Temporal Drift Simulation
Splits dataset chronologically to simulate:
- Model trained on older data
- Deployment on newer data with potential shifts

### 2. Frontal vs Profile Comparison
Compares frontal and profile images to validate:
- System sensitivity to known differences
- Expected high drift detection rates

### 3. Parameter Sensitivity Analysis
Tests different threshold configurations:
- **Conservative**: High thresholds, fewer false positives
- **Moderate**: Balanced sensitivity
- **Sensitive**: Low thresholds, detects subtle changes

### 4. Artificial Drift
Adds controlled noise to simulate gradual drift:
- Tests system response to various drift magnitudes
- Validates threshold calibration

## Best Practices

### Threshold Selection
- **Conservative**: Use for production systems where false alarms are costly
- **Sensitive**: Use for research or when early detection is critical
- **Adaptive**: Adjust based on historical data and domain knowledge

### Deployment Recommendations

1. **Baseline Establishment**: Run on historical data to establish normal ranges
2. **Regular Monitoring**: Schedule periodic drift checks (daily/weekly)
3. **Alert Thresholds**: Set up automated alerts when drift is detected
4. **Human Review**: Always have domain experts review detected drift
5. **Model Retraining**: Prepare pipelines for model updates when drift confirmed

### Performance Optimization

- **Embedding Caching**: Save embeddings to avoid recomputation
- **Batch Processing**: Process images in batches for efficiency  
- **Dimensionality Reduction**: Use PCA for very large embedding dimensions
- **Sampling**: Use representative samples for large datasets

## Technical Details

### FaceNet-512 Embeddings
- 512-dimensional face embeddings
- Pre-trained on large face datasets
- Robust to lighting and pose variations
- Normalized to unit sphere

### Statistical Methods
- **KS Test**: Non-parametric, distribution-free
- **MMD**: Kernel-based, captures complex differences
- **Domain Classifier**: Model-based, learns discriminative features

### Computational Complexity
- **Embedding Extraction**: O(n) with deep learning inference
- **Distance Metrics**: O(d) where d is embedding dimension
- **KS Test**: O(n₁ × n₂ × d) for all dimensions
- **Domain Classifier**: O(n × d) for training

## Troubleshooting

### Common Issues

1. **DeepFace Import Error**:
   ```bash
   pip install deepface tensorflow
   ```

2. **No Images Found**:
   - Check dataset path is correct
   - Verify CFP dataset structure

3. **Embedding Extraction Fails**:
   - Check image file integrity
   - Ensure sufficient RAM for model loading
   - Verify TensorFlow installation

4. **Memory Issues**:
   - Reduce batch size in configuration
   - Process smaller subsets of data
   - Use dimensionality reduction

### Performance Tips

- **GPU Acceleration**: Install TensorFlow-GPU for faster embedding extraction
- **Parallel Processing**: Modify code to use multiprocessing for CPU-bound operations  
- **Memory Management**: Use generators for large datasets

## Contributing

Feel free to extend the system with:
- Additional drift detection methods
- New visualization techniques
- Different embedding models
- Real-time monitoring capabilities

## References

- CFP Dataset: [Celebrities in Frontal-Profile](http://www.cfpw.io/)
- DeepFace Library: [DeepFace](https://github.com/serengil/deepface)
- FaceNet Paper: [FaceNet: A Unified Embedding for Face Recognition](https://arxiv.org/abs/1503.03832)

## License

This project is provided for research and educational purposes. Please cite appropriately if used in academic work. 