#!/usr/bin/env python3
"""
Adaptive Face Recognition System
================================

This system implements Apple Face ID-like adaptive face recognition that automatically
adapts to incremental changes in user appearance using FaceNet-512 embeddings.

Features:
- Adaptive template updates with confidence-based learning
- Multi-template banking for robust representation
- Passcode fallback for close matches
- Incremental learning without catastrophic forgetting
- Integration with CFP dataset for testing

Author: AI Assistant
"""

import os
import time
import numpy as np
import json
import matplotlib.pyplot as plt
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime
import pickle

# Import from existing codebase
from drift_detector import FaceEmbeddingExtractor, CFPDatasetLoader

@dataclass
class AuthenticationResult:
    """Container for authentication results"""
    success: bool
    method: str  # 'biometric', 'passcode_fallback', 'failed'
    similarity: float
    confidence: float
    template_updated: bool
    reason: Optional[str] = None
    timestamp: Optional[str] = None

class AdaptiveFaceTemplate:
    """Adaptive template that learns from user interactions"""
    
    def __init__(self, initial_embedding: np.ndarray, user_id: str, 
                 confidence_threshold: float = 0.4, adaptation_rate: float = 0.1):
        self.user_id = user_id
        self.template = initial_embedding.copy()
        self.template = self.template / np.linalg.norm(self.template)  # Normalize
        self.confidence_threshold = confidence_threshold
        self.adaptation_rate = adaptation_rate
        self.creation_time = time.time()
        self.last_update = time.time()
        self.update_count = 0
        self.update_history = []
        
    def compute_similarity(self, new_embedding: np.ndarray) -> float:
        """Compute cosine similarity between template and new embedding"""
        new_embedding_norm = new_embedding / np.linalg.norm(new_embedding)
        return float(np.dot(self.template, new_embedding_norm))
    
    def is_close_match(self, new_embedding: np.ndarray) -> bool:
        """Determine if embedding is close enough for potential adaptation"""
        similarity = self.compute_similarity(new_embedding)
        return similarity > self.confidence_threshold
    
    def update_template(self, new_embedding: np.ndarray, confidence: float, 
                       update_type: str = "biometric"):
        """Update template using exponential moving average"""
        if confidence > 0.3:  # Minimum confidence for updates
            # Normalize new embedding
            new_embedding_norm = new_embedding / np.linalg.norm(new_embedding)
            
            # Confidence-weighted adaptation rate
            effective_rate = self.adaptation_rate * confidence
            
            # Exponential moving average update
            self.template = (1 - effective_rate) * self.template + effective_rate * new_embedding_norm
            self.template = self.template / np.linalg.norm(self.template)
            
            # Update metadata
            self.last_update = time.time()
            self.update_count += 1
            self.update_history.append({
                'timestamp': datetime.now().isoformat(),
                'confidence': confidence,
                'adaptation_rate': effective_rate,
                'similarity_before': self.compute_similarity(new_embedding),
                'update_type': update_type
            })
            
            # Keep only recent history
            if len(self.update_history) > 100:
                self.update_history = self.update_history[-100:]
            
            return True
        return False
    
    def get_adaptation_stats(self) -> Dict:
        """Get statistics about template adaptation"""
        if not self.update_history:
            return {"total_updates": 0, "avg_confidence": 0.0}
        
        confidences = [h['confidence'] for h in self.update_history]
        return {
            "total_updates": self.update_count,
            "avg_confidence": np.mean(confidences),
            "recent_updates": len([h for h in self.update_history[-10:] 
                                 if time.time() - time.mktime(
                                     time.strptime(h['timestamp'][:19], '%Y-%m-%dT%H:%M:%S')
                                 ) < 86400]),  # Last 24 hours
            "creation_time": datetime.fromtimestamp(self.creation_time).isoformat(),
            "last_update": datetime.fromtimestamp(self.last_update).isoformat()
        }

class MultiTemplateBank:
    """Manages multiple templates per user for robust representation"""
    
    def __init__(self, max_templates: int = 5):
        self.templates = []  # List of (template, weight, creation_time)
        self.max_templates = max_templates
        
    def add_template(self, embedding: np.ndarray, weight: float = 1.0):
        """Add new template with aging mechanism"""
        current_time = time.time()
        normalized_embedding = embedding / np.linalg.norm(embedding)
        self.templates.append((normalized_embedding, weight, current_time))
        
        # Remove oldest if exceeding limit
        if len(self.templates) > self.max_templates:
            self.templates = sorted(self.templates, key=lambda x: x[2])[-self.max_templates:]
    
    def get_consensus_embedding(self) -> Optional[np.ndarray]:
        """Compute weighted average of all templates with time decay"""
        if not self.templates:
            return None
        
        current_time = time.time()
        weighted_sum = np.zeros_like(self.templates[0][0])
        total_weight = 0.0
        
        for template, base_weight, creation_time in self.templates:
            # Apply time decay (newer templates have higher weight)
            age_hours = (current_time - creation_time) / 3600
            time_weight = np.exp(-age_hours / 168)  # Decay over 1 week
            
            effective_weight = base_weight * time_weight
            weighted_sum += effective_weight * template
            total_weight += effective_weight
        
        if total_weight > 0:
            consensus = weighted_sum / total_weight
            return consensus / np.linalg.norm(consensus)
        return None
    
    def get_best_match_similarity(self, embedding: np.ndarray) -> float:
        """Get similarity with best matching template"""
        if not self.templates:
            return 0.0
        
        embedding_norm = embedding / np.linalg.norm(embedding)
        similarities = []
        
        for template, _, _ in self.templates:
            similarity = np.dot(template, embedding_norm)
            similarities.append(similarity)
        
        return max(similarities)

class AdaptiveFaceRecognition:
    """Main adaptive face recognition system"""
    
    def __init__(self, config: Dict = None):
        self.embedding_extractor = FaceEmbeddingExtractor()
        self.users = {}  # user_id -> AdaptiveFaceTemplate
        self.user_banks = {}  # user_id -> MultiTemplateBank
        self.passcodes = {}  # user_id -> passcode_hash (for demo)
        
        # Default configuration
        self.config = {
            'auth_threshold': 0.6,           # Direct authentication threshold
            'close_match_threshold': 0.4,    # Close match for passcode fallback
            'adaptation_rate': 0.15,         # Template update rate
            'confidence_boost_passcode': 1.3, # Boost confidence for passcode auth
            'max_templates_per_user': 5,     # Multi-template banking
            'min_confidence_update': 0.3,    # Minimum confidence for updates
            'enable_multi_template': True     # Use multi-template banking
        }
        
        if config:
            self.config.update(config)
        
        # Statistics tracking
        self.auth_stats = {
            'total_attempts': 0,
            'successful_biometric': 0,
            'successful_passcode': 0,
            'failed_attempts': 0,
            'template_updates': 0
        }
    
    def enroll_user(self, user_id: str, enrollment_images: List, 
                   passcode: str = "1234") -> Dict:
        """Enroll new user with multiple images"""
        print(f"Enrolling user: {user_id}")
        
        embeddings = []
        for i, image_path in enumerate(enrollment_images):
            embedding = self.embedding_extractor.extract_embedding(image_path)
            if embedding is not None:
                embeddings.append(embedding)
                print(f"  Processed enrollment image {i+1}/{len(enrollment_images)}")
            else:
                print(f"  Failed to process image {i+1}: {image_path}")
        
        if len(embeddings) == 0:
            return {"success": False, "reason": "no_valid_embeddings"}
        
        # Create initial template as average of enrollment embeddings
        initial_template = np.mean(embeddings, axis=0)
        initial_template = initial_template / np.linalg.norm(initial_template)
        
        # Create adaptive template
        self.users[user_id] = AdaptiveFaceTemplate(
            initial_template, 
            user_id,
            self.config['close_match_threshold'],
            self.config['adaptation_rate']
        )
        
        # Create multi-template bank if enabled
        if self.config['enable_multi_template']:
            self.user_banks[user_id] = MultiTemplateBank(self.config['max_templates_per_user'])
            for embedding in embeddings:
                self.user_banks[user_id].add_template(embedding)
        
        # Store passcode (in practice, use proper hashing)
        self.passcodes[user_id] = passcode
        
        return {
            "success": True, 
            "enrollment_samples": len(embeddings),
            "initial_template_norm": float(np.linalg.norm(initial_template))
        }
    
    def authenticate(self, user_id: str, image_path: str, 
                    passcode: Optional[str] = None) -> AuthenticationResult:
        """Main authentication method with adaptive learning"""
        self.auth_stats['total_attempts'] += 1
        
        if user_id not in self.users:
            return AuthenticationResult(
                success=False,
                method="failed",
                similarity=0.0,
                confidence=0.0,
                template_updated=False,
                reason="user_not_enrolled",
                timestamp=datetime.now().isoformat()
            )
        
        # Extract embedding from new image
        embedding = self.embedding_extractor.extract_embedding(image_path)
        if embedding is None:
            return AuthenticationResult(
                success=False,
                method="failed",
                similarity=0.0,
                confidence=0.0,
                template_updated=False,
                reason="no_face_detected",
                timestamp=datetime.now().isoformat()
            )
        
        user_template = self.users[user_id]
        
        # Compute similarity with primary template
        primary_similarity = user_template.compute_similarity(embedding)
        
        # Compute similarity with multi-template bank if available
        bank_similarity = 0.0
        if user_id in self.user_banks:
            bank_similarity = self.user_banks[user_id].get_best_match_similarity(embedding)
        
        # Use the higher similarity
        max_similarity = max(primary_similarity, bank_similarity)
        confidence = self._compute_confidence(max_similarity, embedding)
        
        # Direct biometric authentication
        if max_similarity > self.config['auth_threshold']:
            updated = user_template.update_template(embedding, confidence, "biometric")
            
            # Update multi-template bank
            if self.config['enable_multi_template'] and user_id in self.user_banks:
                if confidence > 0.7:  # High confidence updates
                    self.user_banks[user_id].add_template(embedding, confidence)
            
            if updated:
                self.auth_stats['template_updates'] += 1
            
            self.auth_stats['successful_biometric'] += 1
            
            return AuthenticationResult(
                success=True,
                method="biometric",
                similarity=max_similarity,
                confidence=confidence,
                template_updated=updated,
                timestamp=datetime.now().isoformat()
            )
        
        # Close match with passcode fallback
        elif (max_similarity > self.config['close_match_threshold'] and 
              passcode and self._verify_passcode(user_id, passcode)):
            
            # Boost confidence for passcode-verified adaptation
            boosted_confidence = min(confidence * self.config['confidence_boost_passcode'], 1.0)
            updated = user_template.update_template(embedding, boosted_confidence, "passcode_fallback")
            
            # Update multi-template bank with high confidence
            if self.config['enable_multi_template'] and user_id in self.user_banks:
                self.user_banks[user_id].add_template(embedding, boosted_confidence)
            
            if updated:
                self.auth_stats['template_updates'] += 1
            
            self.auth_stats['successful_passcode'] += 1
            
            return AuthenticationResult(
                success=True,
                method="passcode_fallback",
                similarity=max_similarity,
                confidence=boosted_confidence,
                template_updated=updated,
                timestamp=datetime.now().isoformat()
            )
        
        # Authentication failed
        self.auth_stats['failed_attempts'] += 1
        
        return AuthenticationResult(
            success=False,
            method="failed",
            similarity=max_similarity,
            confidence=confidence,
            template_updated=False,
            reason="similarity_too_low" if max_similarity <= self.config['close_match_threshold'] else "passcode_required",
            timestamp=datetime.now().isoformat()
        )
    
    def _compute_confidence(self, similarity: float, embedding: np.ndarray) -> float:
        """Compute confidence based on similarity and embedding quality"""
        # Base confidence from similarity
        conf = similarity
        
        # Adjust based on embedding magnitude (quality indicator)
        embedding_norm = np.linalg.norm(embedding)
        if embedding_norm > 0:
            quality_factor = min(embedding_norm / 20.0, 1.0)  # Normalize to expected range
            conf *= quality_factor
        
        return float(np.clip(conf, 0.0, 1.0))
    
    def _verify_passcode(self, user_id: str, passcode: str) -> bool:
        """Verify user passcode (simplified for demo)"""
        return user_id in self.passcodes and self.passcodes[user_id] == passcode
    
    def get_user_stats(self, user_id: str) -> Dict:
        """Get adaptation statistics for a user"""
        if user_id not in self.users:
            return {"error": "user_not_found"}
        
        template_stats = self.users[user_id].get_adaptation_stats()
        
        bank_stats = {}
        if user_id in self.user_banks:
            bank = self.user_banks[user_id]
            bank_stats = {
                "template_count": len(bank.templates),
                "consensus_available": bank.get_consensus_embedding() is not None
            }
        
        return {
            "user_id": user_id,
            "template_stats": template_stats,
            "bank_stats": bank_stats,
            "system_stats": self.auth_stats.copy()
        }
    
    def save_system_state(self, filepath: str):
        """Save system state for persistence"""
        state = {
            'config': self.config,
            'auth_stats': self.auth_stats,
            'users': {},
            'user_banks': {},
            'passcodes': self.passcodes
        }
        
        # Save user templates
        for user_id, template in self.users.items():
            state['users'][user_id] = {
                'template': template.template.tolist(),
                'user_id': template.user_id,
                'confidence_threshold': template.confidence_threshold,
                'adaptation_rate': template.adaptation_rate,
                'creation_time': template.creation_time,
                'last_update': template.last_update,
                'update_count': template.update_count,
                'update_history': template.update_history
            }
        
        # Save multi-template banks
        for user_id, bank in self.user_banks.items():
            state['user_banks'][user_id] = {
                'templates': [(t.tolist(), w, ct) for t, w, ct in bank.templates],
                'max_templates': bank.max_templates
            }
        
        with open(filepath, 'w') as f:
            json.dump(state, f, indent=2)
        
        print(f"System state saved to {filepath}")
    
    def load_system_state(self, filepath: str):
        """Load system state from file"""
        with open(filepath, 'r') as f:
            state = json.load(f)
        
        self.config = state['config']
        self.auth_stats = state['auth_stats']
        self.passcodes = state['passcodes']
        
        # Load user templates
        self.users = {}
        for user_id, template_data in state['users'].items():
            template = AdaptiveFaceTemplate(
                np.array(template_data['template']),
                template_data['user_id'],
                template_data['confidence_threshold'],
                template_data['adaptation_rate']
            )
            template.creation_time = template_data['creation_time']
            template.last_update = template_data['last_update']
            template.update_count = template_data['update_count']
            template.update_history = template_data['update_history']
            self.users[user_id] = template
        
        # Load multi-template banks
        self.user_banks = {}
        for user_id, bank_data in state['user_banks'].items():
            bank = MultiTemplateBank(bank_data['max_templates'])
            bank.templates = [(np.array(t), w, ct) for t, w, ct in bank_data['templates']]
            self.user_banks[user_id] = bank
        
        print(f"System state loaded from {filepath}")

def visualize_adaptation_progress(user_stats: Dict, save_path: str = None):
    """Visualize user adaptation progress over time"""
    if 'template_stats' not in user_stats or not user_stats['template_stats']['total_updates']:
        print("No adaptation history to visualize")
        return
    
    template_stats = user_stats['template_stats']
    user_id = user_stats['user_id']
    
    # Extract update history
    history = user_stats['template_stats'].get('update_history', [])
    if not history:
        print("No detailed update history available")
        return
    
    # Parse timestamps and confidences
    timestamps = []
    confidences = []
    adaptation_rates = []
    
    for update in history:
        try:
            timestamp = datetime.fromisoformat(update['timestamp'])
            timestamps.append(timestamp)
            confidences.append(update['confidence'])
            adaptation_rates.append(update['adaptation_rate'])
        except:
            continue
    
    if not timestamps:
        print("No valid timestamps in history")
        return
    
    # Create visualization
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
    
    # Plot confidence over time
    ax1.plot(timestamps, confidences, 'b-', marker='o', markersize=4, alpha=0.7)
    ax1.set_title(f'Adaptation Confidence Over Time - User: {user_id}')
    ax1.set_ylabel('Confidence Score')
    ax1.grid(True, alpha=0.3)
    ax1.set_ylim(0, 1)
    
    # Plot adaptation rates over time
    ax2.plot(timestamps, adaptation_rates, 'r-', marker='s', markersize=4, alpha=0.7)
    ax2.set_title('Adaptation Rate Over Time')
    ax2.set_ylabel('Adaptation Rate')
    ax2.set_xlabel('Time')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Adaptation visualization saved to {save_path}")
    
    plt.show()

def main():
    """Demo of adaptive face recognition system"""
    print("=" * 60)
    print("ADAPTIVE FACE RECOGNITION SYSTEM DEMO")
    print("=" * 60)
    
    # Initialize system
    adaptive_system = AdaptiveFaceRecognition()
    dataset_loader = CFPDatasetLoader("cfp-dataset")
    
    # Demo configuration
    demo_config = {
        'user_id': 'demo_user_001',
        'max_celebrities': 10,
        'enrollment_count': 5,
        'test_count': 10
    }
    
    print(f"\n1. Loading images for demo user...")
    
    # Get images for demo user (using first celebrity)
    frontal_images = dataset_loader.get_image_paths(
        image_type="frontal", 
        max_celebrities=demo_config['max_celebrities']
    )
    
    if len(frontal_images) < demo_config['enrollment_count'] + demo_config['test_count']:
        print(f"Not enough images found. Need at least {demo_config['enrollment_count'] + demo_config['test_count']}")
        return
    
    # Split images for enrollment and testing
    enrollment_images = frontal_images[:demo_config['enrollment_count']]
    test_images = frontal_images[demo_config['enrollment_count']:demo_config['enrollment_count'] + demo_config['test_count']]
    
    print(f"Enrollment images: {len(enrollment_images)}")
    print(f"Test images: {len(test_images)}")
    
    # Enroll user
    print(f"\n2. Enrolling user '{demo_config['user_id']}'...")
    enrollment_result = adaptive_system.enroll_user(
        demo_config['user_id'], 
        enrollment_images
    )
    
    if not enrollment_result['success']:
        print(f"Enrollment failed: {enrollment_result}")
        return
    
    print(f"Enrollment successful: {enrollment_result}")
    
    # Test adaptive authentication
    print(f"\n3. Testing adaptive authentication...")
    
    results = []
    for i, test_image in enumerate(test_images):
        print(f"\nAuthentication attempt {i+1}/{len(test_images)}")
        
        # Simulate different scenarios
        if i < 3:
            # Direct biometric authentication
            result = adaptive_system.authenticate(demo_config['user_id'], test_image)
        elif i < 6:
            # Simulate close match with passcode
            result = adaptive_system.authenticate(demo_config['user_id'], test_image, passcode="1234")
        else:
            # Test without passcode
            result = adaptive_system.authenticate(demo_config['user_id'], test_image)
        
        print(f"  Result: {result.method} (similarity: {result.similarity:.3f}, updated: {result.template_updated})")
        results.append(asdict(result))
    
    # Display adaptation statistics
    print(f"\n4. Adaptation Statistics:")
    user_stats = adaptive_system.get_user_stats(demo_config['user_id'])
    print(f"  Total template updates: {user_stats['template_stats']['total_updates']}")
    print(f"  Average confidence: {user_stats['template_stats']['avg_confidence']:.3f}")
    print(f"  System stats: {user_stats['system_stats']}")
    
    # Save results
    output_dir = "adaptive_face_results"
    os.makedirs(output_dir, exist_ok=True)
    
    # Save system state
    adaptive_system.save_system_state(os.path.join(output_dir, "system_state.json"))
    
    # Save results
    with open(os.path.join(output_dir, "authentication_results.json"), 'w') as f:
        json.dump({
            'demo_config': demo_config,
            'enrollment_result': enrollment_result,
            'authentication_results': results,
            'user_stats': user_stats
        }, f, indent=2)
    
    # Visualize adaptation progress
    try:
        visualize_adaptation_progress(
            user_stats, 
            os.path.join(output_dir, "adaptation_progress.png")
        )
    except Exception as e:
        print(f"Visualization failed: {e}")
    
    print(f"\n5. Demo completed! Results saved to '{output_dir}' directory.")
    
    return adaptive_system, results

if __name__ == "__main__":
    system, results = main() 