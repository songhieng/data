#!/usr/bin/env python3
"""
Adaptive Face Recognition Demo
=============================

This script demonstrates the adaptive face recognition system with various scenarios:
1. Initial enrollment with multiple images
2. Successful biometric authentication with template adaptation
3. Close match scenarios requiring passcode fallback
4. Template evolution visualization
5. Multi-user scenarios

Run this script to see how the system adapts over time.
"""

import os
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from adaptive_face_recognition import AdaptiveFaceRecognition, visualize_adaptation_progress
from drift_detector import CFPDatasetLoader
import json
from datetime import datetime
import time

def run_comprehensive_demo():
    """Run comprehensive adaptive face recognition demo"""
    print("🚀 Starting Comprehensive Adaptive Face Recognition Demo")
    print("=" * 70)
    
    # Initialize system with custom configuration
    config = {
        'auth_threshold': 0.65,           # Slightly higher for security
        'close_match_threshold': 0.45,   # Allow passcode fallback
        'adaptation_rate': 0.12,         # Moderate adaptation speed
        'confidence_boost_passcode': 1.2, # Boost for passcode auth
        'max_templates_per_user': 4,     # Multi-template banking
        'enable_multi_template': True
    }
    
    adaptive_system = AdaptiveFaceRecognition(config=config)
    dataset_loader = CFPDatasetLoader("cfp-dataset")
    
    # Demo scenarios
    scenarios = [
        {
            'name': 'John Doe - Regular User',
            'user_id': 'john_doe_001',
            'celebrity_start': 0,
            'enrollment_count': 6,
            'test_count': 15,
            'passcode': '1234'
        },
        {
            'name': 'Jane Smith - Power User',
            'user_id': 'jane_smith_002', 
            'celebrity_start': 10,
            'enrollment_count': 4,
            'test_count': 12,
            'passcode': '9876'
        }
    ]
    
    all_results = {}
    
    for scenario in scenarios:
        print(f"\n{'='*50}")
        print(f"🎭 SCENARIO: {scenario['name']}")
        print(f"{'='*50}")
        
        # Get images for this user
        frontal_images = dataset_loader.get_image_paths(
            image_type="frontal", 
            max_celebrities=50
        )
        
        # Filter images for this specific user (simulate different people)
        start_idx = scenario['celebrity_start'] * 14  # Each celebrity has ~14 images
        user_images = frontal_images[start_idx:start_idx + scenario['enrollment_count'] + scenario['test_count']]
        
        if len(user_images) < scenario['enrollment_count'] + scenario['test_count']:
            print(f"❌ Not enough images for {scenario['name']}, skipping...")
            continue
        
        enrollment_images = user_images[:scenario['enrollment_count']]
        test_images = user_images[scenario['enrollment_count']:scenario['enrollment_count'] + scenario['test_count']]
        
        print(f"📝 Enrolling {scenario['name']} with {len(enrollment_images)} images...")
        
        # Enroll user
        enrollment_result = adaptive_system.enroll_user(
            scenario['user_id'], 
            enrollment_images,
            scenario['passcode']
        )
        
        if not enrollment_result['success']:
            print(f"❌ Enrollment failed: {enrollment_result}")
            continue
        
        print(f"✅ Enrollment successful: {enrollment_result['enrollment_samples']} valid embeddings")
        
        # Test authentication with different scenarios
        auth_results = []
        
        print(f"\n🔐 Testing authentication scenarios...")
        
        for i, test_image in enumerate(test_images):
            print(f"\n  Test {i+1}/{len(test_images)}: ", end="")
            
            # Simulate different authentication patterns
            if i % 5 == 0 and i > 0:
                # Simulate appearance change requiring passcode
                print("(Appearance change scenario)", end=" ")
                result = adaptive_system.authenticate(
                    scenario['user_id'], 
                    test_image, 
                    passcode=scenario['passcode']
                )
            elif i % 8 == 0:
                # Test without passcode (might fail if similarity too low)
                print("(No passcode)", end=" ")
                result = adaptive_system.authenticate(scenario['user_id'], test_image)
            else:
                # Normal authentication
                print("(Normal)", end=" ")
                result = adaptive_system.authenticate(scenario['user_id'], test_image)
            
            # Display result
            status_emoji = "✅" if result.success else "❌"
            method_text = result.method.replace("_", " ").title()
            
            print(f"{status_emoji} {method_text} | Sim: {result.similarity:.3f} | "
                  f"Conf: {result.confidence:.3f} | Updated: {result.template_updated}")
            
            auth_results.append(result)
            
            # Small delay to simulate real usage
            time.sleep(0.1)
        
        # Get final stats
        user_stats = adaptive_system.get_user_stats(scenario['user_id'])
        
        print(f"\n📊 Final Statistics for {scenario['name']}:")
        print(f"  • Total template updates: {user_stats['template_stats']['total_updates']}")
        print(f"  • Average confidence: {user_stats['template_stats']['avg_confidence']:.3f}")
        print(f"  • Templates in bank: {user_stats['bank_stats']['template_count']}")
        
        # Store results
        all_results[scenario['user_id']] = {
            'scenario': scenario,
            'enrollment_result': enrollment_result,
            'auth_results': [result.__dict__ for result in auth_results],
            'user_stats': user_stats
        }
    
    # System-wide statistics
    print(f"\n{'='*50}")
    print("🌟 SYSTEM-WIDE STATISTICS")
    print(f"{'='*50}")
    
    total_stats = adaptive_system.auth_stats
    print(f"📈 Total Authentication Attempts: {total_stats['total_attempts']}")
    print(f"🔐 Successful Biometric: {total_stats['successful_biometric']}")
    print(f"🔑 Successful Passcode Fallback: {total_stats['successful_passcode']}")
    print(f"❌ Failed Attempts: {total_stats['failed_attempts']}")
    print(f"🔄 Template Updates: {total_stats['template_updates']}")
    
    if total_stats['total_attempts'] > 0:
        success_rate = (total_stats['successful_biometric'] + total_stats['successful_passcode']) / total_stats['total_attempts']
        biometric_rate = total_stats['successful_biometric'] / total_stats['total_attempts']
        print(f"✨ Overall Success Rate: {success_rate:.1%}")
        print(f"🎯 Pure Biometric Rate: {biometric_rate:.1%}")
    
    # Save comprehensive results
    output_dir = "adaptive_demo_results"
    os.makedirs(output_dir, exist_ok=True)
    
    # Save system state
    adaptive_system.save_system_state(os.path.join(output_dir, "demo_system_state.json"))
    
    # Save detailed results
    with open(os.path.join(output_dir, "comprehensive_demo_results.json"), 'w') as f:
        json.dump({
            'demo_timestamp': datetime.now().isoformat(),
            'system_config': config,
            'scenarios': scenarios,
            'results': all_results,
            'system_stats': total_stats
        }, f, indent=2)
    
    # Create visualizations
    create_demo_visualizations(all_results, output_dir)
    
    print(f"\n💾 Results saved to '{output_dir}' directory")
    print("🎉 Demo completed successfully!")
    
    return adaptive_system, all_results

def create_demo_visualizations(results: dict, output_dir: str):
    """Create comprehensive visualizations of demo results"""
    print(f"\n📊 Creating visualizations...")
    
    # 1. Authentication success patterns
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('Adaptive Face Recognition Demo Results', fontsize=16, fontweight='bold')
    
    # Success rate by user
    user_names = []
    success_rates = []
    biometric_rates = []
    
    for user_id, user_data in results.items():
        user_names.append(user_data['scenario']['name'])
        
        auth_results = user_data['auth_results']
        total = len(auth_results)
        successful = sum(1 for r in auth_results if r['success'])
        biometric = sum(1 for r in auth_results if r['method'] == 'biometric')
        
        success_rates.append(successful / total if total > 0 else 0)
        biometric_rates.append(biometric / total if total > 0 else 0)
    
    # Plot success rates
    x_pos = range(len(user_names))
    axes[0, 0].bar(x_pos, success_rates, alpha=0.7, color='green', label='Overall Success')
    axes[0, 0].bar(x_pos, biometric_rates, alpha=0.7, color='blue', label='Pure Biometric')
    axes[0, 0].set_xlabel('Users')
    axes[0, 0].set_ylabel('Success Rate')
    axes[0, 0].set_title('Authentication Success Rates by User')
    axes[0, 0].set_xticks(x_pos)
    axes[0, 0].set_xticklabels([name.split(' - ')[0] for name in user_names], rotation=45)
    axes[0, 0].legend()
    axes[0, 0].grid(True, alpha=0.3)
    
    # 2. Similarity distribution over time
    for i, (user_id, user_data) in enumerate(results.items()):
        auth_results = user_data['auth_results']
        similarities = [r['similarity'] for r in auth_results]
        attempts = range(1, len(similarities) + 1)
        
        axes[0, 1].plot(attempts, similarities, 
                       marker='o', linewidth=2, alpha=0.7,
                       label=user_data['scenario']['name'].split(' - ')[0])
    
    axes[0, 1].axhline(y=0.65, color='green', linestyle='--', alpha=0.7, label='Auth Threshold')
    axes[0, 1].axhline(y=0.45, color='orange', linestyle='--', alpha=0.7, label='Close Match Threshold')
    axes[0, 1].set_xlabel('Authentication Attempt')
    axes[0, 1].set_ylabel('Similarity Score')
    axes[0, 1].set_title('Similarity Scores Over Time')
    axes[0, 1].legend()
    axes[0, 1].grid(True, alpha=0.3)
    
    # 3. Template updates over time
    for i, (user_id, user_data) in enumerate(results.items()):
        auth_results = user_data['auth_results']
        updates = []
        cumulative_updates = 0
        
        for r in auth_results:
            if r['template_updated']:
                cumulative_updates += 1
            updates.append(cumulative_updates)
        
        attempts = range(1, len(updates) + 1)
        axes[1, 0].plot(attempts, updates, 
                       marker='s', linewidth=2, alpha=0.7,
                       label=user_data['scenario']['name'].split(' - ')[0])
    
    axes[1, 0].set_xlabel('Authentication Attempt')
    axes[1, 0].set_ylabel('Cumulative Template Updates')
    axes[1, 0].set_title('Template Adaptation Progress')
    axes[1, 0].legend()
    axes[1, 0].grid(True, alpha=0.3)
    
    # 4. Confidence distribution
    all_confidences = []
    all_methods = []
    
    for user_id, user_data in results.items():
        for r in user_data['auth_results']:
            if r['success']:
                all_confidences.append(r['confidence'])
                all_methods.append(r['method'])
    
    # Group by method
    biometric_conf = [c for c, m in zip(all_confidences, all_methods) if m == 'biometric']
    passcode_conf = [c for c, m in zip(all_confidences, all_methods) if m == 'passcode_fallback']
    
    axes[1, 1].hist(biometric_conf, alpha=0.7, bins=15, label='Biometric', color='blue')
    if passcode_conf:
        axes[1, 1].hist(passcode_conf, alpha=0.7, bins=15, label='Passcode Fallback', color='orange')
    
    axes[1, 1].set_xlabel('Confidence Score')
    axes[1, 1].set_ylabel('Frequency')
    axes[1, 1].set_title('Confidence Distribution by Method')
    axes[1, 1].legend()
    axes[1, 1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'comprehensive_demo_analysis.png'), 
                dpi=300, bbox_inches='tight')
    print("  ✅ Comprehensive analysis saved")
    
    # 2. Individual user adaptation progress
    for user_id, user_data in results.items():
        try:
            user_stats = user_data['user_stats']
            if user_stats['template_stats']['total_updates'] > 0:
                visualize_adaptation_progress(
                    user_stats, 
                    os.path.join(output_dir, f'adaptation_{user_id}.png')
                )
                print(f"  ✅ Adaptation progress for {user_id} saved")
        except Exception as e:
            print(f"  ⚠️  Could not create adaptation visualization for {user_id}: {e}")
    
    plt.show()

def run_security_analysis():
    """Analyze security aspects of the adaptive system"""
    print("\n🔒 Security Analysis Demo")
    print("=" * 40)
    
    # Test with different security configurations
    security_configs = {
        'High Security': {
            'auth_threshold': 0.75,
            'close_match_threshold': 0.6,
            'adaptation_rate': 0.08,
            'min_confidence_update': 0.5
        },
        'Balanced': {
            'auth_threshold': 0.65,
            'close_match_threshold': 0.45,
            'adaptation_rate': 0.12,
            'min_confidence_update': 0.3
        },
        'High Convenience': {
            'auth_threshold': 0.55,
            'close_match_threshold': 0.35,
            'adaptation_rate': 0.18,
            'min_confidence_update': 0.2
        }
    }
    
    for config_name, config in security_configs.items():
        print(f"\n⚙️  Testing {config_name} Configuration:")
        print(f"   Auth Threshold: {config['auth_threshold']}")
        print(f"   Close Match: {config['close_match_threshold']}")
        print(f"   Adaptation Rate: {config['adaptation_rate']}")

if __name__ == "__main__":
    # Run the comprehensive demo
    system, results = run_comprehensive_demo()
    
    # Optional: Run security analysis
    user_input = input("\n🔒 Run security analysis demo? (y/n): ").lower().strip()
    if user_input == 'y':
        run_security_analysis()
    
    print("\n🎯 Demo session completed! Check the output directory for detailed results.") 