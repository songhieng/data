#!/usr/bin/env python3
"""
Face Recognition Data Drift Detection System
===========================================

This script implements multiple data drift detection methods for face recognition
using FaceNet-512 embeddings from the CFP dataset.

Methods implemented:
1. Euclidean distance-based drift detection
2. Kolmogorov-Smirnov (KS) test
3. Domain classifier (ML classifier)
4. Combined criteria approach

Author: AI Assistant
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from typing import Tuple, List, Dict, Optional
from dataclasses import dataclass
from tqdm import tqdm
import json
import warnings

# Machine Learning imports
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# Statistical tests
from scipy import stats
from scipy.spatial.distance import euclidean, cosine

# Deep learning
try:
    from deepface import DeepFace
except ImportError:
    print("DeepFace not installed. Please install with: pip install deepface")
    raise

warnings.filterwarnings('ignore')

@dataclass
class DriftDetectionResult:
    """Container for drift detection results"""
    method: str
    drift_detected: bool
    score: float
    threshold: float
    p_value: Optional[float] = None
    additional_info: Optional[Dict] = None

class FaceEmbeddingExtractor:
    """Extract FaceNet-512 embeddings using DeepFace"""
    
    def __init__(self, model_name: str = "Facenet512"):
        self.model_name = model_name
        self.embedding_size = 512
        
    def extract_embedding(self, image_path: str) -> Optional[np.ndarray]:
        """Extract embedding from a single image"""
        try:
            embedding = DeepFace.represent(
                img_path=image_path,
                model_name=self.model_name,
                enforce_detection=False
            )
            return np.array(embedding[0]["embedding"])
        except Exception as e:
            print(f"Error processing {image_path}: {e}")
            return None
    
    def extract_embeddings_batch(self, image_paths: List[str]) -> Tuple[np.ndarray, List[str]]:
        """Extract embeddings from multiple images"""
        embeddings = []
        valid_paths = []
        
        print(f"Extracting embeddings from {len(image_paths)} images...")
        
        for path in tqdm(image_paths):
            embedding = self.extract_embedding(path)
            if embedding is not None:
                embeddings.append(embedding)
                valid_paths.append(path)
        
        if embeddings:
            return np.array(embeddings), valid_paths
        else:
            return np.array([]), []

class CFPDatasetLoader:
    """Load and organize CFP dataset"""
    
    def __init__(self, dataset_path: str):
        self.dataset_path = Path(dataset_path)
        self.images_path = self.dataset_path / "Data" / "Images"
        self.names_file = self.dataset_path / "Data" / "list_name.txt"
        
        # Load celebrity names
        if self.names_file.exists():
            with open(self.names_file, 'r') as f:
                self.celebrity_names = [line.strip() for line in f.readlines()]
        else:
            print(f"Warning: {self.names_file} not found")
            self.celebrity_names = []
    
    def get_image_paths(self, subset: str = "all", 
                       image_type: str = "frontal", 
                       max_celebrities: int = None) -> List[str]:
        """Get image paths from the dataset"""
        image_paths = []
        
        # Determine range of celebrities to process
        start_idx = 1
        end_idx = 501
        if max_celebrities:
            end_idx = min(start_idx + max_celebrities, 501)
        
        # Iterate through celebrity folders (001-500)
        for i in range(start_idx, end_idx):
            celebrity_folder = self.images_path / f"{i:03d}"
            
            if not celebrity_folder.exists():
                continue
                
            if image_type in ["frontal", "both"]:
                frontal_path = celebrity_folder / "frontal"
                if frontal_path.exists():
                    for img_file in frontal_path.glob("*.jpg"):
                        image_paths.append(str(img_file))
            
            if image_type in ["profile", "both"]:
                profile_path = celebrity_folder / "profile"
                if profile_path.exists():
                    for img_file in profile_path.glob("*.jpg"):
                        image_paths.append(str(img_file))
        
        return sorted(image_paths)
    
    def create_temporal_split(self, image_paths: List[str], 
                            split_ratio: float = 0.5) -> Tuple[List[str], List[str]]:
        """Create temporal split to simulate data drift"""
        # Sort by celebrity ID and image number to create temporal ordering
        sorted_paths = sorted(image_paths, key=lambda x: self._extract_sort_key(x))
        
        split_idx = int(len(sorted_paths) * split_ratio)
        reference_set = sorted_paths[:split_idx]
        target_set = sorted_paths[split_idx:]
        
        return reference_set, target_set
    
    def _extract_sort_key(self, path: str) -> Tuple[int, str, int]:
        """Extract sorting key from image path"""
        path_parts = Path(path).parts
        celebrity_id = int(path_parts[-3])  # e.g., "001"
        image_type = path_parts[-2]  # "frontal" or "profile"
        image_num = int(Path(path).stem)  # e.g., "01"
        return (celebrity_id, image_type, image_num)

class DataDriftDetector:
    """Multi-method data drift detection for face embeddings"""
    
    def __init__(self):
        self.scaler = StandardScaler()
        # Remove fixed PCA component count from initialization
        # We'll create PCA instances dynamically as needed with appropriate component counts
        
    def detect_euclidean_drift(self, reference_embeddings: np.ndarray, 
                              target_embeddings: np.ndarray,
                              threshold: float = 2.0) -> DriftDetectionResult:
        """Detect drift using Euclidean distance between centroids"""
        ref_centroid = np.mean(reference_embeddings, axis=0)
        target_centroid = np.mean(target_embeddings, axis=0)
        
        distance = euclidean(ref_centroid, target_centroid)
        drift_detected = distance > threshold
        
        return DriftDetectionResult(
            method="Euclidean Distance",
            drift_detected=drift_detected,
            score=distance,
            threshold=threshold,
            additional_info={
                "reference_centroid_norm": float(np.linalg.norm(ref_centroid)),
                "target_centroid_norm": float(np.linalg.norm(target_centroid))
            }
        )
    
    def detect_cosine_drift(self, reference_embeddings: np.ndarray,
                           target_embeddings: np.ndarray,
                           threshold: float = 0.1) -> DriftDetectionResult:
        """Detect drift using cosine distance between centroids"""
        ref_centroid = np.mean(reference_embeddings, axis=0)
        target_centroid = np.mean(target_embeddings, axis=0)
        
        # Normalize vectors
        ref_centroid_norm = ref_centroid / np.linalg.norm(ref_centroid)
        target_centroid_norm = target_centroid / np.linalg.norm(target_centroid)
        
        distance = cosine(ref_centroid_norm, target_centroid_norm)
        drift_detected = distance > threshold
        
        return DriftDetectionResult(
            method="Cosine Distance",
            drift_detected=drift_detected,
            score=distance,
            threshold=threshold
        )
    
    def detect_ks_drift(self, reference_embeddings: np.ndarray,
                       target_embeddings: np.ndarray,
                       alpha: float = 0.05) -> DriftDetectionResult:
        """Detect drift using Kolmogorov-Smirnov test on embedding dimensions"""
        # Test each dimension separately and use Bonferroni correction
        n_dimensions = reference_embeddings.shape[1]
        p_values = []
        
        for dim in range(n_dimensions):
            ref_dim = reference_embeddings[:, dim]
            target_dim = target_embeddings[:, dim]
            
            # Two-sample KS test
            ks_stat, p_val = stats.ks_2samp(ref_dim, target_dim)
            p_values.append(p_val)
        
        # Use minimum p-value with Bonferroni correction
        min_p_value = min(p_values)
        corrected_alpha = alpha / n_dimensions
        drift_detected = min_p_value < corrected_alpha
        
        return DriftDetectionResult(
            method="Kolmogorov-Smirnov",
            drift_detected=drift_detected,
            score=min_p_value,
            threshold=corrected_alpha,
            p_value=min_p_value,
            additional_info={
                "n_dimensions_tested": n_dimensions,
                "bonferroni_correction": True,
                "mean_p_value": float(np.mean(p_values))
            }
        )
    
    def detect_mmd_drift(self, reference_embeddings: np.ndarray,
                        target_embeddings: np.ndarray,
                        threshold: float = 0.1) -> DriftDetectionResult:
        """Detect drift using Maximum Mean Discrepancy (MMD)"""
        def rbf_kernel(X, Y, gamma=1.0):
            """RBF kernel for MMD computation"""
            XX = np.sum(X**2, axis=1)[:, np.newaxis]
            YY = np.sum(Y**2, axis=1)[np.newaxis, :]
            XY = np.dot(X, Y.T)
            return np.exp(-gamma * (XX + YY - 2 * XY))
        
        # Reduce dimensionality for computational efficiency
        # Dynamically set n_components to avoid the error
        n_samples = min(len(reference_embeddings), len(target_embeddings))
        n_features = reference_embeddings.shape[1]
        n_components = min(n_samples, n_features, 30)  # Cap at 30 components
        
        pca = PCA(n_components=n_components)
        ref_reduced = pca.fit_transform(reference_embeddings)
        target_reduced = pca.transform(target_embeddings)
        
        m, n = len(ref_reduced), len(target_reduced)
        
        # Compute MMD
        K_XX = rbf_kernel(ref_reduced, ref_reduced)
        K_YY = rbf_kernel(target_reduced, target_reduced)
        K_XY = rbf_kernel(ref_reduced, target_reduced)
        
        mmd = (np.sum(K_XX) / (m * m) + 
               np.sum(K_YY) / (n * n) - 
               2 * np.sum(K_XY) / (m * n))
        
        drift_detected = mmd > threshold
        
        return DriftDetectionResult(
            method="Maximum Mean Discrepancy",
            drift_detected=drift_detected,
            score=mmd,
            threshold=threshold,
            additional_info={"pca_components": n_components}
        )
    
    def detect_domain_classifier_drift(self, reference_embeddings: np.ndarray,
                                     target_embeddings: np.ndarray,
                                     auc_threshold: float = 0.7) -> DriftDetectionResult:
        """Detect drift using domain classifier approach"""
        # Create labels: 0 for reference, 1 for target
        X = np.vstack([reference_embeddings, target_embeddings])
        y = np.hstack([np.zeros(len(reference_embeddings)), 
                      np.ones(len(target_embeddings))])
        
        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        
        # Split for training and testing
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y, test_size=0.3, random_state=42, stratify=y
        )
        
        # Train domain classifier
        classifier = RandomForestClassifier(
            n_estimators=100, random_state=42, n_jobs=-1
        )
        classifier.fit(X_train, y_train)
        
        # Evaluate AUC
        y_pred_proba = classifier.predict_proba(X_test)[:, 1]
        auc_score = roc_auc_score(y_test, y_pred_proba)
        
        # Cross-validation for robustness
        cv_scores = cross_val_score(
            classifier, X_scaled, y, cv=5, scoring='roc_auc'
        )
        
        drift_detected = auc_score > auc_threshold
        
        return DriftDetectionResult(
            method="Domain Classifier",
            drift_detected=drift_detected,
            score=auc_score,
            threshold=auc_threshold,
            additional_info={
                "cv_mean_auc": float(np.mean(cv_scores)),
                "cv_std_auc": float(np.std(cv_scores)),
                "feature_importances": classifier.feature_importances_[:10].tolist()
            }
        )
    
    def combined_drift_detection(self, reference_embeddings: np.ndarray,
                               target_embeddings: np.ndarray,
                               config: Dict = None) -> Dict[str, DriftDetectionResult]:
        """Combined drift detection using multiple methods"""
        if config is None:
            config = {
                'euclidean_threshold': 2.0,
                'cosine_threshold': 0.1,
                'ks_alpha': 0.05,
                'mmd_threshold': 0.1,
                'classifier_auc_threshold': 0.7
            }
        
        results = {}
        
        # Run all detection methods
        print("Running Euclidean distance detection...")
        results['euclidean'] = self.detect_euclidean_drift(
            reference_embeddings, target_embeddings,
            threshold=config['euclidean_threshold']
        )
        
        print("Running Cosine distance detection...")
        results['cosine'] = self.detect_cosine_drift(
            reference_embeddings, target_embeddings,
            threshold=config['cosine_threshold']
        )
        
        print("Running KS test detection...")
        results['ks'] = self.detect_ks_drift(
            reference_embeddings, target_embeddings,
            alpha=config['ks_alpha']
        )
        
        print("Running MMD detection...")
        results['mmd'] = self.detect_mmd_drift(
            reference_embeddings, target_embeddings,
            threshold=config['mmd_threshold']
        )
        
        print("Running domain classifier detection...")
        results['domain_classifier'] = self.detect_domain_classifier_drift(
            reference_embeddings, target_embeddings,
            auc_threshold=config['classifier_auc_threshold']
        )
        
        return results

class DriftAnalysisVisualizer:
    """Visualization tools for drift analysis"""
    
    def __init__(self):
        plt.style.use('default')
        
    def plot_embedding_distributions(self, reference_embeddings: np.ndarray,
                                   target_embeddings: np.ndarray,
                                   save_path: str = None):
        """Plot distributions of embedding dimensions"""
        fig, axes = plt.subplots(2, 3, figsize=(15, 10))
        axes = axes.ravel()
        
        # Select first 6 dimensions for visualization
        for i in range(min(6, reference_embeddings.shape[1])):
            ax = axes[i]
            
            ax.hist(reference_embeddings[:, i], alpha=0.7, bins=30, 
                   label='Reference', density=True, color='blue')
            ax.hist(target_embeddings[:, i], alpha=0.7, bins=30, 
                   label='Target', density=True, color='red')
            ax.set_title(f'Dimension {i+1}')
            ax.legend()
            ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()
    
    def plot_drift_results(self, results: Dict[str, DriftDetectionResult],
                          save_path: str = None):
        """Plot drift detection results"""
        methods = list(results.keys())
        scores = [results[method].score for method in methods]
        thresholds = [results[method].threshold for method in methods]
        drift_detected = [results[method].drift_detected for method in methods]
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # Plot scores vs thresholds
        colors = ['red' if detected else 'green' for detected in drift_detected]
        bars = ax1.bar(methods, scores, color=colors, alpha=0.7)
        
        # Add threshold lines
        for i, (method, threshold) in enumerate(zip(methods, thresholds)):
            if method != 'ks':  # KS test uses p-value, others use direct comparison
                ax1.axhline(y=threshold, xmin=i/len(methods), 
                           xmax=(i+1)/len(methods), color='black', 
                           linestyle='--', alpha=0.8)
        
        ax1.set_title('Drift Detection Scores vs Thresholds')
        ax1.set_ylabel('Score')
        ax1.tick_params(axis='x', rotation=45)
        ax1.grid(True, alpha=0.3)
        
        # Plot detection summary
        detection_counts = [sum(drift_detected), len(drift_detected) - sum(drift_detected)]
        ax2.pie(detection_counts, labels=['Drift Detected', 'No Drift'], 
               autopct='%1.1f%%', startangle=90, colors=['red', 'green'])
        ax2.set_title('Drift Detection Summary')
        
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()
    
    def plot_pca_analysis(self, reference_embeddings: np.ndarray,
                         target_embeddings: np.ndarray,
                         save_path: str = None):
        """Plot PCA analysis of embeddings"""
        # Combine embeddings for PCA
        all_embeddings = np.vstack([reference_embeddings, target_embeddings])
        labels = np.hstack([np.zeros(len(reference_embeddings)), 
                           np.ones(len(target_embeddings))])
        
        # Apply PCA
        pca = PCA(n_components=2)
        embeddings_2d = pca.fit_transform(all_embeddings)
        
        # Plot
        plt.figure(figsize=(10, 8))
        colors = ['blue', 'red']
        for i, label in enumerate(['Reference', 'Target']):
            mask = labels == i
            plt.scatter(embeddings_2d[mask, 0], embeddings_2d[mask, 1], 
                       c=colors[i], alpha=0.6, label=label)
        
        plt.xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.2%} variance)')
        plt.ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.2%} variance)')
        plt.title('PCA Analysis of Face Embeddings')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()

def main():
    """Main execution function"""
    
    # Configuration
    DATASET_PATH = "cfp-dataset"
    OUTPUT_DIR = "drift_analysis_results"
    
    # Create output directory
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    print("=" * 60)
    print("FACE RECOGNITION DATA DRIFT DETECTION SYSTEM")
    print("=" * 60)
    
    # Initialize components
    print("\n1. Initializing components...")
    dataset_loader = CFPDatasetLoader(DATASET_PATH)
    embedding_extractor = FaceEmbeddingExtractor()
    drift_detector = DataDriftDetector()
    visualizer = DriftAnalysisVisualizer()
    
    # Load dataset
    print("\n2. Loading dataset...")
    
    # Get frontal images (more consistent for drift detection)
    frontal_images = dataset_loader.get_image_paths(
        image_type="frontal", max_celebrities=250  # Limit for demo
    )
    print(f"Found {len(frontal_images)} frontal images")
    
    if len(frontal_images) == 0:
        print("Error: No images found. Please check dataset path.")
        return
    
    # Create temporal split to simulate drift
    reference_paths, target_paths = dataset_loader.create_temporal_split(
        frontal_images, split_ratio=0.6
    )
    
    print(f"Reference set: {len(reference_paths)} images")
    print(f"Target set: {len(target_paths)} images")
    
    # Extract embeddings (limited for demo)
    print("\n3. Extracting embeddings...")
    print("Extracting reference embeddings...")
    reference_embeddings, valid_ref_paths = embedding_extractor.extract_embeddings_batch(
        reference_paths[:250]  # Limit for demo purposes
    )
    
    print("Extracting target embeddings...")
    target_embeddings, valid_target_paths = embedding_extractor.extract_embeddings_batch(
        target_paths[:250]  # Limit for demo purposes
    )
    
    if len(reference_embeddings) == 0 or len(target_embeddings) == 0:
        print("Error: Could not extract embeddings. Please check image paths and DeepFace installation.")
        print("Make sure you have installed: pip install deepface")
        return
    
    print(f"Reference embeddings shape: {reference_embeddings.shape}")
    print(f"Target embeddings shape: {target_embeddings.shape}")
    
    # Save embeddings for future use
    np.save(os.path.join(OUTPUT_DIR, "reference_embeddings.npy"), reference_embeddings)
    np.save(os.path.join(OUTPUT_DIR, "target_embeddings.npy"), target_embeddings)
    
    # Perform drift detection
    print("\n4. Performing drift detection...")
    
    # Configuration for drift detection (adjusted for better sensitivity)
    drift_config = {
        'euclidean_threshold': 1.5,
        'cosine_threshold': 0.05,
        'ks_alpha': 0.01,
        'mmd_threshold': 0.05,
        'classifier_auc_threshold': 0.7
    }
    
    # Run combined drift detection
    drift_results = drift_detector.combined_drift_detection(
        reference_embeddings, target_embeddings, drift_config
    )
    
    # Print results
    print("\n5. DRIFT DETECTION RESULTS:")
    print("=" * 50)
    
    for method, result in drift_results.items():
        print(f"\n{result.method}:")
        print(f"  Drift Detected: {'YES' if result.drift_detected else 'NO'}")
        print(f"  Score: {result.score:.4f}")
        print(f"  Threshold: {result.threshold:.4f}")
        if result.p_value is not None:
            print(f"  P-value: {result.p_value:.6f}")
        if result.additional_info:
            print(f"  Additional Info: {result.additional_info}")
    
    # Combined decision logic (as requested)
    euclidean_drift = drift_results['euclidean'].drift_detected
    ks_drift = drift_results['ks'].drift_detected
    classifier_drift = drift_results['domain_classifier'].drift_detected
    
    # Your suggested logic: (distance > D_thresh) AND (KS p<0.05 OR classifier AUC>0.7)
    combined_decision = euclidean_drift and (ks_drift or classifier_drift)
    
    print(f"\n6. COMBINED DECISION:")
    print(f"   Logic: (Euclidean > threshold) AND (KS detected OR Classifier detected)")
    print(f"   Euclidean drift: {euclidean_drift}")
    print(f"   KS drift: {ks_drift}")
    print(f"   Classifier drift: {classifier_drift}")
    print(f"   Final Result: {'DRIFT DETECTED' if combined_decision else 'NO DRIFT'}")
    
    # Generate visualizations
    print("\n7. Generating visualizations...")
    
    try:
        # Plot embedding distributions
        visualizer.plot_embedding_distributions(
            reference_embeddings, target_embeddings,
            save_path=os.path.join(OUTPUT_DIR, "embedding_distributions.png")
        )
        
        # Plot drift results
        visualizer.plot_drift_results(
            drift_results,
            save_path=os.path.join(OUTPUT_DIR, "drift_results.png")
        )
        
        # Plot PCA analysis
        visualizer.plot_pca_analysis(
            reference_embeddings, target_embeddings,
            save_path=os.path.join(OUTPUT_DIR, "pca_analysis.png")
        )
    except Exception as e:
        print(f"Error generating visualizations: {e}")
        print("Continuing without visualizations...")
    
    # Save detailed results
    results_summary = {
        'config': drift_config,
        'dataset_info': {
            'reference_size': len(reference_embeddings),
            'target_size': len(target_embeddings),
            'embedding_dimension': reference_embeddings.shape[1]
        },
        'results': {
            method: {
                'drift_detected': bool(result.drift_detected),
                'score': float(result.score),
                'threshold': float(result.threshold),
                'p_value': float(result.p_value) if result.p_value else None,
                'additional_info': {
                    k: (float(v) if isinstance(v, (np.float32, np.float64)) else
                       bool(v) if isinstance(v, np.bool_) else
                       v.tolist() if isinstance(v, np.ndarray) else v)
                    for k, v in (result.additional_info or {}).items()
                }
            }
            for method, result in drift_results.items()
        },
        'combined_decision': bool(combined_decision)
    }
    
    with open(os.path.join(OUTPUT_DIR, "drift_analysis_summary.json"), 'w') as f:
        json.dump(results_summary, f, indent=2)
    
    print(f"\n8. Analysis complete! Results saved to '{OUTPUT_DIR}' directory.")
    print("\nFiles generated:")
    print("  - reference_embeddings.npy")
    print("  - target_embeddings.npy") 
    print("  - embedding_distributions.png")
    print("  - drift_results.png")
    print("  - pca_analysis.png")
    print("  - drift_analysis_summary.json")
    
    # Recommendations
    print(f"\n9. RECOMMENDATIONS:")
    print("=" * 30)
    
    if combined_decision:
        print("⚠️  DRIFT DETECTED - Consider the following actions:")
        print("   - Retrain the face recognition model with recent data")
        print("   - Investigate the source of distribution shift")
        print("   - Implement continuous monitoring")
        print("   - Consider domain adaptation techniques")
    else:
        print("✅ NO SIGNIFICANT DRIFT DETECTED")
        print("   - Current model should perform well")
        print("   - Continue monitoring with regular intervals")
        print("   - Consider expanding the dataset for better coverage")

if __name__ == "__main__":
    main()
