#!/usr/bin/env python3
"""
Quick Demo Script for Adaptive Face Recognition
===============================================

Run this to test the adaptive face recognition system with your CFP dataset.
"""

import os
from adaptive_face_recognition import AdaptiveFaceRecognition, visualize_adaptation_progress
from drift_detector import CFPDatasetLoader
import json

def quick_demo():
    """Quick demonstration of adaptive face recognition"""
    print("🚀 Starting Adaptive Face Recognition Demo")
    print("=" * 50)
    
    # Initialize system
    adaptive_system = AdaptiveFaceRecognition()
    dataset_loader = CFPDatasetLoader("cfp-dataset")
    
    # Get some images from the dataset
    print("📸 Loading images from CFP dataset...")
    frontal_images = dataset_loader.get_image_paths(image_type="frontal", max_celebrities=5)
    
    if len(frontal_images) < 10:
        print("❌ Need at least 10 images. Check your dataset path.")
        return
    
    # Use first few images for enrollment, rest for testing
    enrollment_images = frontal_images[:5]
    test_images = frontal_images[5:10]
    
    print(f"✅ Found {len(frontal_images)} images total")
    print(f"📝 Using {len(enrollment_images)} for enrollment")
    print(f"🧪 Using {len(test_images)} for testing")
    
    # Enroll a demo user
    user_id = "demo_user"
    print(f"\n🔐 Enrolling user: {user_id}")
    
    enrollment_result = adaptive_system.enroll_user(
        user_id, 
        enrollment_images, 
        passcode="1234"
    )
    
    if not enrollment_result['success']:
        print(f"❌ Enrollment failed: {enrollment_result}")
        return
    
    print(f"✅ Enrollment successful! Processed {enrollment_result['enrollment_samples']} images")
    
    # Test authentication
    print(f"\n🔍 Testing authentication...")
    
    for i, test_image in enumerate(test_images):
        print(f"\nTest {i+1}/{len(test_images)}:")
        
        # Try authentication (some with passcode, some without)
        if i % 2 == 0:
            result = adaptive_system.authenticate(user_id, test_image)
        else:
            result = adaptive_system.authenticate(user_id, test_image, passcode="1234")
        
        # Display result
        status = "✅ SUCCESS" if result.success else "❌ FAILED"
        method = result.method.replace("_", " ").title()
        
        print(f"  {status} - {method}")
        print(f"  Similarity: {result.similarity:.3f}")
        print(f"  Confidence: {result.confidence:.3f}")
        print(f"  Template Updated: {result.template_updated}")
        
        if result.reason:
            print(f"  Reason: {result.reason}")
    
    # Show final statistics
    print(f"\n📊 Final Results:")
    user_stats = adaptive_system.get_user_stats(user_id)
    system_stats = adaptive_system.auth_stats
    
    print(f"  Template Updates: {user_stats['template_stats']['total_updates']}")
    print(f"  Average Confidence: {user_stats['template_stats']['avg_confidence']:.3f}")
    print(f"  Total Attempts: {system_stats['total_attempts']}")
    print(f"  Successful Biometric: {system_stats['successful_biometric']}")
    print(f"  Successful Passcode: {system_stats['successful_passcode']}")
    print(f"  Failed: {system_stats['failed_attempts']}")
    
    # Save results
    output_dir = "adaptive_demo_output"
    os.makedirs(output_dir, exist_ok=True)
    
    # Save system state
    adaptive_system.save_system_state(f"{output_dir}/system_state.json")
    
    # Save user stats
    with open(f"{output_dir}/demo_results.json", 'w') as f:
        json.dump({
            'user_stats': user_stats,
            'system_stats': system_stats,
            'enrollment_result': enrollment_result
        }, f, indent=2)
    
    # Create visualization if there were updates
    if user_stats['template_stats']['total_updates'] > 0:
        try:
            visualize_adaptation_progress(
                user_stats, 
                f"{output_dir}/adaptation_progress.png"
            )
        except Exception as e:
            print(f"⚠️ Visualization failed: {e}")
    
    print(f"\n💾 Results saved to '{output_dir}' directory")
    print("🎉 Demo completed!")

if __name__ == "__main__":
    quick_demo() 