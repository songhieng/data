#!/usr/bin/env python
"""
FaceNet 512 Installation Verification Script
===========================================

This script verifies that FaceNet 512 is correctly installed and working.
It tests both facenet-pytorch (TRUE 512-dim) and face_recognition (128-dim fallback).
"""

import os
import sys
import logging
import numpy as np
from pathlib import Path
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def check_import(module_name, package_name=None):
    """Check if a module can be imported."""
    if package_name is None:
        package_name = module_name
    
    try:
        __import__(module_name)
        logger.info(f"✓ {module_name} is installed")
        return True
    except ImportError as e:
        logger.warning(f"✗ {module_name} is NOT installed: {e}")
        logger.info(f"  Install with: pip install {package_name}")
        return False

def verify_facenet_pytorch():
    """Verify facenet-pytorch installation and functionality."""
    logger.info("\n=== Testing facenet-pytorch (TRUE 512-dim embeddings) ===")
    
    if not check_import('facenet_pytorch'):
        return False
    
    if not check_import('torch'):
        logger.warning("PyTorch is required for facenet-pytorch")
        return False
    
    if not check_import('torchvision'):
        logger.warning("torchvision is required for facenet-pytorch")
        return False
    
    try:
        from facenet_pytorch import MTCNN, InceptionResnetV1
        import torch
        
        # Test model initialization
        logger.info("Initializing FaceNet models...")
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        logger.info(f"Using device: {device}")
        
        mtcnn = MTCNN(
            image_size=160, 
            margin=20,
            min_face_size=20,
            thresholds=[0.6, 0.7, 0.7],
            factor=0.709,
            post_process=True,
            device=device,
            keep_all=True
        )
        logger.info("✓ MTCNN face detector initialized")
        
        resnet = InceptionResnetV1(pretrained='vggface2').eval().to(device)
        logger.info("✓ InceptionResnetV1 model initialized")
        
        # Test with a sample image if available
        sample_path = None
        for path in ['data/cacd_split/cacd_split', 'data/cacd_split', 'data']:
            if os.path.exists(path):
                for root, dirs, files in os.walk(path):
                    for file in files:
                        if file.lower().endswith(('.jpg', '.jpeg', '.png')):
                            sample_path = os.path.join(root, file)
                            break
                    if sample_path:
                        break
            if sample_path:
                break
        
        if sample_path:
            logger.info(f"Testing with sample image: {sample_path}")
            
            # Test with PIL
            try:
                from PIL import Image
                import torchvision.transforms as transforms
                
                img = Image.open(sample_path).convert('RGB')
                logger.info("✓ Image loaded with PIL")
                
                # Try face detection
                start_time = time.time()
                faces = mtcnn(img)
                detection_time = time.time() - start_time
                
                if faces is not None:
                    if isinstance(faces, list):
                        if len(faces) > 0 and faces[0] is not None:
                            face_tensor = faces[0].unsqueeze(0).to(device)
                            logger.info(f"✓ Face detected (list) in {detection_time:.2f}s")
                        else:
                            logger.warning("✗ No faces detected in list result")
                            # Try with direct resize
                            resized = img.resize((160, 160))
                            img_tensor = transforms.ToTensor()(resized).unsqueeze(0).to(device)
                            face_tensor = img_tensor
                            logger.info("✓ Using direct resize as fallback")
                    else:  # Single tensor
                        face_tensor = faces.unsqueeze(0).to(device)
                        logger.info(f"✓ Face detected (tensor) in {detection_time:.2f}s")
                    
                    # Extract embedding
                    start_time = time.time()
                    with torch.no_grad():
                        embedding = resnet(face_tensor)
                    embedding_time = time.time() - start_time
                    
                    embedding_np = embedding.cpu().numpy().flatten()
                    logger.info(f"✓ Embedding extracted in {embedding_time:.2f}s")
                    logger.info(f"✓ Embedding shape: {embedding_np.shape} (should be 512)")
                    logger.info(f"✓ Embedding norm: {np.linalg.norm(embedding_np):.4f} (should be ~1.0)")
                    
                    return True
                else:
                    logger.warning("✗ No faces detected with MTCNN")
                    
                    # Try with direct resize
                    resized = img.resize((160, 160))
                    img_tensor = transforms.ToTensor()(resized).unsqueeze(0).to(device)
                    
                    # Extract embedding
                    with torch.no_grad():
                        embedding = resnet(img_tensor)
                    
                    embedding_np = embedding.cpu().numpy().flatten()
                    logger.info("✓ Embedding extracted with direct resize")
                    logger.info(f"✓ Embedding shape: {embedding_np.shape} (should be 512)")
                    
                    return True
            
            except Exception as e:
                logger.error(f"Error testing with PIL: {e}")
        else:
            logger.warning("No sample images found for testing")
            logger.info("✓ Models initialized successfully but couldn't test with an image")
            return True
        
    except Exception as e:
        logger.error(f"Error testing facenet-pytorch: {e}")
        return False

def verify_face_recognition():
    """Verify face_recognition installation and functionality."""
    logger.info("\n=== Testing face_recognition (128-dim fallback) ===")
    
    if not check_import('face_recognition'):
        return False
    
    if not check_import('dlib'):
        logger.warning("dlib is required for face_recognition")
        return False
    
    try:
        import face_recognition
        
        # Test with a sample image if available
        sample_path = None
        for path in ['data/cacd_split/cacd_split', 'data/cacd_split', 'data']:
            if os.path.exists(path):
                for root, dirs, files in os.walk(path):
                    for file in files:
                        if file.lower().endswith(('.jpg', '.jpeg', '.png')):
                            sample_path = os.path.join(root, file)
                            break
                    if sample_path:
                        break
            if sample_path:
                break
        
        if sample_path:
            logger.info(f"Testing with sample image: {sample_path}")
            
            # Load image
            start_time = time.time()
            image = face_recognition.load_image_file(sample_path)
            load_time = time.time() - start_time
            logger.info(f"✓ Image loaded in {load_time:.2f}s")
            
            # Detect faces with HOG
            start_time = time.time()
            face_locations = face_recognition.face_locations(image, model="hog")
            detection_time = time.time() - start_time
            
            if len(face_locations) > 0:
                logger.info(f"✓ {len(face_locations)} face(s) detected with HOG in {detection_time:.2f}s")
            else:
                logger.warning("✗ No faces detected with HOG")
                
                # Try CNN model
                try:
                    start_time = time.time()
                    face_locations = face_recognition.face_locations(image, model="cnn")
                    detection_time = time.time() - start_time
                    
                    if len(face_locations) > 0:
                        logger.info(f"✓ {len(face_locations)} face(s) detected with CNN in {detection_time:.2f}s")
                    else:
                        logger.warning("✗ No faces detected with CNN")
                except Exception as e:
                    logger.warning(f"CNN model error: {e}")
            
            # Get encodings
            start_time = time.time()
            if len(face_locations) > 0:
                face_encodings = face_recognition.face_encodings(image, face_locations)
            else:
                face_encodings = face_recognition.face_encodings(image)
            encoding_time = time.time() - start_time
            
            if len(face_encodings) > 0:
                logger.info(f"✓ Encodings extracted in {encoding_time:.2f}s")
                logger.info(f"✓ Encoding shape: {face_encodings[0].shape} (should be 128)")
                
                # Expand to 512-dim
                embedding_128 = face_encodings[0]
                embedding_512 = np.tile(embedding_128, 4)  # 128 * 4 = 512
                logger.info(f"✓ Expanded to 512-dim: {embedding_512.shape}")
                
                return True
            else:
                logger.warning("✗ No encodings extracted")
                return False
        else:
            logger.warning("No sample images found for testing")
            logger.info("✓ face_recognition imported successfully but couldn't test with an image")
            return True
        
    except Exception as e:
        logger.error(f"Error testing face_recognition: {e}")
        return False

def verify_deepface():
    """Verify DeepFace installation and functionality."""
    logger.info("\n=== Testing DeepFace with FaceNet 512 (TRUE 512-dim embeddings) ===")
    
    if not check_import('deepface', 'deepface'):
        return False
    
    try:
        from deepface import DeepFace
        
        # Test with a sample image if available
        sample_path = None
        for path in ['data/cacd_split/cacd_split', 'data/cacd_split', 'data']:
            if os.path.exists(path):
                for root, dirs, files in os.walk(path):
                    for file in files:
                        if file.lower().endswith(('.jpg', '.jpeg', '.png')):
                            sample_path = os.path.join(root, file)
                            break
                    if sample_path:
                        break
            if sample_path:
                break
        
        if sample_path:
            logger.info(f"Testing with sample image: {sample_path}")
            
            try:
                # Test DeepFace with FaceNet 512
                start_time = time.time()
                embedding_obj = DeepFace.represent(
                    img_path=sample_path,
                    model_name='Facenet512',  # This gives TRUE 512-dim FaceNet embeddings
                    enforce_detection=False,  # Continue even if face detection fails
                    detector_backend='opencv'  # Use OpenCV for better compatibility
                )
                extraction_time = time.time() - start_time
                
                # DeepFace returns a list of dictionaries
                if isinstance(embedding_obj, list) and len(embedding_obj) > 0:
                    embedding = np.array(embedding_obj[0]['embedding'])
                    if embedding.shape[0] == 512:
                        logger.info(f"✓ TRUE DeepFace FaceNet 512 embedding extracted in {extraction_time:.2f}s")
                        logger.info(f"✓ Embedding shape: {embedding.shape} (should be (512,))")
                        logger.info(f"✓ Embedding norm: {np.linalg.norm(embedding):.4f} (should be ~1.0)")
                        return True
                    else:
                        logger.warning(f"✗ Unexpected embedding dimension: {embedding.shape}")
                        return False
                else:
                    logger.warning("✗ DeepFace failed to extract embedding")
                    return False
                    
            except Exception as e:
                logger.error(f"Error testing DeepFace: {e}")
                return False
        else:
            logger.warning("No sample images found for testing")
            logger.info("✓ DeepFace imported successfully but couldn't test with an image")
            return True
        
    except Exception as e:
        logger.error(f"Error testing DeepFace: {e}")
        return False

def main():
    """Main verification function."""
    logger.info("=== FaceNet 512 Installation Verification ===")
    
    # Check core dependencies
    logger.info("\n=== Checking core dependencies ===")
    core_deps = {
        'numpy': 'numpy',
        'cv2': 'opencv-python',
        'PIL': 'pillow',
        'matplotlib': 'matplotlib',
        'pandas': 'pandas',
        'sklearn': 'scikit-learn'
    }
    
    all_core_ok = True
    for module, package in core_deps.items():
        if not check_import(module, package):
            all_core_ok = False
    
    if all_core_ok:
        logger.info("✓ All core dependencies installed")
    else:
        logger.warning("✗ Some core dependencies are missing")
    
    # Verify facenet-pytorch (TRUE 512-dim)
    facenet_pytorch_ok = verify_facenet_pytorch()
    
    # Verify face_recognition (128-dim fallback)
    face_recognition_ok = verify_face_recognition()
    
    # Verify DeepFace with FaceNet 512
    deepface_ok = verify_deepface()
    
    # Summary
    logger.info("\n=== Verification Summary ===")
    if facenet_pytorch_ok:
        logger.info("✅ TRUE FaceNet 512 (facenet-pytorch) is working correctly")
    else:
        logger.warning("⚠️ TRUE FaceNet 512 (facenet-pytorch) is NOT working")
        logger.info("  Install with: pip install facenet-pytorch torch torchvision")
    
    if face_recognition_ok:
        logger.info("✅ Fallback face_recognition (128→512) is working correctly")
    else:
        logger.warning("⚠️ Fallback face_recognition is NOT working")
        logger.info("  Install with: pip install face-recognition dlib")
    
    if deepface_ok:
        logger.info("✅ DeepFace with FaceNet 512 is working correctly")
    else:
        logger.warning("⚠️ DeepFace with FaceNet 512 is NOT working")
        logger.info("  Install with: pip install deepface")
    
    if facenet_pytorch_ok:
        logger.info("\n✅ VERIFICATION SUCCESSFUL: TRUE FaceNet 512 embeddings are available")
        return 0
    elif face_recognition_ok:
        logger.info("\n⚠️ VERIFICATION PARTIAL: Using fallback 128→512 embeddings")
        return 1
    elif deepface_ok:
        logger.info("\n⚠️ VERIFICATION PARTIAL: Using DeepFace with FaceNet 512")
        return 2
    else:
        logger.error("\n❌ VERIFICATION FAILED: No face embedding methods available")
        return 3

if __name__ == "__main__":
    sys.exit(main()) 