"""
Gated EMA Validation Framework
=============================

This package provides validation modules for EMA and Gated EMA strategies.
"""

import importlib
import os
import sys
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Import FaceNet dependencies
try:
    from facenet_pytorch import MTCNN, InceptionResnetV1
    import torch
    import torchvision
    FACENET_PYTORCH_AVAILABLE = True
    logger.info("✓ TRUE FaceNet 512 available via facenet-pytorch")
except ImportError as e:
    FACENET_PYTORCH_AVAILABLE = False
    logger.warning(f"⚠ facenet-pytorch not available: {e}")

try:
    import face_recognition
    FACE_RECOGNITION_AVAILABLE = True
    logger.info("✓ face_recognition available (128-dim fallback)")
except ImportError as e:
    FACE_RECOGNITION_AVAILABLE = False
    logger.warning(f"⚠ face_recognition not available: {e}")

# Define validator classes to import
validators = {
    '1_Face_Verification_Accuracy_Over_Time': 'FaceVerificationAccuracyOverTimeValidator',
    '2_Genuine_Impostor_Separation': 'GenuineImpostorSeparationValidator',
    '3_Template_Drift_Robustness': 'TemplateDriftRobustnessValidator',
    '4_Update_Stability_Sensitivity': 'UpdateStabilityValidator',
    '5_Ablation_Study_Comparison': 'AblationStudyComparisonValidator',
    '6_Baseline_Strategies_Comparison': 'BaselineStrategiesComparisonValidator'
}

# Import all validators dynamically
for module_name, class_name in validators.items():
    try:
        module = importlib.import_module(f'gated_ema_validation.{module_name}')
        # Add the class to the package namespace
        globals()[class_name] = getattr(module, class_name)
        logger.info(f"✓ Successfully imported {class_name} from {module_name}")
    except (ImportError, AttributeError) as e:
        logger.error(f"Failed to import {class_name} from {module_name}: {e}")
        # Create fallback class
        class FallbackValidator:
            def __init__(self, *args, **kwargs):
                pass
            def validate(self, *args, **kwargs):
                return {'metric_name': f'Fallback {class_name}', 
                        'values': {}, 
                        'summary': f'Module {module_name} not available', 
                        'passed': False}
        globals()[class_name] = FallbackValidator

# Create config module with common settings
class Config:
    """Common configuration settings for validators."""
    DEFAULT_ALPHA_VALUES = [0.1, 0.3, 0.5, 0.7, 0.9]
    DEFAULT_THRESHOLD_VALUES = [0.5, 0.6, 0.7, 0.8, 0.9]
    DEFAULT_WINDOW_SIZES = [3, 5, 7]
    DEFAULT_DECAY_FACTORS = [0.9, 0.95]
    
    @staticmethod
    def get_default_config():
        """Get default configuration dictionary."""
        return {
            'alpha_values': Config.DEFAULT_ALPHA_VALUES,
            'threshold_values': Config.DEFAULT_THRESHOLD_VALUES,
            'window_sizes': Config.DEFAULT_WINDOW_SIZES,
            'decay_factors': Config.DEFAULT_DECAY_FACTORS
        }

# Add config to package namespace
sys.modules['gated_ema_validation.config'] = Config

# Export all validator classes
__all__ = list(validators.values()) + ['Config'] 