#!/usr/bin/env python3
"""
Simple Runner for Complete EMA Evaluation Suite with FaceNet 512
==============================================================

This script runs the consolidated EMA evaluation including:
- EMA strategies
- Gated EMA strategies  
- Baseline strategies
- FaceNet 512-dimensional embeddings
- Comprehensive visualizations
- Production recommendations
"""

import sys
from pathlib import Path

def main():
    """Main runner function."""
    
    print("🚀 EMA Evaluation Suite - FaceNet 512 Version")
    print("=" * 50)
    print("Running comprehensive evaluation including:")
    print("  ✓ EMA strategies (5 configurations)")
    print("  ✓ Gated EMA strategies (6 configurations)")
    print("  ✓ Baseline strategies (13 configurations)")
    print("  ✓ FaceNet 512-dimensional embeddings")
    print("  ✓ Comprehensive analysis and visualizations")
    print("=" * 50)
    
    try:
        # Import and run the consolidated evaluation
        from ema_evaluation_complete import main as run_evaluation
        run_evaluation()
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("Please ensure ema_evaluation_complete.py is in the same directory")
        sys.exit(1)
        
    except Exception as e:
        print(f"❌ Evaluation error: {e}")
        import traceback
        print(traceback.format_exc())
        sys.exit(1)

if __name__ == "__main__":
    main() 