# Installing FaceNet 512 for Face Embeddings

This guide helps you install and verify the necessary dependencies for using TRUE 512-dimensional FaceNet embeddings in the EMA evaluation scripts.

## Quick Installation

```bash
# Install core dependencies
pip install numpy pandas matplotlib scikit-learn opencv-python pillow tqdm scipy seaborn

# Install TRUE FaceNet 512 (RECOMMENDED)
pip install torch torchvision facenet-pytorch

# Install face_recognition fallback (optional)
pip install face-recognition dlib
```

## Step-by-Step Installation Guide

### 1. Core Dependencies

These are required for basic functionality:

```bash
pip install numpy pandas matplotlib scikit-learn opencv-python pillow tqdm scipy seaborn
```

### 2. TRUE FaceNet 512 (RECOMMENDED)

For authentic 512-dimensional FaceNet embeddings:

```bash
# Install PyTorch (adjust for your CUDA version if needed)
pip install torch torchvision

# Install FaceNet
pip install facenet-pytorch
```

For GPU support, visit [PyTorch Installation](https://pytorch.org/get-started/locally/) to get the correct command for your CUDA version.

### 3. Face Recognition Fallback (Optional)

This provides a fallback if FaceNet fails (gives 128-dim expanded to 512-dim):

```bash
pip install face-recognition dlib
```

Note: Installing `dlib` may require additional system dependencies:
- **Windows**: Visual C++ build tools
- **Linux**: CMake, C++ compiler, X11 dev libraries
- **macOS**: XCode command line tools

## Verifying Your Installation

Run the verification script to check if everything is working:

```bash
python verify_facenet_installation.py
```

The script will:
1. Check if all required packages are installed
2. Test FaceNet 512 model initialization
3. Test face detection and embedding extraction
4. Verify embedding dimensions (should be 512)

### Expected Output

If everything is working correctly, you should see:

```
=== FaceNet 512 Installation Verification ===
✓ numpy is installed
✓ cv2 is installed
✓ PIL is installed
✓ matplotlib is installed
✓ pandas is installed
✓ sklearn is installed
✓ All core dependencies installed

=== Testing facenet-pytorch (TRUE 512-dim embeddings) ===
✓ facenet-pytorch is installed
✓ torch is installed
✓ torchvision is installed
Initializing FaceNet models...
Using device: cuda
✓ MTCNN face detector initialized
✓ InceptionResnetV1 model initialized
Testing with sample image: data/cacd_split/cacd_split/50Cent/28_50Cent_0001.jpg
✓ Image loaded with PIL
✓ Face detected (tensor) in 0.15s
✓ Embedding extracted in 0.02s
✓ Embedding shape: (512,) (should be 512)
✓ Embedding norm: 1.0000 (should be ~1.0)

=== Verification Summary ===
✅ TRUE FaceNet 512 (facenet-pytorch) is working correctly
✅ Fallback face_recognition (128→512) is working correctly

✅ VERIFICATION SUCCESSFUL: TRUE FaceNet 512 embeddings are available
```

## Troubleshooting

### FaceNet Issues

1. **No faces detected**:
   - Try increasing the margin in MTCNN parameters
   - Use direct image resizing as a fallback

2. **CUDA out of memory**:
   - Reduce batch size
   - Use CPU instead of GPU

3. **Import errors**:
   - Ensure PyTorch is installed with the correct CUDA version
   - Check for conflicting packages

### Face Recognition Issues

1. **dlib installation fails**:
   - Install system dependencies first
   - On Windows, install Visual C++ build tools
   - On Linux: `apt-get install cmake libx11-dev libopenblas-dev`

2. **No faces detected**:
   - Try both 'hog' and 'cnn' models
   - Ensure images are in RGB format

## Running the EMA Evaluation

After successful installation:

1. Verify installation:
   ```bash
   python verify_facenet_installation.py
   ```

2. Run the evaluation:
   ```bash
   python ema_evaluation_complete.py
   ```

3. Run comprehensive baseline evaluation:
   ```bash
   python run_comprehensive_baseline_evaluation.py
   ```

## Notes on Embedding Types

The system uses three types of embeddings in order of preference:

1. **TRUE FaceNet 512** (via facenet-pytorch): Authentic 512-dimensional embeddings
2. **Face Recognition 128→512** (via face_recognition): 128-dimensional embeddings expanded to 512
3. **Synthetic Fallback**: Image-based synthetic embeddings as a last resort

The logs will clearly indicate which embedding type is being used. 