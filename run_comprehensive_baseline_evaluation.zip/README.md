# EMA Study for Face Recognition - Consolidated Version

## Overview

This repository contains a comprehensive evaluation framework for EMA (Exponential Moving Average) strategies in face recognition template updating. The codebase has been consolidated for easier usage and maintenance.

## Quick Start

```bash
# Run validation tests
python validation_test.py

# Run complete evaluation
python run_evaluation.py
```

## File Structure

### Core Files
- **`ema_evaluation_complete.py`** - Main evaluation script with all strategies
- **`run_evaluation.py`** - Simple runner for the evaluation
- **`validation_test.py`** - Testing and validation script

### Results
All results are saved to the `results/` directory:
- Visualizations in `results/plots/`
- Comprehensive report in `results/CONSOLIDATED_EVALUATION_REPORT.md`
- Raw data in `results/all_results_consolidated.json`

## Features

- Evaluates 24 different template update strategies:
  - 5 EMA strategies
  - 6 Gated EMA strategies
  - 13 baseline strategies
- Comprehensive analysis of:
  - Accuracy performance
  - Computational cost
  - Robustness
  - Parameter sensitivity
- Production deployment recommendations

## Requirements

```
numpy
pandas
matplotlib
seaborn
scipy
```

For more detailed information, see the `CONSOLIDATED_README.md` file. 